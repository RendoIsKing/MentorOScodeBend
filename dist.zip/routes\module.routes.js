"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Controllers_1 = require("../app/Controllers/");
const moduleRoutes = (0, express_1.Router)();
moduleRoutes.post("/", Controllers_1.ModuleController.create);
moduleRoutes.get("/", Controllers_1.ModuleController.index);
moduleRoutes.get("/:id", Controllers_1.ModuleController.show);
moduleRoutes.put("/:id", Controllers_1.ModuleController.update);
moduleRoutes.delete("/:id", Controllers_1.ModuleController.destroy);
exports.default = moduleRoutes;
//# sourceMappingURL=module.routes.js.map