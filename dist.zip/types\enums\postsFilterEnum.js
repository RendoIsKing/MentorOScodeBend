"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostFilterEnum = void 0;
var PostFilterEnum;
(function (PostFilterEnum) {
    PostFilterEnum["POSTS"] = "posts";
    PostFilterEnum["TAGGED"] = "tagged";
    PostFilterEnum["FOLLOWING"] = "following";
    PostFilterEnum["SUBSCRIBED"] = "subscribed";
    PostFilterEnum["LIKED"] = "liked";
    PostFilterEnum["SAVED"] = "saved";
    PostFilterEnum["FOR_YOU"] = "foryou";
    PostFilterEnum["ALL"] = "all";
})(PostFilterEnum || (exports.PostFilterEnum = PostFilterEnum = {}));
//# sourceMappingURL=postsFilterEnum.js.map