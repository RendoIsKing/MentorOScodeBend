"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const passport_1 = __importDefault(require("passport"));
const Controllers_1 = require("../app/Controllers/");
const Middlewares_1 = require("../app/Middlewares");
const FileEnum_1 = require("../types/FileEnum");
const fileUpload_1 = require("../app/Middlewares/fileUpload");
const updateProfilePicture_1 = require("../app/Controllers/updateProfilePicture");
const user = (0, express_1.Router)();
const uploadBase = (process.env.UPLOAD_ROOT
    ? require('path').isAbsolute(process.env.UPLOAD_ROOT)
        ? process.env.UPLOAD_ROOT
        : `${process.cwd()}${process.env.UPLOAD_ROOT}`
    : `${process.cwd()}${FileEnum_1.FileEnum.PUBLICDIR}`);
const upload = (0, fileUpload_1.createMulterInstance)(`${uploadBase}${FileEnum_1.FileEnum.PROFILEIMAGE}`);
user.post("/fcm-token", Middlewares_1.Auth, Controllers_1.UsersControllers.updateFcmToken);
user.post("/hasPhotoSkipped", Middlewares_1.Auth, Controllers_1.UsersControllers.isUserPhotoSkipped);
user.get("/file-download/:id", Middlewares_1.Auth, Controllers_1.UsersControllers.downloadDocument);
user.get("/files/:id", Controllers_1.UsersControllers.getFile);
user.get("/find", Controllers_1.UsersControllers.findUserByUserName);
user.post("/file-upload", upload.single("file"), Controllers_1.UsersControllers.fileUpload);
user.post("/", Middlewares_1.OnlyAdmins, upload.single("image"), Controllers_1.UsersControllers.create);
user.get;
user.post("/account", Middlewares_1.Auth, Controllers_1.UsersControllers.onboardUser);
user.get("/user-name-availability", Middlewares_1.Auth, Controllers_1.UsersControllers.checkUsernameAvailability);
user.get("/", Middlewares_1.Auth, Controllers_1.UsersControllers.index);
user.get("/:id", Controllers_1.UsersControllers.show);
user.post("/:id", Middlewares_1.OnlyAdmins, upload.single("image"), Controllers_1.UsersControllers.update);
user.delete("/:id", Middlewares_1.OnlyAdmins, Controllers_1.UsersControllers.destroy);
user.delete("/file-remove/:id", Middlewares_1.Auth, Controllers_1.UsersControllers.deleteFile);
user.patch("/:id/make-it-free", Middlewares_1.OnlyAdmins, Controllers_1.UsersControllers.makeUserSubscriptionActive);
user.put("/:id/status", Middlewares_1.OnlyAdmins, Controllers_1.UsersControllers.updateUserStatus);
user.post('/profile-picture', passport_1.default.authenticate('jwt', { session: false }), updateProfilePicture_1.updateProfilePicture);
exports.default = user;
//# sourceMappingURL=user.routes.js.map