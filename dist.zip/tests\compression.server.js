"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTestApp = createTestApp;
const express_1 = __importDefault(require("express"));
const compression_1 = __importDefault(require("compression"));
function createTestApp() {
    const app = (0, express_1.default)();
    app.use((0, compression_1.default)());
    // send a large enough payload to benefit from gzip
    const payload = 'x'.repeat(5000);
    app.get('/big', (_req, res) => {
        res.type('text/plain').send(payload);
    });
    return app;
}
//# sourceMappingURL=compression.server.js.map