"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.httpLogger = void 0;
exports.withRequestId = withRequestId;
const uuid_1 = require("uuid");
const pino_http_1 = __importDefault(require("pino-http"));
function withRequestId(req, _res, next) {
    req.id = req.id || (0, uuid_1.v4)();
    next();
}
exports.httpLogger = (0, pino_http_1.default)({ genReqId: (req) => req.id, autoLogging: { ignore: (req) => { var _a; return (_a = req.url) === null || _a === void 0 ? void 0 : _a.includes('/health'); } } });
//# sourceMappingURL=logging.js.map