"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default_user_pfp = exports.default_user_cover = void 0;
exports.default_user_cover = "66cd7d71dbab6ec1ca717231";
exports.default_user_pfp = "66cd7d1bdbab6ec1ca71722f";
//# sourceMappingURL=DefaultUserImages.js.map