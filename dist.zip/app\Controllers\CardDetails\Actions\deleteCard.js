"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCard = void 0;
const CardDetails_1 = require("../../../Models/CardDetails");
// import stripeInstance from "../../../../utils/stripe";
const deleteCard = async (req, res) => {
    try {
        const user = req.user;
        const { cardId } = req.params;
        if (!user) {
            return res.status(404).json({ error: { message: "User not found." } });
        }
        if (!cardId) {
            return res
                .status(400)
                .json({ error: { message: "Card ID is required." } });
        }
        const card = await CardDetails_1.cardDetails.findOne({
            _id: cardId,
            userId: user._id,
            isDeleted: false,
        });
        // const customerSource = await stripeInstance.customers.deleteSource(
        //   user.stripeClientId,
        //   card.stripeCardId
        // );
        if (card) {
            card.isDeleted = true;
            card.deletedAt = new Date();
            await card.save();
            return res.json({ message: "Card deleted successfully." });
        }
        else {
            return res.status(404).json({
                error: {
                    message: "Card not found or you do not have permission to delete this card.",
                },
            });
        }
    }
    catch (error) {
        console.error(error, "Error in deleting card");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.deleteCard = deleteCard;
//# sourceMappingURL=deleteCard.js.map