"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyDocument = void 0;
const Document_1 = require("../../../Models/Document");
const User_1 = require("../../../Models/User");
const DocumentStatusEnum_1 = require("../../../../types/DocumentStatusEnum");
const verifyDocument = async (req, res) => {
    const { id } = req.params;
    const adminUser = req.user;
    const document = await Document_1.Document.findById(id);
    if (!document) {
        return res.status(400).json({ error: { message: "No Document found" } });
    }
    try {
        const data = await Document_1.Document.findByIdAndUpdate(id, {
            verifiedBy: id,
            verifiedAt: new Date(),
            status: DocumentStatusEnum_1.DocumentStatusEnum.Approved,
        }, {
            new: true,
        });
        const user = await User_1.User.findById(data === null || data === void 0 ? void 0 : data.userId);
        if (user) {
            await User_1.User.findByIdAndUpdate(user.id, {
                verifiedBy: adminUser.id,
                verifiedAt: new Date(),
                hasDocumentVerified: true
            });
        }
        return res.json({ data: data, message: "User verified successfully." });
    }
    catch (err) {
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.verifyDocument = verifyDocument;
//# sourceMappingURL=verifyDocumentAction.js.map