"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInterest = void 0;
const class_validator_1 = require("class-validator");
const crypto_1 = __importDefault(require("crypto"));
const Interest_1 = require("../../../Models/Interest");
const generateRandomSlug = (length = 8) => {
    return crypto_1.default.randomBytes(length).toString("hex");
};
const createInterest = async (req, res) => {
    try {
        const validationErrors = await (0, class_validator_1.validate)(req.body);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        const addedBy = req.user;
        const slug = generateRandomSlug();
        const existingInterest = await Interest_1.Interest.findOne({
            title: req.body.title,
            isDeleted: false,
        });
        if (existingInterest) {
            return res
                .status(400)
                .json({
                error: {
                    message: "This interest has already been added by you or some other admin.",
                },
            });
        }
        const newInterest = new Interest_1.Interest({
            ...req.body,
            addedBy: addedBy.id,
            slug: slug,
        });
        await newInterest.save();
        return res.json({
            data: newInterest,
            message: "Interest added successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error in creating a interest");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.createInterest = createInterest;
//# sourceMappingURL=createInterestAction.js.map