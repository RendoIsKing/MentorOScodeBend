"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateProfilePicture = void 0;
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const User_1 = require("../../app/Models/User");
// Set up multer for file uploads
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/profile-pictures/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path_1.default.extname(file.originalname)); // Append extension
    },
});
const upload = (0, multer_1.default)({ storage });
exports.updateProfilePicture = [
    // Multer middleware for file handling
    upload.single('profilePicture'),
    // Controller logic
    async (req, res) => {
        var _a;
        try {
            const userId = (_a = req.user) === null || _a === void 0 ? void 0 : _a.id; // Assuming user id is available in req.user.id
            // Update user's profile picture URL in the database
            const user = await User_1.User.findById(userId);
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }
            if (req.file) {
                user.profilePictureUrl = `/uploads/profile-pictures/${req.file.filename}`;
                await user.save();
                // Return success message and the new picture URL
                return res.json({
                    message: 'Profile picture updated successfully',
                    profilePictureUrl: user.profilePictureUrl,
                });
            }
            else {
                return res.status(400).json({ error: 'No file uploaded' });
            }
        }
        catch (error) {
            console.error('Error updating profile picture:', error);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
    },
];
//# sourceMappingURL=updateProfilePicture.js.map