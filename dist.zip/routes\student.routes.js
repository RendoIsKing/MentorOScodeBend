"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const zod_1 = require("zod");
const Middlewares_1 = require("../app/Middlewares");
const rateLimiters_1 = require("../app/Middlewares/rateLimiters");
const WeightEntry_1 = require("../app/Models/WeightEntry");
const mongoose_1 = require("mongoose");
const PlanModels_1 = require("../app/Models/PlanModels");
const ChangeEvent_1 = __importDefault(require("../models/ChangeEvent"));
const publish_1 = require("../services/events/publish");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const ExerciseProgress_1 = require("../app/Models/ExerciseProgress");
const WorkoutLog_1 = __importDefault(require("../models/WorkoutLog"));
const StudentRoutes = (0, express_1.Router)();
// Recent changes endpoint
// Only match real ObjectId userIds so '/me/changes' doesn't get captured here
StudentRoutes.get('/:userId([0-9a-fA-F]{24})/changes', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    try {
        const { userId } = req.params;
        const limRaw = req.query.limit || '10';
        const limit = Math.max(1, Math.min(50, Number(limRaw) || 10));
        if (!mongoose_1.Types.ObjectId.isValid(userId))
            return res.status(400).json({ message: 'Bad userId' });
        const items = await ChangeEvent_1.default.find({ user: new mongoose_1.Types.ObjectId(userId) }).sort({ createdAt: -1 }).limit(limit).lean();
        return res.json({ items: items.map((c) => ({
                id: String(c._id),
                date: c.createdAt,
                type: c.type,
                summary: c.summary,
                rationale: c.rationale,
                actor: c.actor ? String(c.actor) : undefined,
                before: c.before,
                after: c.after,
            })) });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to load changes' });
    }
});
// Resolve current user's changes via cookie/JWT for convenience
StudentRoutes.get('/me/changes', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    var _a, _b;
    try {
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        const limRaw = req.query.limit || '10';
        const limit = Math.max(1, Math.min(50, Number(limRaw) || 10));
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
            // Be permissive for UI: return an empty list instead of error
            return res.json({ items: [] });
        }
        const items = await ChangeEvent_1.default.find({ user: new mongoose_1.Types.ObjectId(resolvedUserId) }).sort({ createdAt: -1 }).limit(limit).lean();
        return res.json({ items: items.map((c) => ({ id: String(c._id), date: c.createdAt, type: c.type, summary: c.summary, rationale: c.rationale, actor: c.actor ? String(c.actor) : undefined, before: c.before, after: c.after })) });
    }
    catch {
        return res.status(500).json({ message: 'Failed to load changes' });
    }
});
// Zod schemas for validation
const NonEmptyString = zod_1.z.string().trim().min(1);
const IsoDate = zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const WeightLogSchema = zod_1.z.object({ date: IsoDate, kg: zod_1.z.number().min(30).max(400) });
const ExerciseProgressSchema = zod_1.z.object({ exercise: NonEmptyString, date: IsoDate, value: zod_1.z.number() });
function generateDates(period) {
    const today = new Date();
    if (period === '7d') {
        return Array.from({ length: 7 }).map((_, i) => {
            const d = new Date(today);
            d.setDate(today.getDate() - (6 - i));
            return d.toISOString().slice(0, 10);
        });
    }
    if (period === '30d') {
        return Array.from({ length: 30 }).map((_, i) => {
            const d = new Date(today);
            d.setDate(today.getDate() - (29 - i));
            return d.toISOString().slice(0, 10);
        });
    }
    if (period === '90d') {
        return Array.from({ length: 90 }).map((_, i) => {
            const d = new Date(today);
            d.setDate(today.getDate() - (89 - i));
            return d.toISOString().slice(0, 10);
        });
    }
    const startOfYear = new Date(today.getFullYear(), 0, 1);
    const daysSince = Math.floor((today.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24));
    return Array.from({ length: daysSince + 1 }).map((_, i) => {
        const d = new Date(startOfYear);
        d.setDate(startOfYear.getDate() + i);
        return d.toISOString().slice(0, 10);
    });
}
StudentRoutes.get('/:userId/snapshot', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a, _b, _c, _d;
    try {
        let { userId } = req.params;
        const period = req.query.period || '30d';
        const days = generateDates(period);
        const today = new Date();
        // Pull actual weights for selected period using date range
        let dbWeights = [];
        try {
            let resolvedUserId = mongoose_1.Types.ObjectId.isValid(userId) ? userId : (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
            if (!resolvedUserId) {
                const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
                const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
                if (match) {
                    try {
                        const token = decodeURIComponent(match[1]);
                        const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                        const decoded = jsonwebtoken_1.default.verify(token, secret);
                        resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                    }
                    catch { }
                }
            }
            if (resolvedUserId && mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
                const start = days[0];
                const end = days[days.length - 1];
                const entries = await WeightEntry_1.WeightEntry.find({
                    userId: new mongoose_1.Types.ObjectId(resolvedUserId),
                    date: { $gte: start, $lte: end },
                })
                    .select('date kg -_id')
                    .lean();
                dbWeights = entries;
            }
        }
        catch { }
        const merged = days.map(d => dbWeights.find(w => w.date === d)).filter(Boolean);
        // Read current plans/goals
        let resolvedUserIdForPlans = mongoose_1.Types.ObjectId.isValid(userId) ? userId : (_c = req === null || req === void 0 ? void 0 : req.user) === null || _c === void 0 ? void 0 : _c._id;
        if (!resolvedUserIdForPlans) {
            const cookie = (_d = req.headers) === null || _d === void 0 ? void 0 : _d.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserIdForPlans = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        let currentTraining = resolvedUserIdForPlans && mongoose_1.Types.ObjectId.isValid(resolvedUserIdForPlans)
            ? await PlanModels_1.TrainingPlan.findOne({ userId: resolvedUserIdForPlans, isCurrent: true }).sort({ version: -1 }).lean()
            : null;
        let currentNutrition = resolvedUserIdForPlans && mongoose_1.Types.ObjectId.isValid(resolvedUserIdForPlans)
            ? await PlanModels_1.NutritionPlan.findOne({ userId: resolvedUserIdForPlans, isCurrent: true }).sort({ version: -1 }).lean()
            : null;
        const changes = resolvedUserIdForPlans && mongoose_1.Types.ObjectId.isValid(resolvedUserIdForPlans)
            ? await ChangeEvent_1.default.find({ user: new mongoose_1.Types.ObjectId(resolvedUserIdForPlans) }).sort({ createdAt: -1 }).limit(10).lean()
            : [];
        const trainingSessions = ((currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining.sessions) || []).map((s, idx) => ({
            id: String(currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining._id),
            index: idx,
            date: today.toISOString(),
            day: s.day,
            focus: s.focus || `Økt ${idx + 1}`,
            sets: (s.exercises || []).map((e) => ({ exercise: e.name, sets: e.sets, reps: e.reps, weight: e.load })),
            guidelines: (currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining.guidelines) || [],
            sourceText: (currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining.sourceText) || undefined,
        }));
        const payload = {
            weightTrend: merged,
            currentTrainingPlan: trainingSessions,
            currentNutritionPlan: currentNutrition ? [
                {
                    id: String(currentNutrition._id),
                    date: today.toISOString().slice(0, 10),
                    dailyTargets: currentNutrition.dailyTargets,
                    meals: currentNutrition.meals || [],
                    days: currentNutrition.days || [],
                    guidelines: currentNutrition.guidelines || [],
                    sourceText: currentNutrition.sourceText || undefined,
                },
            ] : [],
            planChanges: changes.map((c) => ({ id: String(c._id), date: c.createdAt, author: 'coach-engh', area: c.area, summary: c.summary })),
            glance: {
                nextSession: { date: today.toISOString(), focus: 'Pull — rygg/biceps' },
                adherence7d: 0.86,
                adherence28d: 0.78,
                lastCheckIn: today.toISOString(),
                activeGoals: ['-3kg på 6 uker', 'Øke 5RM markløft'],
            },
            topExercises: ['Markløft', 'Knebøy', 'Benkpress', 'Roing', 'Pull‑ups'],
        };
        try {
            if (resolvedUserIdForPlans && mongoose_1.Types.ObjectId.isValid(resolvedUserIdForPlans)) {
                const currentGoal = await PlanModels_1.Goal.findOne({ userId: resolvedUserIdForPlans, isCurrent: true }).sort({ version: -1 }).lean();
                if (currentGoal) {
                    const goals = [];
                    if (currentGoal.targetWeightKg)
                        goals.push(`Vektmål: ${currentGoal.targetWeightKg} kg`);
                    if (currentGoal.strengthTargets)
                        goals.push(`Styrke: ${currentGoal.strengthTargets}`);
                    if (currentGoal.horizonWeeks)
                        goals.push(`Horisont: ${currentGoal.horizonWeeks} uker`);
                    // @ts-ignore
                    payload.goals = goals.length ? goals : undefined;
                    // @ts-ignore
                    if (goals.length)
                        payload.glance.activeGoals = goals;
                    // expose structured goal for plans/goals page
                    // @ts-ignore
                    payload.currentGoal = currentGoal;
                }
            }
        }
        catch { }
        res.status(200).json(payload);
    }
    catch (err) {
        res.status(500).json({ message: 'Failed to load student snapshot' });
    }
});
// Convenience route: resolve userId from cookie/JWT and return snapshot
StudentRoutes.get('/me/snapshot', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a, _b;
    try {
        // Resolve user id
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        const period = req.query.period || '30d';
        const days = generateDates(period);
        const today = new Date();
        // weights
        let dbWeights = [];
        try {
            const start = days[0];
            const end = days[days.length - 1];
            const entries = await WeightEntry_1.WeightEntry.find({
                userId: new mongoose_1.Types.ObjectId(resolvedUserId),
                date: { $gte: start, $lte: end },
            })
                .select('date kg -_id')
                .lean();
            dbWeights = entries;
        }
        catch { }
        const merged = days.map((d) => dbWeights.find((w) => w.date === d)).filter(Boolean);
        // plans/goals
        const currentTraining = await PlanModels_1.TrainingPlan.findOne({ userId: resolvedUserId, isCurrent: true })
            .sort({ version: -1 })
            .lean();
        const currentNutrition = await PlanModels_1.NutritionPlan.findOne({ userId: resolvedUserId, isCurrent: true })
            .sort({ version: -1 })
            .lean();
        const changes = await ChangeEvent_1.default.find({ user: new mongoose_1.Types.ObjectId(resolvedUserId) }).sort({ createdAt: -1 }).limit(10).lean();
        const trainingSessions = ((currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining.sessions) || []).map((s, idx) => ({
            id: String(currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining._id),
            index: idx,
            date: today.toISOString(),
            day: s.day,
            focus: s.focus || `Økt ${idx + 1}`,
            sets: (s.exercises || []).map((e) => ({ exercise: e.name, sets: e.sets, reps: e.reps, weight: e.load })),
            guidelines: (currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining.guidelines) || [],
            sourceText: (currentTraining === null || currentTraining === void 0 ? void 0 : currentTraining.sourceText) || undefined,
        }));
        const payload = {
            weightTrend: merged,
            currentTrainingPlan: trainingSessions,
            currentNutritionPlan: currentNutrition
                ? [
                    {
                        id: String(currentNutrition._id),
                        date: today.toISOString().slice(0, 10),
                        dailyTargets: currentNutrition.dailyTargets,
                        meals: currentNutrition.meals || [],
                        days: currentNutrition.days || [],
                        guidelines: currentNutrition.guidelines || [],
                        sourceText: currentNutrition.sourceText || undefined,
                    },
                ]
                : [],
            planChanges: changes.map((c) => ({ id: String(c._id), date: c.createdAt, author: String(c.actor || 'coach-engh'), area: c.type.includes('NUTRITION') ? 'nutrition' : (c.type.includes('PLAN') ? 'training' : 'other'), summary: c.summary })),
            glance: {
                nextSession: { date: today.toISOString(), focus: 'Pull — rygg/biceps' },
                adherence7d: 0.86,
                adherence28d: 0.78,
                lastCheckIn: today.toISOString(),
                activeGoals: [],
            },
            topExercises: ['Markløft', 'Knebøy', 'Benkpress', 'Roing', 'Pull‑ups'],
        };
        try {
            const currentGoal = await PlanModels_1.Goal.findOne({ userId: resolvedUserId, isCurrent: true })
                .sort({ version: -1 })
                .lean();
            if (currentGoal) {
                const goals = [];
                if (currentGoal.targetWeightKg)
                    goals.push(`Vektmål: ${currentGoal.targetWeightKg} kg`);
                if (currentGoal.strengthTargets)
                    goals.push(`Styrke: ${currentGoal.strengthTargets}`);
                if (currentGoal.horizonWeeks)
                    goals.push(`Horisont: ${currentGoal.horizonWeeks} uker`);
                payload.goals = goals.length ? goals : undefined;
                if (goals.length)
                    payload.glance.activeGoals = goals;
            }
        }
        catch { }
        return res.json(payload);
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to load snapshot' });
    }
});
StudentRoutes.get('/:userId([0-9a-fA-F]{24})/exercise-progress', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    try {
        const period = req.query.period || '30d';
        const exercise = req.query.exercise || '';
        const { userId } = req.params;
        if (!mongoose_1.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Bad userId' });
        }
        const days = generateDates(period);
        const start = days[0];
        const end = days[days.length - 1];
        const series = await ExerciseProgress_1.ExerciseProgress.find({
            userId: new mongoose_1.Types.ObjectId(userId),
            exercise: exercise || { $exists: true },
            date: { $gte: start, $lte: end },
        }).select('date value -_id').sort({ date: 1 }).lean();
        return res.status(200).json({ series, exercise });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to load exercise progress' });
    }
});
// /me exercise-progress variants resolve user from cookie/JWT like snapshot
StudentRoutes.get('/me/exercise-progress', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    var _a, _b;
    try {
        // resolve user id from cookie/JWT
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        const period = req.query.period || '30d';
        const exercise = req.query.exercise || '';
        const days = generateDates(period);
        const start = days[0];
        const end = days[days.length - 1];
        const series = await ExerciseProgress_1.ExerciseProgress.find({
            userId: new mongoose_1.Types.ObjectId(resolvedUserId),
            exercise: exercise || { $exists: true },
            date: { $gte: start, $lte: end },
        }).select('date value -_id').sort({ date: 1 }).lean();
        return res.status(200).json({ series, exercise });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to load exercise progress' });
    }
});
StudentRoutes.post('/me/exercise-progress', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a, _b;
    try {
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        const parsed = ExerciseProgressSchema.safeParse(req.body || {});
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        if (!parsed.success)
            return res.status(422).json({ message: 'validation_failed', details: parsed.error.flatten() });
        const { exercise, date, value } = parsed.data;
        await ExerciseProgress_1.ExerciseProgress.updateOne({ userId: new mongoose_1.Types.ObjectId(resolvedUserId), exercise, date }, { $set: { value } }, { upsert: true });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to add exercise progress' });
    }
});
StudentRoutes.put('/me/exercise-progress', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a, _b;
    try {
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        const parsed = ExerciseProgressSchema.safeParse(req.body || {});
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        if (!parsed.success)
            return res.status(422).json({ message: 'validation_failed', details: parsed.error.flatten() });
        const { exercise, date, value } = parsed.data;
        await ExerciseProgress_1.ExerciseProgress.updateOne({ userId: new mongoose_1.Types.ObjectId(resolvedUserId), exercise, date }, { $set: { value } }, { upsert: true });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to update exercise progress' });
    }
});
StudentRoutes.delete('/me/exercise-progress', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a, _b;
    try {
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        const exercise = req.query.exercise;
        const date = req.query.date;
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId) || !exercise || !date) {
            return res.status(400).json({ message: 'exercise and date query params required' });
        }
        await ExerciseProgress_1.ExerciseProgress.deleteOne({ userId: new mongoose_1.Types.ObjectId(resolvedUserId), exercise, date });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to delete exercise progress' });
    }
});
// Minimal weight check-in endpoint (placeholder for real persistence)
StudentRoutes.post('/:userId/weights', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a;
    try {
        const { userId } = req.params;
        const parsed = WeightLogSchema.safeParse(req.body || {});
        if (!mongoose_1.Types.ObjectId.isValid(userId))
            return res.status(400).json({ message: 'Bad userId' });
        if (!parsed.success)
            return res.status(422).json({ message: 'validation_failed', details: parsed.error.flatten() });
        const { date, kg } = parsed.data;
        // basic validation: ISO date not in future
        const todayIso = new Date().toISOString().slice(0, 10);
        if (date > todayIso) {
            return res.status(400).json({ message: 'date cannot be in the future' });
        }
        await WeightEntry_1.WeightEntry.updateOne({ userId: new mongoose_1.Types.ObjectId(userId), date }, { $set: { kg } }, { upsert: true });
        try {
            await ChangeEvent_1.default.create({ user: new mongoose_1.Types.ObjectId(userId), type: "WEIGHT_LOG", summary: `Weight ${kg}kg on ${date}`, actor: (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id, after: { date, kg } });
            await (0, publish_1.publish)({ type: "WEIGHT_LOGGED", user: new mongoose_1.Types.ObjectId(userId), date, kg });
        }
        catch { }
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to record weight' });
    }
});
// Update a weight entry (upsert) for a given date
StudentRoutes.put('/:userId/weights', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    var _a;
    try {
        const { userId } = req.params;
        const parsed = WeightLogSchema.safeParse(req.body || {});
        if (!mongoose_1.Types.ObjectId.isValid(userId))
            return res.status(400).json({ message: 'Bad userId' });
        if (!parsed.success)
            return res.status(422).json({ message: 'validation_failed', details: parsed.error.flatten() });
        const { date, kg } = parsed.data;
        const todayIso = new Date().toISOString().slice(0, 10);
        if (date > todayIso) {
            return res.status(400).json({ message: 'date cannot be in the future' });
        }
        await WeightEntry_1.WeightEntry.updateOne({ userId: new mongoose_1.Types.ObjectId(userId), date }, { $set: { kg } }, { upsert: true });
        try {
            await ChangeEvent_1.default.create({ user: new mongoose_1.Types.ObjectId(userId), type: "WEIGHT_LOG", summary: `Weight updated to ${kg}kg on ${date}`, actor: (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id, after: { date, kg } });
            await (0, publish_1.publish)({ type: "WEIGHT_LOGGED", user: new mongoose_1.Types.ObjectId(userId), date, kg });
        }
        catch { }
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to update weight' });
    }
});
// Delete a weight entry by date
StudentRoutes.delete('/:userId/weights', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), async (req, res) => {
    try {
        const date = req.query.date;
        const { userId } = req.params;
        if (!date || !mongoose_1.Types.ObjectId.isValid(userId))
            return res.status(400).json({ message: 'date query param is required' });
        await WeightEntry_1.WeightEntry.deleteOne({ userId: new mongoose_1.Types.ObjectId(userId), date });
        try {
            await ChangeEvent_1.default.create({ user: new mongoose_1.Types.ObjectId(userId), type: "WEIGHT_LOG", summary: `Weight entry deleted for ${date}` });
            await (0, publish_1.publish)({ type: "WEIGHT_DELETED", user: new mongoose_1.Types.ObjectId(userId), date });
        }
        catch { }
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to delete weight' });
    }
});
// Create exercise progress entry
StudentRoutes.post('/:userId([0-9a-fA-F]{24})/exercise-progress', async (req, res) => {
    try {
        const { userId } = req.params;
        const { exercise, date, value } = req.body || {};
        if (!mongoose_1.Types.ObjectId.isValid(userId) || !exercise || !date || typeof value !== 'number') {
            return res.status(400).json({ message: 'exercise, date, value required' });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
            return res.status(400).json({ message: 'date must be YYYY-MM-DD' });
        await ExerciseProgress_1.ExerciseProgress.updateOne({ userId: new mongoose_1.Types.ObjectId(userId), exercise, date }, { $set: { value } }, { upsert: true });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to add exercise progress' });
    }
});
// Update exercise progress entry
StudentRoutes.put('/:userId([0-9a-fA-F]{24})/exercise-progress', async (req, res) => {
    try {
        const { userId } = req.params;
        const { exercise, date, value } = req.body || {};
        if (!mongoose_1.Types.ObjectId.isValid(userId) || !exercise || !date || typeof value !== 'number') {
            return res.status(400).json({ message: 'exercise, date, value required' });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
            return res.status(400).json({ message: 'date must be YYYY-MM-DD' });
        await ExerciseProgress_1.ExerciseProgress.updateOne({ userId: new mongoose_1.Types.ObjectId(userId), exercise, date }, { $set: { value } }, { upsert: true });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to update exercise progress' });
    }
});
// Delete exercise progress entry
StudentRoutes.delete('/:userId([0-9a-fA-F]{24})/exercise-progress', async (req, res) => {
    try {
        const { userId } = req.params;
        const exercise = req.query.exercise;
        const date = req.query.date;
        if (!mongoose_1.Types.ObjectId.isValid(userId) || !exercise || !date) {
            return res.status(400).json({ message: 'exercise and date query params required' });
        }
        await ExerciseProgress_1.ExerciseProgress.deleteOne({ userId: new mongoose_1.Types.ObjectId(userId), exercise, date });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to delete exercise progress' });
    }
});
// Log a workout day (mark done today or specific date)
StudentRoutes.post('/me/workouts', async (req, res) => {
    var _a, _b, _c;
    try {
        // resolve user id from cookie/JWT
        let resolvedUserId = (_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id;
        if (!resolvedUserId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    resolvedUserId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!resolvedUserId || !mongoose_1.Types.ObjectId.isValid(resolvedUserId)) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        const date = ((_c = req.body) === null || _c === void 0 ? void 0 : _c.date) || new Date().toISOString().slice(0, 10);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date))
            return res.status(400).json({ message: 'date must be YYYY-MM-DD' });
        await WorkoutLog_1.default.updateOne({ user: new mongoose_1.Types.ObjectId(resolvedUserId), date }, { $setOnInsert: { entries: [] } }, { upsert: true });
        await (0, publish_1.publish)({ type: 'WORKOUT_LOGGED', user: new mongoose_1.Types.ObjectId(resolvedUserId), date });
        return res.status(200).json({ ok: true });
    }
    catch (err) {
        return res.status(500).json({ message: 'Failed to log workout' });
    }
});
exports.default = StudentRoutes;
//# sourceMappingURL=student.routes.js.map