"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const class_validator_1 = require("class-validator");
const passport_1 = __importDefault(require("passport"));
const bcryptjs_1 = require("bcryptjs");
const date_fns_1 = require("date-fns");
const Register_input_1 = require("../Inputs/Register.input");
const User_1 = require("../Models/User");
const Subscription_1 = require("../Models/Subscription");
const Login_input_1 = require("../Inputs/Login.input");
const jwt_1 = require("../../utils/jwt");
const RolesEnum_1 = require("../../types/RolesEnum");
const checkUser_input_1 = require("../Inputs/checkUser.input");
// import { UserLoginDto } from "../Inputs/UserLogin.input";
const class_transformer_1 = require("class-transformer");
const date_fns_2 = require("date-fns");
const otpGenerator_1 = __importDefault(require("../../utils/otpGenerator"));
const OTPInput_1 = require("../Inputs/OTPInput");
// import { Collection } from "../Models/Collection";
// import { SubscriptionPlan } from "../Models/SubscriptionPlan";
const UpdateUser_input_1 = require("../Inputs/UpdateUser.input");
const UserForgotPassword_input_1 = require("../Inputs/UserForgotPassword.input");
const mongoose_1 = __importDefault(require("mongoose"));
// import jwt from "jsonwebtoken";
const subscriptionPlanEnum_1 = require("../../types/enums/subscriptionPlanEnum");
const InteractionTypeEnum_1 = require("../../types/enums/InteractionTypeEnum");
const postTypeEnum_1 = require("../../types/enums/postTypeEnum");
const SubscriptionStatusEnum_1 = require("../../types/enums/SubscriptionStatusEnum");
const sendMessage_1 = require("../../utils/Twillio/sendMessage");
const google_auth_library_1 = require("google-auth-library");
class AuthController {
}
exports.AuthController = AuthController;
_a = AuthController;
AuthController.googleLogin = async (req, res) => {
    var _b, _c;
    try {
        const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
        if (!clientId)
            return res.status(500).json({ message: "GOOGLE_OAUTH_CLIENT_ID missing" });
        const { idToken } = (req.body || {});
        if (!idToken)
            return res.status(400).json({ message: "idToken required" });
        const client = new google_auth_library_1.OAuth2Client(clientId);
        const ticket = await client.verifyIdToken({ idToken, audience: clientId });
        const payload = ticket.getPayload();
        if (!payload || !payload.sub || !payload.email) {
            return res.status(401).json({ message: "Invalid Google token" });
        }
        const googleId = payload.sub;
        const email = String(payload.email).toLowerCase();
        let user = await User_1.User.findOne({ $or: [{ googleId }, { email }] });
        let isNewUser = false;
        if (!user) {
            // Brand new Google user - needs onboarding
            user = await User_1.User.create({
                firstName: payload.given_name || "",
                lastName: payload.family_name || "",
                email,
                googleId,
                role: RolesEnum_1.RolesEnum.USER,
                isActive: true,
                isVerified: true,
            });
            isNewUser = true;
        }
        else if (!user.googleId) {
            // Existing email user linking Google
            user.googleId = googleId;
            await user.save();
        }
        // Check if user needs to complete onboarding (no userName set)
        if (!user.userName || user.userName.trim() === '') {
            isNewUser = true;
        }
        const token = (0, jwt_1.generateAuthToken)(user);
        try {
            const isProd = process.env.NODE_ENV === 'production';
            const sameSiteEnv = String(process.env.SESSION_SAMESITE || (isProd ? 'none' : 'lax')).toLowerCase();
            const cookieSameSite = (sameSiteEnv === 'none' ? 'none' : 'lax');
            const secureEnv = String(process.env.SESSION_SECURE || (isProd ? 'true' : 'false')).toLowerCase();
            const cookieSecure = secureEnv === 'true' || secureEnv === '1';
            const cookieDomain = (process.env.SESSION_COOKIE_DOMAIN || '').trim();
            const cookieOpts = { httpOnly: true, sameSite: cookieSameSite, secure: cookieSecure, maxAge: 1000 * 60 * 60 * 24 * 30, path: '/' };
            if (cookieDomain)
                cookieOpts.domain = cookieDomain;
            res.cookie('auth_token', token, cookieOpts);
        }
        catch { }
        return res.json({
            token,
            isNewUser,
            user: {
                id: user._id,
                email: user.email,
                name: `${(_b = user.firstName) !== null && _b !== void 0 ? _b : ''} ${(_c = user.lastName) !== null && _c !== void 0 ? _c : ''}`.trim(),
                role: user.role,
            },
        });
    }
    catch (e) {
        const msg = (e === null || e === void 0 ? void 0 : e.message) || String(e);
        return res.status(401).json({ message: msg || 'Google login failed' });
    }
};
// NOTE: legacy misspelling kept for backward compatibility with any callers
AuthController.regsiter = async (req, res) => {
    const input = req.body;
    const registerInput = new Register_input_1.RegisterInput();
    registerInput.firstName = input.firstName;
    registerInput.lastName = input.lastName;
    registerInput.email = input.email;
    registerInput.phoneNumber = input.phoneNumber;
    registerInput.password = input.password;
    registerInput.dialCode = input.dialCode;
    registerInput.country = input.country;
    const errors = await (0, class_validator_1.validate)(registerInput);
    if (errors.length) {
        const errorsInfo = errors.map((error) => ({
            property: error.property,
            constraints: error.constraints,
        }));
        return res
            .status(400)
            .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
    }
    try {
        // const user = await User.findOne({phoneNumber: input.phoneNumber,email : input.email});
        const user = await User_1.User.findOne({
            $or: [
                { email: input.email },
                {
                    completePhoneNumber: `${input.country}--${input.dialCode}--${input.phoneNumber}`,
                },
            ],
        });
        if (!user) {
            const salt = (0, bcryptjs_1.genSaltSync)(10);
            const hashPassword = (0, bcryptjs_1.hashSync)(input.password, salt);
            await User_1.User.create({
                firstName: input.firstName,
                lastName: input.lastName,
                email: input.email,
                password: hashPassword,
                role: RolesEnum_1.RolesEnum.USER,
                phoneNumber: input.phoneNumber,
                country: input.country,
                dialCode: input.dialCode,
                completePhoneNumber: `${input.country}--${input.dialCode}--${input.phoneNumber}`,
                isActive: true, //need to delete
                isVerified: true, //need to delete
            });
            passport_1.default.authenticate("local", { session: false }, (err, user, message) => {
                if (!user) {
                    if (err) {
                        return res.status(400).json({ error: err });
                    }
                    return res.status(401).json({ error: message });
                }
                else if (!user.isActive) {
                    return res
                        .status(401)
                        .json({ error: "User not active.Please contact admin." });
                }
                else if (!user.isVerified) {
                    return res.status(401).json({
                        error: "User not verified.Please verify your account",
                    });
                }
                else if (user.isDeleted) {
                    return res
                        .status(401)
                        .json({ error: "User is deleted.Please contact admin" });
                }
                const token = (0, jwt_1.generateAuthToken)(user);
                try {
                    const isProd = process.env.NODE_ENV === 'production';
                    const sameSiteEnv = String(process.env.SESSION_SAMESITE || (isProd ? 'none' : 'lax')).toLowerCase();
                    const cookieSameSite = (sameSiteEnv === 'none' ? 'none' : 'lax');
                    const secureEnv = String(process.env.SESSION_SECURE || (isProd ? 'true' : 'false')).toLowerCase();
                    const cookieSecure = secureEnv === 'true' || secureEnv === '1';
                    const cookieDomain = (process.env.SESSION_COOKIE_DOMAIN || '').trim();
                    const cookieOpts = { httpOnly: true, sameSite: cookieSameSite, secure: cookieSecure, maxAge: 1000 * 60 * 60 * 24 * 30, path: '/' };
                    if (cookieDomain)
                        cookieOpts.domain = cookieDomain;
                    res.cookie('auth_token', token, cookieOpts);
                }
                catch { }
                return res.json({
                    data: {
                        _id: user._id,
                        firstName: user.firstName,
                        lastName: user.lastName,
                        email: user.email,
                        role: user.role,
                        lastLogin: user.lastLogin,
                        image: user.photoId,
                        phoneNumber: user.phoneNumber,
                        country: user.country,
                        dialCode: user.dialCode,
                        token,
                    },
                });
            })(req, res);
        }
        else {
            return res.status(400).json({
                data: {
                    message: "User already exists with same email or phone number.",
                },
            });
        }
    }
    catch (error) {
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
AuthController.login = async (req, res) => {
    const input = req.body;
    const loginInput = new Login_input_1.LoginInput();
    loginInput.email = input.email;
    loginInput.password = input.password;
    const errors = await (0, class_validator_1.validate)(loginInput);
    if (errors.length) {
        const errorsInfo = errors.map((error) => ({
            property: error.property,
            constraints: error.constraints,
        }));
        return res.status(400).json({
            error: { message: "VALIDATIONS_ERROR", info: { errorsInfo } },
        });
    }
    return passport_1.default.authenticate("local", { session: false }, (err, user, message) => {
        if (!user) {
            if (err) {
                return res.status(400).json({ error: err });
            }
            return res.status(401).json({ error: message });
        }
        else if (!user.isActive) {
            return res
                .status(401)
                .json({ error: "User not active.Please contact admin." });
        }
        else if (!user.isVerified) {
            return res
                .status(401)
                .json({ error: "User not verified.Please verify your account" });
        }
        else if (user.isDeleted) {
            return res
                .status(401)
                .json({ error: "User is deleted.Please contact admin" });
        }
        const token = (0, jwt_1.generateAuthToken)(user);
        try {
            const isProd = process.env.NODE_ENV === 'production';
            const sameSiteEnv = String(process.env.SESSION_SAMESITE || (isProd ? 'none' : 'lax')).toLowerCase();
            const cookieSameSite = (sameSiteEnv === 'none' ? 'none' : 'lax');
            const secureEnv = String(process.env.SESSION_SECURE || (isProd ? 'true' : 'false')).toLowerCase();
            const cookieSecure = secureEnv === 'true' || secureEnv === '1';
            const cookieDomain = (process.env.SESSION_COOKIE_DOMAIN || '').trim();
            const cookieOpts = { httpOnly: true, sameSite: cookieSameSite, secure: cookieSecure, maxAge: 1000 * 60 * 60 * 24 * 30, path: '/' };
            if (cookieDomain)
                cookieOpts.domain = cookieDomain;
            res.cookie('auth_token', token, cookieOpts);
        }
        catch { }
        return res.json({
            data: {
                _id: user._id,
                firstName: user === null || user === void 0 ? void 0 : user.firstName,
                lastName: user === null || user === void 0 ? void 0 : user.lastName,
                email: user === null || user === void 0 ? void 0 : user.email,
                role: user === null || user === void 0 ? void 0 : user.role,
                lastLogin: user === null || user === void 0 ? void 0 : user.lastLogin,
                image: user === null || user === void 0 ? void 0 : user.photoId,
                phoneNumber: user === null || user === void 0 ? void 0 : user.phoneNumber,
                country: user === null || user === void 0 ? void 0 : user.country,
                dialCode: user === null || user === void 0 ? void 0 : user.dialCode,
                token,
            },
        });
    })(req, res);
};
AuthController.updateMe = async (req, res) => {
    var _b;
    try {
        const user = req.user;
        const updateData = (0, class_transformer_1.plainToClass)(UpdateUser_input_1.UpdateUserDTO, req.body);
        const errors = await (0, class_validator_1.validate)(updateData);
        if (errors.length > 0) {
            return res.status(400).json({ errors });
        }
        // If password change requested, require and verify currentPassword
        if (updateData.password) {
            const currentPassword = (_b = req.body) === null || _b === void 0 ? void 0 : _b.currentPassword;
            if (!currentPassword) {
                return res.status(400).json({ error: { message: "CURRENT_PASSWORD_REQUIRED" } });
            }
            // Fetch fresh user to compare hash
            const dbUser = await User_1.User.findById(user.id).select("password");
            if (!dbUser || !dbUser.password || !(0, bcryptjs_1.compareSync)(currentPassword, dbUser.password)) {
                return res.status(400).json({ error: { message: "CURRENT_PASSWORD_INVALID" } });
            }
            const salt = (0, bcryptjs_1.genSaltSync)(10);
            updateData.password = (0, bcryptjs_1.hashSync)(updateData.password, salt);
            // Do not log sensitive data
        }
        const updatedUser = await User_1.User.findByIdAndUpdate(user.id, updateData, {
            new: true,
        });
        if (updatedUser === null || updatedUser === void 0 ? void 0 : updatedUser.photoId) {
            updatedUser.hasPhotoInfo = true;
            await updatedUser.save();
        }
        if (!updatedUser) {
            return res.status(404).json({ error: "User not found" });
        }
        return res.json({
            data: updatedUser,
            message: "User updated successfully",
        });
    }
    catch (error) {
        console.error("Error in user Updation", error);
        return res.status(500).json({ error: "Something went wrong" });
    }
};
AuthController.userLogin = async (req, res) => {
    var _b, _c;
    try {
        const { email, username, phoneNumber, password, dialCode } = req.body || {};
        // Branch A: Phone-only initiation (no password) → generate OTP (signup/OTP login flow)
        if (!password && (phoneNumber || email || username)) {
            // Normalize phone from either "dial--num", "country--dial--num", or separate dialCode/phoneNumber
            let dial = '';
            let num = '';
            if (typeof phoneNumber === 'string' && phoneNumber.includes('--')) {
                const parts = phoneNumber.split('--');
                if (parts.length === 2) {
                    dial = String(parts[0] || '').replace(/^\+/, '').replace(/\s+/g, '');
                    num = String(parts[1] || '').replace(/\s+/g, '');
                }
                else if (parts.length === 3) {
                    dial = String(parts[1] || '').replace(/^\+/, '').replace(/\s+/g, '');
                    num = String(parts[2] || '').replace(/\s+/g, '');
                }
            }
            else if (phoneNumber && dialCode) {
                dial = String(dialCode || '').replace(/^\+/, '').replace(/\s+/g, '');
                num = String(phoneNumber || '').replace(/\s+/g, '');
            }
            if (!dial || !num) {
                return res.status(422).json({ message: 'dialCode and phoneNumber are required' });
            }
            // Find or create user by phone with atomic upsert
            const orQuery = [
                { completePhoneNumber: `${dial}--${num}` },
                { $and: [{ dialCode: dial }, { phoneNumber: num }] },
            ];
            const user = await User_1.User.findOneAndUpdate({ isDeleted: false, $or: orQuery }, {
                $setOnInsert: {
                    firstName: '',
                    lastName: '',
                    email: email || undefined,
                    dialCode: dial,
                    phoneNumber: num,
                    role: RolesEnum_1.RolesEnum.USER,
                    isActive: true,
                    isVerified: false,
                },
            }, { upsert: true, new: true });
            const otp = (0, otpGenerator_1.default)();
            const otpInvalidAt = (0, date_fns_2.addMinutes)(new Date(), 10);
            await User_1.User.findByIdAndUpdate(user._id, { otp: String(otp), otpInvalidAt });
            // Send OTP (dev: also return it in response for easy verification)
            try {
                await (0, sendMessage_1.sendMessage)(`${dial}--${num}`, `Your OTP is: ${otp}`);
            }
            catch (e) {
                // ignore SMS errors in dev
            }
            return res.status(200).json({
                data: { _id: user._id, dialCode: dial, phoneNumber: num, otp },
                message: 'OTP sent successfully',
            });
        }
        // Accept both formats: "<dialCode>--<number>" and "<country>--<dialCode>--<number>"
        const orClauses = [];
        if (email)
            orClauses.push({ email });
        if (username)
            orClauses.push({ userName: username });
        if (typeof phoneNumber === "string" && phoneNumber.includes("--")) {
            const esc = (s) => s.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&");
            const parts = phoneNumber.split("--");
            if (parts.length === 2) {
                const [rawDial, rawNum] = parts;
                const dial = String(rawDial || "").replace(/^\+/, "").replace(/\s+/g, "");
                const num = String(rawNum || "").replace(/\s+/g, "");
                // Try exact two-part match and a regex that matches stored three-part format
                orClauses.push({ completePhoneNumber: `${dial}--${num}` });
                orClauses.push({
                    completePhoneNumber: {
                        $regex: new RegExp(`^[A-Za-z]{2}--${esc(dial)}--${esc(num)}$`, "i"),
                    },
                });
                // Also allow direct match on separate fields
                orClauses.push({ $and: [{ dialCode: dial }, { phoneNumber: num }] });
            }
            else {
                // Already three-part; try exact match
                const [, rawDial3, rawNum3] = parts;
                const dial3 = String(rawDial3 || "").replace(/^\+/, "").replace(/\s+/g, "");
                const num3 = String(rawNum3 || "").replace(/\s+/g, "");
                orClauses.push({ completePhoneNumber: `${dial3}--${num3}` });
                orClauses.push({ $and: [{ dialCode: dial3 }, { phoneNumber: num3 }] });
            }
        }
        const user = await User_1.User.findOne({
            ...(orClauses.length ? { $or: orClauses } : {}),
            isDeleted: false,
        });
        if (!user || !user.password || !(0, bcryptjs_1.compareSync)(password, user.password)) {
            return res.status(400).json({ message: "Invalid login credentials" });
        }
        // @ts-ignore
        req.session.user = {
            id: user._id,
            email: user.email,
            role: user.role,
        };
        const token = (0, jwt_1.generateAuthToken)(user);
        // Set cookie to support endpoints that read from cookies (student/interaction routes)
        try {
            const isProd = process.env.NODE_ENV === 'production';
            const sameSiteEnv = String(process.env.SESSION_SAMESITE || (isProd ? 'none' : 'lax')).toLowerCase();
            const cookieSameSite = (sameSiteEnv === 'none' ? 'none' : 'lax');
            const secureEnv = String(process.env.SESSION_SECURE || (isProd ? 'true' : 'false')).toLowerCase();
            const cookieSecure = secureEnv === 'true' || secureEnv === '1';
            const cookieDomain = (process.env.SESSION_COOKIE_DOMAIN || '').trim();
            const cookieOpts = { httpOnly: true, sameSite: cookieSameSite, secure: cookieSecure, maxAge: 1000 * 60 * 60 * 24 * 30, path: '/' };
            if (cookieDomain)
                cookieOpts.domain = cookieDomain;
            res.cookie('auth_token', token, cookieOpts);
        }
        catch { }
        return res.json({
            message: "User login successfully",
            token,
            user: {
                id: user._id,
                name: `${(_b = user.firstName) !== null && _b !== void 0 ? _b : ''} ${(_c = user.lastName) !== null && _c !== void 0 ? _c : ''}`.trim(),
                email: user.email,
                role: user.role,
                userName: user.userName,
            },
        });
    }
    catch (error) {
        const msg = (error === null || error === void 0 ? void 0 : error.message) || String(error);
        console.error('[auth:user-login] failed', msg);
        // Always return the error message during debugging so we can see the exact cause
        return res.status(500).json({ message: msg });
    }
};
AuthController.checkUser = async (req, res) => {
    const input = req.body;
    const userInput = new checkUser_input_1.CheckUserInput();
    // userInput.phoneNumber = input.phoneNumber;
    // userInput.email = input.email;
    userInput.email = input.email;
    userInput.phoneNumber = input.phoneNumber;
    userInput.dialCode = input.dialCode;
    userInput.country = input.country;
    const errors = await (0, class_validator_1.validate)(userInput);
    if (errors.length) {
        const errorsInfo = errors.map((error) => ({
            property: error.property,
            constraints: error.constraints,
        }));
        return res.status(400).json({
            error: { message: "VALIDATIONS_ERROR", info: { errorsInfo } },
        });
    }
    const user = await User_1.User.findOne({
        $or: [
            { email: input.email },
            {
                completePhoneNumber: `${input.country}--${input.dialCode}--${input.phoneNumber}`,
            },
        ],
    });
    // const user = await User.findOne({phoneNumber: input.phoneNumber,email : input.email});
    if (user) {
        return res.json({ data: { message: "User exist." } });
    }
    else {
        return res
            .status(400)
            .json({ data: { message: "User does not exist." } });
    }
};
AuthController.verifyOtp = async (req, res) => {
    try {
        const { id, otp } = req.body;
        const otpInput = new OTPInput_1.OTPInput();
        otpInput.id = id;
        otpInput.otp = otp;
        const errors = await (0, class_validator_1.validate)(otpInput);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        const objectId = otpInput.id;
        const user = await User_1.User.findById(objectId);
        if (!user) {
            return res.status(400).json({ error: { message: "User not found" } });
        }
        //   if (user?.isVerified) {
        //     return res
        //       .status(400)
        //       .json({ error: { message: "User already verified" } });
        //   }
        if (user.otp != otp || (0, date_fns_1.compareAsc)(new Date(), user.otpInvalidAt) === 1) {
            return res.status(400).json({ data: { message: "otp is invalid" } });
        }
        const updatedUser = (await User_1.User.findByIdAndUpdate(objectId, { isVerified: true, verifiedAt: new Date(), otp: "" }, { new: true }));
        const token = await (0, jwt_1.generateAuthToken)(updatedUser);
        // Set auth cookie so subsequent cross-site requests include credentials
        try {
            const isProd = process.env.NODE_ENV === 'production';
            const sameSiteEnv = String(process.env.SESSION_SAMESITE || (isProd ? 'none' : 'lax')).toLowerCase();
            const cookieSameSite = (sameSiteEnv === 'none' ? 'none' : 'lax');
            const secureEnv = String(process.env.SESSION_SECURE || (isProd ? 'true' : 'false')).toLowerCase();
            const cookieSecure = secureEnv === 'true' || secureEnv === '1';
            const cookieDomain = (process.env.SESSION_COOKIE_DOMAIN || '').trim();
            const cookieOpts = {
                httpOnly: true,
                sameSite: cookieSameSite,
                secure: cookieSecure,
                maxAge: 1000 * 60 * 60 * 24 * 30,
                path: '/',
            };
            if (cookieDomain)
                cookieOpts.domain = cookieDomain;
            res.cookie('auth_token', token, cookieOpts);
        }
        catch { }
        return res.json({
            data: {
                ...updatedUser.toObject(),
                token,
            },
            message: "User verified succesfully",
        });
    }
    catch (error) {
        return res
            .status(500)
            .json({ error: { message: "Something went wrong" } });
    }
};
AuthController.me = async (req, res) => {
    var _b, _c, _d, _e, _f;
    const user = req.user;
    try {
        if (!(user === null || user === void 0 ? void 0 : user.id)) {
            return res.status(401).json({ error: { message: "Unauthorized" } });
        }
        const userId = new mongoose_1.default.Types.ObjectId(user.id);
        const [result] = await User_1.User.aggregate([
            { $match: { _id: userId } },
            {
                $lookup: {
                    from: "files",
                    localField: "photoId",
                    foreignField: "_id",
                    as: "photo",
                },
            },
            {
                $addFields: {
                    photo: {
                        $cond: {
                            if: { $eq: [{ $size: "$photo" }, 0] },
                            then: null,
                            else: { $arrayElemAt: ["$photo", 0] },
                        },
                    },
                },
            },
            {
                $lookup: {
                    from: "files",
                    localField: "coverPhotoId",
                    foreignField: "_id",
                    as: "coverPhoto",
                },
            },
            {
                $addFields: {
                    coverPhoto: {
                        $cond: {
                            if: { $eq: [{ $size: "$coverPhoto" }, 0] },
                            then: null,
                            else: { $arrayElemAt: ["$coverPhoto", 0] },
                        },
                    },
                },
            },
            {
                $lookup: {
                    from: "subscriptionplans",
                    localField: "_id",
                    foreignField: "userId",
                    as: "subscriptionPlans",
                },
            },
            {
                $addFields: {
                    subscriptionPlans: {
                        $filter: {
                            input: "$subscriptionPlans",
                            as: "plan",
                            cond: {
                                $and: [
                                    { $eq: ["$$plan.isDeleted", false] },
                                    {
                                        $or: [
                                            {
                                                $eq: ["$$plan.planType", subscriptionPlanEnum_1.SubscriptionPlanType.CUSTOM],
                                            },
                                            {
                                                $eq: ["$$plan.planType", subscriptionPlanEnum_1.SubscriptionPlanType.FIXED],
                                            },
                                        ],
                                    },
                                ],
                            },
                        },
                    },
                },
            },
            {
                $facet: {
                    user: [{ $limit: 1 }],
                    followersCount: [
                        {
                            $lookup: {
                                from: "userconnections",
                                let: { userId: "$_id" },
                                pipeline: [
                                    {
                                        $match: { $expr: { $eq: ["$followingTo", "$$userId"] } },
                                    },
                                    { $count: "count" },
                                ],
                                as: "followers",
                            },
                        },
                        {
                            $addFields: {
                                count: { $arrayElemAt: ["$followers.count", 0] },
                            },
                        },
                    ],
                    followingCount: [
                        {
                            $lookup: {
                                from: "userconnections",
                                let: { userId: "$_id" },
                                pipeline: [
                                    { $match: { $expr: { $eq: ["$owner", "$$userId"] } } },
                                    { $count: "count" },
                                ],
                                as: "following",
                            },
                        },
                        {
                            $addFields: {
                                count: { $arrayElemAt: ["$following.count", 0] },
                            },
                        },
                    ],
                    postsCount: [
                        {
                            $lookup: {
                                from: "posts",
                                let: { userId: "$_id" },
                                pipeline: [
                                    {
                                        $match: {
                                            $expr: {
                                                $and: [
                                                    { $eq: ["$user", "$$userId"] },
                                                    { $eq: ["$isDeleted", false] },
                                                    { $eq: ["$type", postTypeEnum_1.PostType.POST] },
                                                ],
                                            },
                                        },
                                    },
                                    { $count: "count" },
                                ],
                                as: "posts",
                            },
                        },
                        {
                            $addFields: {
                                count: { $arrayElemAt: ["$posts.count", 0] },
                            },
                        },
                    ],
                    likesCount: [
                        {
                            $lookup: {
                                from: "posts",
                                let: { userId: "$_id" },
                                pipeline: [
                                    { $match: { $expr: { $eq: ["$user", "$$userId"] } } },
                                    { $project: { _id: 1 } },
                                ],
                                as: "userPosts",
                            },
                        },
                        { $unwind: "$userPosts" },
                        {
                            $lookup: {
                                from: "interactions",
                                let: { postId: "$userPosts._id" },
                                pipeline: [
                                    {
                                        $match: {
                                            $expr: {
                                                $and: [
                                                    { $eq: ["$post", "$$postId"] },
                                                    { $eq: ["$type", InteractionTypeEnum_1.InteractionType.LIKE_POST] },
                                                ],
                                            },
                                        },
                                    },
                                    { $count: "count" },
                                ],
                                as: "likes",
                            },
                        },
                        {
                            $group: {
                                _id: null,
                                totalLikes: { $sum: { $arrayElemAt: ["$likes.count", 0] } },
                            },
                        },
                        {
                            $addFields: {
                                totalLikes: { $ifNull: ["$totalLikes", 0] },
                            },
                        },
                    ],
                    subscriberCount: [
                        {
                            $lookup: {
                                from: "subscriptions",
                                let: { planIds: "$subscriptionPlans._id" },
                                pipeline: [
                                    {
                                        $match: {
                                            $expr: {
                                                $and: [
                                                    { $in: ["$planId", "$$planIds"] },
                                                    { $eq: ["$status", SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE] },
                                                ],
                                            },
                                        },
                                    },
                                    { $count: "count" },
                                ],
                                as: "subscribers",
                            },
                        },
                        {
                            $addFields: {
                                count: { $arrayElemAt: ["$subscribers.count", 0] },
                            },
                        },
                    ],
                },
            },
            {
                $project: {
                    user: { $arrayElemAt: ["$user", 0] },
                    followersCount: {
                        $ifNull: [{ $arrayElemAt: ["$followersCount.count", 0] }, 0],
                    },
                    followingCount: {
                        $ifNull: [{ $arrayElemAt: ["$followingCount.count", 0] }, 0],
                    },
                    postsCount: {
                        $ifNull: [{ $arrayElemAt: ["$postsCount.count", 0] }, 0],
                    },
                    totalLikes: {
                        $ifNull: [{ $arrayElemAt: ["$likesCount.totalLikes", 0] }, 0],
                    },
                    subscriberCount: {
                        $ifNull: [{ $arrayElemAt: ["$subscriberCount.count", 0] }, 0],
                    },
                },
            },
        ]);
        // get the user platform subscription
        console.log("Existing user id is", user.id);
        let planId = "67648382f267d99e0dc8de11";
        if (user === null || user === void 0 ? void 0 : user.isFreeSubscription) {
            planId = "678a0764e01be7cfa52b9a9c";
        }
        const subscriptionDetails = await Subscription_1.Subscription.findOne({
            userId: user.id,
            planId: planId, //same $20 plan used for all users.
        }).select("-stripeSubscriptionObject");
        if (result && result.user) {
            const userDoc = Array.isArray(result.user)
                ? result.user[0]
                : result.user;
            const followersCount = Array.isArray(result.followersCount)
                ? (((_b = result.followersCount[0]) === null || _b === void 0 ? void 0 : _b.count) || 0)
                : 0;
            const followingCount = Array.isArray(result.followingCount)
                ? (((_c = result.followingCount[0]) === null || _c === void 0 ? void 0 : _c.count) || 0)
                : 0;
            const postsCount = Array.isArray(result.postsCount)
                ? (((_d = result.postsCount[0]) === null || _d === void 0 ? void 0 : _d.count) || 0)
                : 0;
            const totalLikes = Array.isArray(result.likesCount)
                ? (((_e = result.likesCount[0]) === null || _e === void 0 ? void 0 : _e.totalLikes) || 0)
                : 0;
            const subscriberCount = Array.isArray(result.subscriberCount)
                ? (((_f = result.subscriberCount[0]) === null || _f === void 0 ? void 0 : _f.count) || 0)
                : 0;
            // Preserve legacy shape (data.user = {...}) to avoid breaking existing clients,
            // but also expose useful fields at top-level for convenience
            const payload = {
                user: userDoc || {},
                followersCount,
                followingCount,
                postsCount,
                totalLikes,
                subscriberCount,
                platformSubscription: subscriptionDetails,
            };
            // duplicate some common fields at top level for clients that read data.fullName/userName/photo
            if (userDoc) {
                payload._id = userDoc._id;
                payload.fullName = userDoc.fullName;
                payload.userName = userDoc.userName;
                payload.email = userDoc.email;
                payload.photo = userDoc.photo;
                payload.coverPhoto = userDoc.coverPhoto;
                payload.googleId = userDoc.googleId;
            }
            return res.json({ data: payload });
        }
        return res.status(404).json({ error: { message: "User not found." } });
    }
    catch (err) {
        console.error(err, "error in retrievng user");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
//Below forget password apis
AuthController.sendForgotPasswordOtp = async (req, res) => {
    try {
        // Validate input using DTO
        const userInput = (0, class_transformer_1.plainToClass)(UserForgotPassword_input_1.UserForgotPasswordDto, req.body);
        const errors = await (0, class_validator_1.validate)(userInput);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        // Check if the user exists
        // Support both two-part and three-part stored formats
        const dial = String(userInput.dialCode || '');
        const num = String(userInput.phoneNumber || '');
        const threePartRegex = new RegExp(`^[A-Za-z]{2}--${dial.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}--${num.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}$`, 'i');
        const user = await User_1.User.findOne({
            isDeleted: false,
            $or: [
                { completePhoneNumber: `${dial}--${num}` },
                { completePhoneNumber: { $regex: threePartRegex } },
            ],
        });
        console.log("Reached");
        if (!user) {
            return res.status(404).json({
                status: false,
                message: "User not found with this phone number",
            });
        }
        // Generate OTP and update user
        const otp = (0, otpGenerator_1.default)();
        const otpInvalidAt = (0, date_fns_2.addMinutes)(new Date(), 10);
        const updatedData = {
            otp,
            otpInvalidAt,
        };
        await User_1.User.findByIdAndUpdate(user.id, updatedData, { new: true });
        // Send OTP via SMS
        await (0, sendMessage_1.sendMessage)(`${dial}--${num}`, `Your OTP for password reset is: ${otp}`);
        return res.status(200).json({
            status: true,
            message: "OTP sent successfully. Please verify within 10 minutes.",
            otp,
        });
    }
    catch (error) {
        console.error("Error in sending OTP:", error);
        return res.status(500).json({
            status: false,
            message: "Failed to send OTP.",
        });
    }
};
AuthController.validateForgotPasswordOtp = async (req, res) => {
    try {
        const { dialCode, phoneNumber, otp } = req.body;
        if (!dialCode || !phoneNumber || !otp) {
            return res.status(400).json({
                status: false,
                message: "Phone number, dial code, and OTP are required.",
            });
        }
        const threePartRegex = new RegExp(`^[A-Za-z]{2}--${String(dialCode || '').replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}--${String(phoneNumber || '').replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}$`, 'i');
        const user = await User_1.User.findOne({
            isDeleted: false,
            $or: [
                { completePhoneNumber: `${dialCode}--${phoneNumber}` },
                { completePhoneNumber: { $regex: threePartRegex } },
            ],
        });
        if (!user) {
            return res.status(404).json({
                status: false,
                message: "User not found with this phone number.",
            });
        }
        console.log("user details are", user);
        if (!user.otp || user.otp !== otp.toString()) {
            return res.status(400).json({
                status: false,
                message: "Invalid OTP.",
            });
        }
        if (new Date() > user.otpInvalidAt) {
            return res.status(400).json({
                status: false,
                message: "OTP has expired.",
            });
        }
        // const usreInfo = await User.findOneAndUpdate(
        //   {completePhoneNumber: completePhoneNumber},
        //   {otp: ""},
        //  {new: true}
        // );
        return res.status(200).json({
            status: true,
            message: "OTP validated successfully.",
            user: user,
            // user: usreInfo
        });
    }
    catch (error) {
        console.error("Error in validating OTP:", error);
        return res.status(500).json({
            status: false,
            message: "Failed to validate OTP.",
            error: error.message,
        });
    }
};
AuthController.resetPassword = async (req, res) => {
    try {
        const { dialCode, phoneNumber, newPassword, confirmPassword } = req.body;
        // Validate required fields
        if (!dialCode || !phoneNumber || !newPassword || !confirmPassword) {
            return res.status(400).json({
                message: "Dial code, phone number, new password, and confirm password are required.",
            });
        }
        // Check if passwords match
        if (newPassword !== confirmPassword) {
            return res
                .status(400)
                .json({ message: "New password and confirm password do not match." });
        }
        const threePartRegex = new RegExp(`^[A-Za-z]{2}--${String(dialCode || '').replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}--${String(phoneNumber || '').replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}$`, 'i');
        const user = await User_1.User.findOne({
            isDeleted: false,
            $or: [
                { completePhoneNumber: `${dialCode}--${phoneNumber}` },
                { completePhoneNumber: { $regex: threePartRegex } },
            ],
        });
        // Check if the user exists
        if (!user) {
            return res
                .status(404)
                .json({ message: "User not found with this phone number." });
        }
        const salt = (0, bcryptjs_1.genSaltSync)(10);
        const password = newPassword;
        const hashPassword = (0, bcryptjs_1.hashSync)(password, salt);
        await User_1.User.findOneAndUpdate({ _id: user._id, isDeleted: false }, {
            password: hashPassword,
        }, {
            new: true,
        });
        return res.status(200).json({ message: "Password reset successfully." });
    }
    catch (error) {
        console.error("Error in resetting password:", error);
        return res.status(500).json({ message: "Failed to reset password." });
    }
};
//# sourceMappingURL=auth.controller.js.map