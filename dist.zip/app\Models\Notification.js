"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Notification = void 0;
const mongoose_1 = require("mongoose");
const NotificationSchema_1 = require("../../database/schemas/NotificationSchema");
const Notification = (0, mongoose_1.model)("Notification", NotificationSchema_1.NotificationSchema);
exports.Notification = Notification;
//# sourceMappingURL=Notification.js.map