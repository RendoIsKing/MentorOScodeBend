"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Interest = void 0;
const mongoose_1 = require("mongoose");
const InterestSchema_1 = require("../../database/schemas/InterestSchema");
const Interest = (0, mongoose_1.model)('Interest', InterestSchema_1.InterestSchema);
exports.Interest = Interest;
//# sourceMappingURL=Interest.js.map