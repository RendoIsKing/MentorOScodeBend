"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionPlanController = void 0;
const createSubscriptionPlanAction_1 = require("./Actions/createSubscriptionPlanAction");
const getSubscriptionPlanAction_1 = require("./Actions/getSubscriptionPlanAction");
const updateSubscriptionPlanAction_1 = require("./Actions/updateSubscriptionPlanAction");
const deleteSubscriptionPlanAction_1 = require("./Actions/deleteSubscriptionPlanAction");
// import {  }
const createProduct_1 = __importDefault(require("./Actions/createProduct"));
class SubscriptionPlanController {
}
exports.SubscriptionPlanController = SubscriptionPlanController;
SubscriptionPlanController.createPlan = (req, res) => {
    (0, createSubscriptionPlanAction_1.postSubscriptionPlan)(req, res);
};
SubscriptionPlanController.createProduct = (req, res) => {
    (0, createProduct_1.default)(req, res);
};
SubscriptionPlanController.getSubscriptionPlan = (req, res) => {
    (0, getSubscriptionPlanAction_1.getSubscriptionPlan)(req, res);
};
SubscriptionPlanController.updateSubscriptionPlan = (req, res) => {
    (0, updateSubscriptionPlanAction_1.updateSubscriptionPlan)(req, res);
};
SubscriptionPlanController.softDeleteSubscriptionPlan = (req, res) => {
    (0, deleteSubscriptionPlanAction_1.softDeleteSubscriptionPlan)(req, res);
};
SubscriptionPlanController.oneSameSubscirptionPlanForAllUsers = (req, res) => {
    (0, getSubscriptionPlanAction_1.getOneSubscriptionPlanForAllUsers)(req, res);
};
//# sourceMappingURL=index.js.map