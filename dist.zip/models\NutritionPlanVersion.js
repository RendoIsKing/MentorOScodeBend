"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const NutritionPlanVersionSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    version: { type: Number, index: true, required: true },
    source: { type: String, enum: ["preview", "rule", "manual", "action"], default: "action" },
    reason: String,
    kcal: Number, proteinGrams: Number, carbsGrams: Number, fatGrams: Number,
}, { timestamps: true });
NutritionPlanVersionSchema.index({ user: 1, version: -1 }, { unique: true });
exports.default = (0, mongoose_1.model)("NutritionPlanVersion", NutritionPlanVersionSchema);
//# sourceMappingURL=NutritionPlanVersion.js.map