"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const StudentStateSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", unique: true, index: true, required: true },
    currentTrainingPlanVersion: { type: mongoose_1.Schema.Types.ObjectId, ref: "TrainingPlanVersion" },
    currentNutritionPlanVersion: { type: mongoose_1.Schema.Types.ObjectId, ref: "NutritionPlanVersion" },
    snapshotUpdatedAt: Date,
    lastEventAt: Date,
}, { timestamps: true });
exports.default = (0, mongoose_1.model)("StudentState", StudentStateSchema);
//# sourceMappingURL=StudentState.js.map