"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFirstPost = void 0;
const Post_1 = require("../../../Models/Post");
const getFirstPost = async (req, res) => {
    try {
        const post = await Post_1.Post.findOne({
            deletedAt: null,
            isDeleted: false,
        }).exec();
        if (!post) {
            return res.status(404).json({ error: "No posts found" });
        }
        return res.json(post);
    }
    catch (error) {
        console.error("Error retrieving Post:", error);
        return res.status(500).json({ error: "Internal Server Error" });
    }
};
exports.getFirstPost = getFirstPost;
//# sourceMappingURL=testPostAction.js.map