"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionPlan = void 0;
const mongoose_1 = require("mongoose");
const SubscriptionPlanSchema_1 = require("../../database/schemas/SubscriptionPlanSchema");
const SubscriptionPlan = (0, mongoose_1.model)('SubscriptionPlan', SubscriptionPlanSchema_1.SubscriptionPlanSchema);
exports.SubscriptionPlan = SubscriptionPlan;
//# sourceMappingURL=SubscriptionPlan.js.map