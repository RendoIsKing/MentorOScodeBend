"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFeature = void 0;
const Feature_1 = require("../../../Models/Feature");
const createSlug_1 = __importDefault(require("../../../../utils/regx/createSlug"));
const createFeature = async (req, res) => {
    try {
        const body = req.body;
        const featureSlug = (0, createSlug_1.default)(body.feature);
        const featureExist = await Feature_1.Feature.findOne({ slug: featureSlug });
        if (featureExist) {
            return res.status(400).json({
                message: "Feature already existed with this name",
            });
        }
        const feature = await Feature_1.Feature.create({
            ...body,
            slug: featureSlug,
            isAvailable: true,
        });
        return res.json({
            data: feature,
        });
    }
    catch (error) {
        console.log("error in creating feature", error);
        return res.status(500).json({
            messsage: "Something went wrong",
            error: error,
        });
    }
};
exports.createFeature = createFeature;
//# sourceMappingURL=createFeatureAction.js.map