"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatMessageSchema = void 0;
const mongoose_1 = require("mongoose");
exports.ChatMessageSchema = new mongoose_1.Schema({
    threadId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'ChatThread', required: true, index: true },
    sender: { type: String, enum: ['user', 'assistant'], required: true },
    text: { type: String, required: true },
}, { timestamps: { createdAt: true, updatedAt: false } });
exports.ChatMessageSchema.index({ threadId: 1, createdAt: -1 });
//# sourceMappingURL=ChatMessageSchema.js.map