"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.acceptTos = acceptTos;
const User_1 = require("../../Models/User");
async function acceptTos(req, res) {
    var _a;
    try {
        const user = req.user;
        if (!user)
            return res.status(401).json({ error: { message: 'Unauthorized' } });
        const version = ((_a = req.body) === null || _a === void 0 ? void 0 : _a.version) || '1.0';
        const id = (user === null || user === void 0 ? void 0 : user._id) || (user === null || user === void 0 ? void 0 : user.id);
        if (!id)
            return res.status(400).json({ error: { message: 'invalid user id' } });
        await User_1.User.updateOne({ _id: id }, { $set: { acceptedTosAt: new Date(), tosVersion: version } });
        return res.json({ ok: true, version });
    }
    catch {
        return res.status(500).json({ error: { message: 'acceptance failed' } });
    }
}
//# sourceMappingURL=acceptTos.js.map