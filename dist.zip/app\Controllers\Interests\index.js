"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.InterestController = void 0;
const createInterestAction_1 = require("./Actions/createInterestAction");
const postInterestByUserAction_1 = require("./Actions/postInterestByUserAction");
const getAllInterestAction_1 = require("./Actions/getAllInterestAction");
const deleteInterestAction_1 = require("./Actions/deleteInterestAction");
const updateInterestAction_1 = require("./Actions/updateInterestAction");
class InterestController {
}
exports.InterestController = InterestController;
_a = InterestController;
InterestController.createInterest = async (req, res) => {
    return (0, createInterestAction_1.createInterest)(req, res);
};
InterestController.postInterest = async (req, res) => {
    return (0, postInterestByUserAction_1.postInterest)(req, res);
};
InterestController.getAllInterest = async (req, res) => {
    return (0, getAllInterestAction_1.getAllInterest)(req, res);
};
InterestController.deleteInterest = async (req, res) => {
    return (0, deleteInterestAction_1.deleteInterest)(req, res);
};
InterestController.updateInterest = async (req, res) => {
    return (0, updateInterestAction_1.updateInterest)(req, res);
};
//# sourceMappingURL=index.js.map