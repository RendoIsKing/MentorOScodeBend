"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOneTimeSubscription = void 0;
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const User_1 = require("../../../Models/User");
const CardDetails_1 = require("../../../Models/CardDetails");
const Post_1 = require("../../../Models/Post");
const privacyEnums_1 = require("../../../../types/enums/privacyEnums");
const Transaction_1 = require("../../../Models/Transaction");
const transactionStatusEnum_1 = require("../../../../types/enums/transactionStatusEnum");
const stripeCurrency_1 = require("../../../../utils/consts/stripeCurrency");
const transactionTypeEnum_1 = require("../../../../types/enums/transactionTypeEnum");
const productEnum_1 = require("../../../../types/enums/productEnum");
const createOneTimeSubscription = async (req, res) => {
    const { postId } = req.body;
    const reqUser = req.user;
    try {
        console.log("subscirption api is hitting");
        const user = await User_1.User.findOne({
            _id: reqUser === null || reqUser === void 0 ? void 0 : reqUser.id,
            isDeleted: false,
            deletedAt: null,
        });
        console.log("postId is", postId);
        const post = await Post_1.Post.findOne({
            _id: postId,
            privacy: privacyEnums_1.Privacy.PAY_PER_VIEW,
            isDeleted: false,
            deletedAt: null,
        });
        if (!post) {
            return res.status(404).json({ error: { message: "Post not found" } });
        }
        if (!post.stripeProductId) {
            return res
                .status(404)
                .json({ error: { message: "Product not registerd on stripe" } });
        }
        if (!user) {
            return res.status(404).json({ error: { message: "User not found" } });
        }
        if (!user.isStripeCustomer == false && !user.stripeClientId) {
            return res
                .status(404)
                .json({ error: { message: "User not registerd on stripe" } });
        }
        console.log("ali User id is", user.id);
        const card = await CardDetails_1.cardDetails.findOne({
            userId: user.id,
            isDefault: true,
        });
        if (!card) {
            return res
                .status(404)
                .json({ error: { message: "Card not found for the user" } });
        }
        const paymentIntent = await stripe_1.default.paymentIntents.create({
            amount: post.price,
            customer: user.stripeClientId,
            currency: stripeCurrency_1.stripe_currency,
            // payment_method: card.paymentMethodId,
            // off_session: true, // Required for automatic confirmation
            // confirm: true,
        });
        const newTransaction = new Transaction_1.Transaction({
            userId: user === null || user === void 0 ? void 0 : user.id,
            stripePaymentIntentId: paymentIntent.id,
            stripeProductId: post.stripeProductId,
            type: transactionTypeEnum_1.TransactionType.DEBIT,
            productType: productEnum_1.ProductType.POSTS,
            productId: post.id,
            amount: post.price,
            status: transactionStatusEnum_1.TransactionStatus.PENDING,
        });
        await newTransaction.save();
        const newCreditTransaction = new Transaction_1.Transaction({
            userId: post === null || post === void 0 ? void 0 : post.user,
            stripePaymentIntentId: paymentIntent.id,
            type: transactionTypeEnum_1.TransactionType.CREDIT,
            stripeProductId: post.stripeProductId,
            productType: productEnum_1.ProductType.POSTS,
            productId: post.id,
            amount: post.price,
            status: transactionStatusEnum_1.TransactionStatus.PENDING,
        });
        await newCreditTransaction.save();
        return res.status(200).send({
            data: paymentIntent,
            paymentMethod: card.paymentMethodId,
            // clientSecret: paymentIntent.client_secret,
            //@ts-ignore
            //   clientSecret: subscription.latest_invoice.payment_intent.client_secret,
        });
    }
    catch (error) {
        console.error("Error creating one time payment:", error);
        return res.status(400).send({ error: { message: error.message } });
    }
};
exports.createOneTimeSubscription = createOneTimeSubscription;
//# sourceMappingURL=createOneTimeSubscription.js.map