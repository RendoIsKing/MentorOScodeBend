"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postDocument = void 0;
const Document_1 = require("../../../Models/Document");
const class_validator_1 = require("class-validator");
const postDocumentInput_1 = require("../Inputs/postDocumentInput");
const User_1 = require("../../../Models/User");
const class_transformer_1 = require("class-transformer");
const postDocument = async (req, res) => {
    try {
        const docInput = (0, class_transformer_1.plainToClass)(postDocumentInput_1.DocumentInput, req.body);
        const validationErrors = await (0, class_validator_1.validate)(docInput);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        const user = req.user;
        if (user) {
            await User_1.User.findByIdAndUpdate(user.id, {
                hasDocumentUploaded: true,
            });
        }
        const newDocument = new Document_1.Document({
            ...req.body,
            userId: user.id,
        });
        await newDocument.save();
        return res.json({
            data: newDocument,
            message: "Document created successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error in posting document");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.postDocument = postDocument;
//# sourceMappingURL=postDocumentAction.js.map