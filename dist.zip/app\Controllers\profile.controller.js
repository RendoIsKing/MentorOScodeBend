"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfileController = void 0;
const class_validator_1 = require("class-validator");
const bcryptjs_1 = require("bcryptjs");
const ChangePassword_input_1 = require("../Inputs/ChangePassword.input");
const User_1 = require("../Models/User");
// import {DeleteFile} from "../../utils/removeFile";
// import {FileEnum} from "../../types/FileEnum";
// import { UpdateUserDTO } from '../Inputs/UpdateUser.input';
class ProfileController {
}
exports.ProfileController = ProfileController;
_a = ProfileController;
ProfileController.changePassword = async (req, res) => {
    const input = req.body;
    // @ts-ignore
    const { id } = req.user;
    const changePasswordInput = new ChangePassword_input_1.ChangePasswordInput();
    changePasswordInput.currentPassword = input.currentPassword;
    changePasswordInput.newPassword = input.newPassword;
    const errors = await (0, class_validator_1.validate)(changePasswordInput);
    if (errors.length) {
        const errorsInfo = errors.map(error => ({
            property: error.property,
            constraints: error.constraints
        }));
        return res.status(400).json({ error: { message: 'VALIDATION_ERROR', info: { errorsInfo } } });
    }
    try {
        const user = await User_1.User.findById(id);
        if (!user) {
            return res.status(400).json({ error: { message: 'User to update does not exists.' } });
        }
        if (!(0, bcryptjs_1.compareSync)(input.currentPassword, user.password)) {
            return res.status(400).json({ error: { message: 'Invalid current password' } });
        }
        const salt = (0, bcryptjs_1.genSaltSync)(10);
        const password = input.newPassword;
        const hashPassword = (0, bcryptjs_1.hashSync)(password, salt);
        await User_1.User.findByIdAndUpdate(id, {
            password: hashPassword
        }, {
            new: true,
        });
        // todo: send password rest mail to user
        return res.json({ data: { message: 'Password reset successfully.' } });
    }
    catch (error) {
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
//# sourceMappingURL=profile.controller.js.map