"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rebuildSnapshot = rebuildSnapshot;
const StudentSnapshot_1 = __importDefault(require("../../models/StudentSnapshot"));
const StudentState_1 = __importDefault(require("../../models/StudentState"));
const TrainingPlanVersion_1 = __importDefault(require("../../models/TrainingPlanVersion"));
const NutritionPlanVersion_1 = __importDefault(require("../../models/NutritionPlanVersion"));
const WeightEntry_1 = require("../../app/Models/WeightEntry");
async function rebuildSnapshot(user) {
    const state = await StudentState_1.default.findOne({ user });
    const [tp, np] = await Promise.all([
        (state === null || state === void 0 ? void 0 : state.currentTrainingPlanVersion) ? TrainingPlanVersion_1.default.findById(state.currentTrainingPlanVersion) : null,
        (state === null || state === void 0 ? void 0 : state.currentNutritionPlanVersion) ? NutritionPlanVersion_1.default.findById(state.currentNutritionPlanVersion) : null
    ]);
    const weights = await WeightEntry_1.WeightEntry.find({ userId: user }).sort({ date: 1 }).select('date kg').lean();
    const weightSeries = (weights || []).map((w) => ({ t: w.date, v: w.kg }));
    const daysPerWeek = tp ? (tp.days || []).filter((d) => (d.exercises || []).length).length : 0;
    const snap = {
        user,
        weightSeries,
        trainingPlanSummary: tp ? { daysPerWeek } : undefined,
        nutritionSummary: np ? { kcal: np.kcal, protein: np.proteinGrams, carbs: np.carbsGrams, fat: np.fatGrams } : undefined,
        kpis: { adherence7d: 0 }
    };
    await StudentSnapshot_1.default.findOneAndUpdate({ user }, { $set: snap }, { upsert: true });
    await StudentState_1.default.updateOne({ user }, { $set: { snapshotUpdatedAt: new Date() } }, { upsert: true });
}
//# sourceMappingURL=rebuildSnapshot.js.map