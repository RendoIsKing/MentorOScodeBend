"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const chat_1 = require("../models/chat");
const sseHub_1 = require("../lib/sseHub");
const Middlewares_1 = require("../app/Middlewares");
const rateLimiters_1 = require("../app/Middlewares/rateLimiters");
const schemas_1 = require("../app/Validation/schemas");
const r = (0, express_1.Router)();
function me(req) {
    var _a, _b, _c;
    // @ts-ignore
    return (_c = (_b = (_a = req.user) === null || _a === void 0 ? void 0 : _a._id) === null || _b === void 0 ? void 0 : _b.toString) === null || _c === void 0 ? void 0 : _c.call(_b);
}
r.post('/threads', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_CHAT_PER_MIN || 30) }), async (req, res) => {
    const myId = me(req);
    if (!myId)
        return res.status(401).json({ error: 'unauthorized' });
    const { userId } = req.body || {};
    if (!userId || userId === myId)
        return res.status(400).json({ error: 'bad userId' });
    const pair = [myId, userId].sort();
    let thread = await chat_1.ChatThread.findOne({ participants: { $all: pair, $size: 2 } });
    if (!thread) {
        thread = await chat_1.ChatThread.create({ participants: pair, lastMessageAt: new Date(), unread: new Map([[userId, 0], [myId, 0]]) });
    }
    return res.json({ threadId: thread._id.toString() });
});
r.get('/threads', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    const myId = me(req);
    if (!myId)
        return res.status(401).json({ error: 'unauthorized' });
    const threads = await chat_1.ChatThread.find({ participants: myId }).sort({ lastMessageAt: -1 }).lean();
    return res.json({ threads: threads.map(t => { var _a, _b; return ({ id: t._id.toString(), lastMessageAt: t.lastMessageAt, lastMessageText: t.lastMessageText || '', unread: ((_b = (_a = t.unread) === null || _a === void 0 ? void 0 : _a.get(myId)) !== null && _b !== void 0 ? _b : 0), participants: t.participants.map(String) }); }) });
});
r.get('/threads/:id/messages', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_CHAT_PER_MIN || 30) }), async (req, res) => {
    const myId = me(req);
    if (!myId)
        return res.status(401).json({ error: 'unauthorized' });
    const { id } = req.params;
    const thread = await chat_1.ChatThread.findById(id).lean();
    if (!thread)
        return res.status(404).json({ error: 'not found' });
    if (!thread.participants.map(String).includes(myId))
        return res.status(403).json({ error: 'forbidden' });
    const { cursor, limit = 30 } = req.query;
    const q = { thread: id };
    if (cursor)
        q._id = { $lt: cursor };
    const messages = await chat_1.ChatMessage.find(q).sort({ _id: -1 }).limit(Number(limit)).lean();
    return res.json({ messages: messages.reverse().map(m => ({ id: m._id.toString(), text: m.text, sender: m.sender.toString(), createdAt: m.createdAt })), nextCursor: messages.length ? messages[0]._id.toString() : null });
});
r.post('/threads/:id/messages', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_CHAT_PER_MIN || 30) }), async (req, res) => {
    var _a, _b;
    const myId = me(req);
    if (!myId)
        return res.status(401).json({ error: 'unauthorized' });
    const { id } = req.params;
    const parsed = schemas_1.chatMessageSchema.safeParse({ text: (req.body || {}).text });
    if (!parsed.success)
        return res.status(422).json({ error: 'validation_failed', details: parsed.error.flatten() });
    const text = parsed.data.text;
    const thread = await chat_1.ChatThread.findById(id);
    if (!thread)
        return res.status(404).json({ error: 'not found' });
    if (!thread.participants.map(String).includes(myId))
        return res.status(403).json({ error: 'forbidden' });
    const msg = await chat_1.ChatMessage.create({ thread: thread._id, sender: myId, text: text.trim(), readBy: [myId] });
    thread.lastMessageAt = new Date();
    thread.lastMessageText = msg.text;
    for (const p of thread.participants.map(String)) {
        thread.unread.set(p, p === myId ? 0 : ((_a = thread.unread.get(p)) !== null && _a !== void 0 ? _a : 0) + 1);
    }
    await thread.save();
    for (const p of thread.participants.map(String)) {
        (0, sseHub_1.ssePush)(p, 'chat:message', { threadId: thread._id.toString(), message: { id: msg._id.toString(), text: msg.text, sender: myId, createdAt: msg.createdAt } });
        (0, sseHub_1.ssePush)(p, 'chat:thread', { id: thread._id.toString(), lastMessageAt: thread.lastMessageAt, lastMessageText: thread.lastMessageText, unread: (_b = thread.unread.get(p)) !== null && _b !== void 0 ? _b : 0 });
    }
    return res.json({ ok: true, id: msg._id.toString() });
});
r.post('/threads/:id/read', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_CHAT_PER_MIN || 30) }), async (req, res) => {
    const myId = me(req);
    if (!myId)
        return res.status(401).json({ error: 'unauthorized' });
    const { id } = req.params;
    const thread = await chat_1.ChatThread.findById(id);
    if (!thread)
        return res.status(404).json({ error: 'not found' });
    if (!thread.participants.map(String).includes(myId))
        return res.status(403).json({ error: 'forbidden' });
    await chat_1.ChatMessage.updateMany({ thread: id, sender: { $ne: myId } }, { $addToSet: { readBy: myId } });
    thread.unread.set(myId, 0);
    await thread.save();
    (0, sseHub_1.ssePush)(myId, 'chat:thread', { id: thread._id.toString(), lastMessageAt: thread.lastMessageAt, lastMessageText: thread.lastMessageText, unread: 0 });
    return res.json({ ok: true });
});
r.get('/sse', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_SSE_PER_MIN || 30) }), (req, res) => {
    var _a;
    const myId = me(req);
    if (!myId)
        return res.status(401).end();
    res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    // @ts-ignore
    (_a = res.flushHeaders) === null || _a === void 0 ? void 0 : _a.call(res);
    res.write(':\n\n');
    (0, sseHub_1.sseAddClient)(myId, res);
    req.on('close', () => { (0, sseHub_1.sseRemoveClient)(myId, res); try {
        res.end();
    }
    catch { } });
    return;
});
exports.default = r;
//# sourceMappingURL=chat.js.map