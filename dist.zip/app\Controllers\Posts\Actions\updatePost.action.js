"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updatePostAction = void 0;
const class_transformer_1 = require("class-transformer");
const updatePost_input_1 = require("../Inputs/updatePost.input");
const class_validator_1 = require("class-validator");
const Post_1 = require("../../../Models/Post");
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const User_1 = require("../../../Models/User");
const RolesEnum_1 = require("../../../../types/RolesEnum");
const updatePostAction = async (req, res) => {
    try {
        const user = req.user;
        const postInput = (0, class_transformer_1.plainToClass)(updatePost_input_1.UpdatePostDto, req.body);
        const postId = req.params.id;
        const errors = await (0, class_validator_1.validate)(postInput);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        const postExists = await Post_1.Post.findById(postId);
        if (!postExists) {
            return res.status(400).json({ error: { message: "Post not exist" } });
        }
        if (postExists.user.toString() !== user.id &&
            user.role !== RolesEnum_1.RolesEnum.ADMIN) {
            return res.status(400).json({ error: { message: "Invalid post" } });
        }
        if (postInput.isPinned) {
            const pinnedPostsCount = await Post_1.Post.countDocuments({
                user: user.id,
                deletedAt: null,
                isDeleted: false,
                isPinned: true,
            });
            if (pinnedPostsCount >= 3) {
                return res
                    .status(400)
                    .json({ error: { message: "You can only pin up to 3 posts." } });
            }
        }
        if (postInput.userTags && postInput.userTags.length > 0) {
            const userIds = postInput.userTags.map((tag) => tag.userId);
            const uniqueUserIds = [...new Set(userIds)];
            const validUserIds = await User_1.User.find({ _id: { $in: uniqueUserIds }, deletedAt: null, isDeleted: false }, "_id").lean();
            if (validUserIds.length !== uniqueUserIds.length) {
                return res
                    .status(400)
                    .json({ error: { message: "One or more user IDs are invalid." } });
            }
        }
        if (postInput.planToAccess) {
            const subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.findOne({
                userId: user.id,
                title: postInput.planToAccess,
            });
            if (!subscriptionPlan) {
                return res
                    .status(400)
                    .json({ error: { message: "Invalid planToAccess value." } });
            }
            subscriptionPlan.permissions.map((permission) => ({
                name: permission.feature,
                description: permission.description,
            }));
        }
        const post = await Post_1.Post.findByIdAndUpdate(postId, {
            ...postInput,
        }, { new: true });
        return res.json({
            data: post,
        });
    }
    catch (error) {
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.updatePostAction = updatePostAction;
//# sourceMappingURL=updatePost.action.js.map