"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildTestNotificationSchema = buildTestNotificationSchema;
function buildTestNotificationSchema(m) {
    const NotificationSchema = new m.Schema({
        title: { type: String, required: true },
        body: { type: String, required: true },
        sentTo: [
            {
                type: m.Schema.Types.ObjectId,
                ref: 'User',
                required: true,
            },
        ],
        createdAt: { type: Date, default: Date.now },
    });
    return NotificationSchema;
}
//# sourceMappingURL=NotificationSchema.test.js.map