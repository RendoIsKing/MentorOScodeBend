"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPostLikes = void 0;
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const getPostLikes = async (req, res) => {
    try {
        const { id } = req.params;
        const likes = await Interaction_1.Interaction.find({
            post: id,
            type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
            isDeleted: false,
        }).populate("user");
        return res.status(200).json({ data: likes });
    }
    catch (error) {
        console.error("Error fetching likes on post", error);
        return res.status(500).json({ error: "Something went wrong." });
    }
};
exports.getPostLikes = getPostLikes;
//# sourceMappingURL=getPostLikesAction.js.map