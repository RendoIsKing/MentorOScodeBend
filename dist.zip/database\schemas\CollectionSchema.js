"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionSchema = void 0;
const mongoose_1 = require("mongoose");
const CollectionSchema = new mongoose_1.Schema({
    title: String,
    owner: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    isActive: {
        type: Boolean,
        default: true,
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: Date,
}, {
    timestamps: true,
});
exports.CollectionSchema = CollectionSchema;
//# sourceMappingURL=CollectionSchema.js.map