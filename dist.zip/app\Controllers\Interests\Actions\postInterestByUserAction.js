"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postInterest = void 0;
const User_1 = require("../../../Models/User");
const Interest_1 = require("../../../Models/Interest");
const mongoose_1 = require("mongoose");
const postInterest = async (req, res) => {
    try {
        const { interestIds } = req.body;
        if (!Array.isArray(interestIds) || interestIds.some(id => !mongoose_1.Types.ObjectId.isValid(id))) {
            return res.status(400).json({ error: { message: "Invalid interest IDs." } });
        }
        const user = req.user;
        const userId = user.id;
        const interests = await Interest_1.Interest.find({ _id: { $in: interestIds }, isDeleted: false });
        if (interests.length !== interestIds.length) {
            return res.status(404).json({ error: { message: "One or more interests not found." } });
        }
        const userDoc = await User_1.User.findById(userId);
        if (!userDoc) {
            return res.status(404).json({ error: { message: "User not found." } });
        }
        userDoc.interests = [...new Set([...userDoc.interests, ...interestIds])];
        userDoc.hasSelectedInterest = true;
        await userDoc.save();
        return res.json({
            data: userDoc,
            message: "Interests added successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error in posting interest");
        return res.status(500).json({ error: { message: "Something went wrong." } });
    }
};
exports.postInterest = postInterest;
//# sourceMappingURL=postInterestByUserAction.js.map