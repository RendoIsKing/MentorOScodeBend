"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractCardDetailsFromToken = void 0;
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const extractCardDetailsFromToken = async (tokenId) => {
    try {
        const tokenDetails = await stripe_1.default.tokens.retrieve(tokenId);
        const cardDetails = tokenDetails.card;
        if (!cardDetails) {
            throw new Error("No card details found in the provided token.");
        }
        return cardDetails;
    }
    catch (error) {
        console.error("Error in extracting card details from token", error);
        throw error;
    }
};
exports.extractCardDetailsFromToken = extractCardDetailsFromToken;
//# sourceMappingURL=extractCardDetailsFromToken.js.map