"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserEarningStats = void 0;
const Transaction_1 = require("../../../Models/Transaction");
const mongoose_1 = require("mongoose");
const productEnum_1 = require("../../../../types/enums/productEnum");
const transactionTypeEnum_1 = require("../../../../types/enums/transactionTypeEnum");
const getUserEarningStats = async (req, res) => {
    try {
        const user = req.user;
        const { startDate, endDate } = req.body;
        const transaction = await Transaction_1.Transaction.aggregate([
            {
                $match: {
                    userId: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $gte: new Date(startDate), $lt: new Date(endDate) },
                    type: transactionTypeEnum_1.TransactionType.CREDIT,
                },
            },
            {
                $facet: {
                    Subcription: [
                        {
                            $match: {
                                productType: productEnum_1.ProductType.SUBSCRIPTION,
                            },
                        },
                        {
                            $group: {
                                _id: null,
                                count: {
                                    $sum: "$amount",
                                },
                            },
                        },
                    ],
                    Tips: [
                        {
                            $match: {
                                productType: productEnum_1.ProductType.TIPS,
                            },
                        },
                        {
                            $group: {
                                _id: null,
                                count: {
                                    $sum: "$amount",
                                },
                            },
                        },
                    ],
                    Posts: [
                        {
                            $match: {
                                productType: productEnum_1.ProductType.POSTS,
                            },
                        },
                        {
                            $group: {
                                _id: null,
                                count: {
                                    $sum: "$amount",
                                },
                            },
                        },
                    ],
                },
            },
        ]);
        const data = Object.entries(transaction[0]).map((item) => {
            var _a, _b;
            return {
                invoice: item[0],
                gross: (_a = item[1][0]) === null || _a === void 0 ? void 0 : _a.count,
                netAmt: (_b = item[1][0]) === null || _b === void 0 ? void 0 : _b.count,
                paymentMethod: "Card",
            };
        });
        return res.status(200).json({ data: data });
    }
    catch (error) {
        console.error("Error fetching user earning stats", error);
        return res.status(500).json({ error: "Something went wrong." });
    }
};
exports.getUserEarningStats = getUserEarningStats;
//# sourceMappingURL=getUserEarningStats.action.js.map