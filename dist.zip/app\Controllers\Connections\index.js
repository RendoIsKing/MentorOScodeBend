"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConnectionController = void 0;
const ToggleFollowAction_1 = require("./Actions/ToggleFollowAction");
class ConnectionController {
}
exports.ConnectionController = ConnectionController;
_a = ConnectionController;
ConnectionController.toggleFollow = async (req, res) => {
    return (0, ToggleFollowAction_1.toggleFollow)(req, res);
};
//# sourceMappingURL=index.js.map