"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductType = void 0;
var ProductType;
(function (ProductType) {
    ProductType["SUBSCRIPTION"] = "subscription";
    ProductType["TIPS"] = "tips";
    ProductType["POSTS"] = "post";
})(ProductType || (exports.ProductType = ProductType = {}));
//# sourceMappingURL=productEnum.js.map