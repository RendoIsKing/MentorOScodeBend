"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionPlanType = void 0;
var SubscriptionPlanType;
(function (SubscriptionPlanType) {
    SubscriptionPlanType["BASIC_FREE"] = "basic_free";
    SubscriptionPlanType["FIXED"] = "fixed";
    SubscriptionPlanType["CUSTOM"] = "custom";
})(SubscriptionPlanType || (exports.SubscriptionPlanType = SubscriptionPlanType = {}));
//# sourceMappingURL=subscriptionPlanEnum.js.map