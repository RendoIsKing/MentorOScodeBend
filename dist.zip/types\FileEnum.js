"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileEnum = void 0;
var FileEnum;
(function (FileEnum) {
    FileEnum["PUBLICDIR"] = "/public";
    FileEnum["PROFILEIMAGE"] = "/profile-image/";
})(FileEnum || (exports.FileEnum = FileEnum = {}));
//# sourceMappingURL=FileEnum.js.map