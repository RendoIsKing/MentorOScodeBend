"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSubscription = void 0;
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const User_1 = require("../../../Models/User");
const Subscription_1 = require("../../../Models/Subscription");
const SubscriptionStatusEnum_1 = require("../../../../types/enums/SubscriptionStatusEnum");
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const CardDetails_1 = require("../../../Models/CardDetails");
const Transaction_1 = require("../../../Models/Transaction");
const transactionStatusEnum_1 = require("../../../../types/enums/transactionStatusEnum");
const transactionTypeEnum_1 = require("../../../../types/enums/transactionTypeEnum");
const cancelSubscription_1 = require("./cancelSubscription");
const productEnum_1 = require("../../../../types/enums/productEnum");
const createSubscription = async (req, res) => {
    const { planId } = req.body;
    const reqUser = req.user;
    try {
        const user = await User_1.User.findOne({
            _id: reqUser === null || reqUser === void 0 ? void 0 : reqUser.id,
            isDeleted: false,
            deletedAt: null,
        });
        //why find subscription plan => as the data added in table with each user
        const plan = await SubscriptionPlan_1.SubscriptionPlan.findOne({
            _id: planId,
            isDeleted: false,
            deletedAt: null,
        });
        if (!plan) {
            return res.status(404).json({ error: { message: "Plan not found" } });
        }
        if (!plan.stripeProductObject) {
            return res
                .status(404)
                .json({ error: { message: "Plan/Product not registerd on stripe" } });
        }
        console.log("Plan/Product registerd on stripe", plan.stripeProductObject);
        if (!user) {
            return res.status(404).json({ error: { message: "User not found" } });
        }
        if (!user.isStripeCustomer == false && !user.stripeClientId) {
            return res
                .status(404)
                .json({ error: { message: "User not registerd on stripe" } });
        }
        const cancelParams = { userId: reqUser === null || reqUser === void 0 ? void 0 : reqUser.id };
        await (0, cancelSubscription_1.cancelSubscriptions)(cancelParams);
        // FIXME: cardDetails should be CardDetail
        // Always have Class names with first letter capital
        console.log("user.id ", user.id);
        const card = await CardDetails_1.cardDetails.findOne({
            userId: user.id,
            isDefault: true,
        });
        console.log("User card details is", card);
        if (!card) {
            return res
                .status(404)
                .json({ error: { message: "Card not found for the user" } });
        }
        console.log("card.paymentMethodId ", card.paymentMethodId);
        console.log("user.stripeClientId ", user.stripeClientId);
        const paymentMethod = await stripe_1.default.paymentMethods.retrieve(card.paymentMethodId);
        console.log("paymentMethod ", paymentMethod);
        const subscription = await stripe_1.default.subscriptions.create({
            customer: user.stripeClientId,
            default_payment_method: card.paymentMethodId,
            items: [
                {
                    price: plan.stripeProductObject.default_price,
                },
            ],
            payment_behavior: "default_incomplete",
            payment_settings: { save_default_payment_method: "on_subscription" },
            expand: ["latest_invoice.payment_intent"],
        });
        console.log("subscription ", subscription);
        const latestInvoice = subscription.latest_invoice;
        console.log("latestInvoice ", latestInvoice);
        if (!latestInvoice || typeof latestInvoice === "string") {
            throw new Error("Failed to retrieve latest invoice.");
        }
        // const paymentIntent = latestInvoice.payment_intent;
        // console.log("paymentIntent ",paymentIntent)
        // if (!paymentIntent) {
        //   console.error(
        //     "Payment intent is null for subscription:",
        //     subscription.id
        //   );
        //   return res.status(400).send({
        //     error: { message: "Payment intent is null. Please try again." },
        //   });
        // }
        const newSubscription = new Subscription_1.Subscription({
            userId: user === null || user === void 0 ? void 0 : user.id,
            planId: plan.id,
            StripeSubscriptionId: subscription.id,
            StripePriceId: plan.stripeProductObject.default_price,
            status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
            stripeSubscriptionObject: JSON.stringify(subscription),
        });
        await newSubscription.save();
        const newDebitTransaction = new Transaction_1.Transaction({
            userId: user === null || user === void 0 ? void 0 : user.id,
            // stripePaymentIntentId: paymentIntent.id,
            type: transactionTypeEnum_1.TransactionType.DEBIT,
            productType: productEnum_1.ProductType.SUBSCRIPTION,
            stripeProductId: plan.stripeProductId,
            productId: plan.id,
            amount: plan.price,
            status: transactionStatusEnum_1.TransactionStatus.PENDING,
        });
        await newDebitTransaction.save();
        // Comment for now
        // const newCreditTransaction = new Transaction({
        //   userId: plan?.userId,
        //   stripePaymentIntentId: paymentIntent.id,
        //   type: TransactionType.CREDIT,
        //   productType: ProductType.SUBSCRIPTION,
        //   stripeProductId: plan.stripeProductId,
        //   productId: plan.id,
        //   amount: plan.price,
        //   status: TransactionStatus.PENDING,
        // });
        // await newCreditTransaction.save();
        return res.status(200).send({
            status: true,
            subscriptionId: subscription.id,
            // clientSecret: paymentIntent.client_secret,
            //@ts-ignore
            //comment for now
            // clientSecret: subscription.latest_invoice.payment_intent.client_secret,
        });
    }
    catch (error) {
        console.error("Error creating subscription:", error);
        return res.status(400).send({ error: { message: error.message } });
    }
};
exports.createSubscription = createSubscription;
//# sourceMappingURL=createSubscription.js.map