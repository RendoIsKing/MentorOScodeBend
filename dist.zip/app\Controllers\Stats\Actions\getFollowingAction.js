"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFollowing = void 0;
const Connection_1 = require("../../../Models/Connection");
const getFollowing = async (req, res) => {
    try {
        const { id } = req.params;
        const following = await Connection_1.userConnection
            .find({ owner: id })
            .populate({
            path: "owner",
            populate: {
                path: "photo",
                model: "File",
            },
        })
            .populate({
            path: "followingTo",
            populate: {
                path: "photo",
                model: "File",
            },
        });
        return res.status(200).json({ data: following });
    }
    catch (error) {
        console.error("Error while fetching following", error);
        return res.status(500).json({ error: "Something went wrong." });
    }
};
exports.getFollowing = getFollowing;
//# sourceMappingURL=getFollowingAction.js.map