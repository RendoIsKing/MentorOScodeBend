"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCommentsByPostId = void 0;
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const File_1 = require("../../../Models/File");
const populateInteractedBy = async (comment) => {
    if (!comment)
        return null;
    let interaction = { ...comment.toObject() };
    if (interaction.replies && interaction.replies.length > 0) {
        interaction.replies = await Promise.all(interaction.replies.map(async (replyId) => {
            const reply = await Interaction_1.Interaction.findOne({
                _id: replyId,
                isDeleted: false,
            })
                .populate("interactedBy")
                .exec();
            return populateInteractedBy(reply);
        }));
    }
    interaction.interactedBy = await Interaction_1.Interaction.populate(interaction.interactedBy, { path: "interactedBy" });
    if (interaction.interactedBy && interaction.interactedBy.photoId) {
        const photo = await File_1.File.findById(interaction.interactedBy.photoId).exec();
        interaction.interactedBy.photo = photo;
    }
    return interaction;
};
const getCommentsByPostId = async (req, res) => {
    try {
        const { id } = req.params;
        const postComments = await Interaction_1.Interaction.find({
            post: id,
            type: InteractionTypeEnum_1.InteractionType.COMMENT,
            isDeleted: false,
            deletedAt: null,
        })
            .populate("interactedBy")
            .exec();
        const populatedComments = await Promise.all(postComments.map(async (comment) => {
            return populateInteractedBy(comment);
        }));
        const replyIds = new Set();
        const collectReplyIds = (comment) => {
            if (comment && comment.replies && comment.replies.length > 0) {
                comment.replies.forEach((reply) => {
                    if (reply) {
                        replyIds.add(reply._id.toString());
                        collectReplyIds(reply);
                    }
                });
            }
        };
        populatedComments.forEach((comment) => collectReplyIds(comment));
        // Filter out comments that are replies
        const filteredComments = populatedComments.filter((comment) => {
            return comment && !replyIds.has(comment._id.toString());
        });
        if (filteredComments.length === 0) {
            return res
                .status(200)
                .json({ data: [], error: { message: "No comments to show." } });
        }
        return res.json({
            data: filteredComments,
            message: "Comments retrieved successfully.",
        });
    }
    catch (error) {
        console.log("Error in getting all comments", error);
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.getCommentsByPostId = getCommentsByPostId;
//# sourceMappingURL=getAllCommentsAction.js.map