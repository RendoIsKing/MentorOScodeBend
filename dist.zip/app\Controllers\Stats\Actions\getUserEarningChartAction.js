"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserEarningChart = void 0;
const Transaction_1 = require("../../../Models/Transaction");
const mongoose_1 = require("mongoose");
const productEnum_1 = require("../../../../types/enums/productEnum");
const transactionTypeEnum_1 = require("../../../../types/enums/transactionTypeEnum");
const getDatesBetRange_1 = __importDefault(require("../../../../utils/getDatesBetRange"));
const getUserEarningChart = async (req, res) => {
    try {
        const user = req.user;
        const { startDate, endDate } = req.body;
        const transaction = await Transaction_1.Transaction.aggregate([
            {
                $match: {
                    userId: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $gte: new Date(startDate), $lt: new Date(endDate) },
                    type: transactionTypeEnum_1.TransactionType.CREDIT,
                },
            },
            {
                $addFields: {
                    customDate: {
                        $dateToString: {
                            format: "%Y-%m-%d",
                            date: "$createdAt",
                        },
                    },
                },
            },
            {
                $facet: {
                    subscription: [
                        {
                            $match: {
                                productType: productEnum_1.ProductType.SUBSCRIPTION,
                            },
                        },
                        {
                            $group: {
                                _id: "$customDate",
                                count: {
                                    $sum: "$amount",
                                },
                            },
                        },
                    ],
                    tips: [
                        {
                            $match: {
                                productType: productEnum_1.ProductType.TIPS,
                            },
                        },
                        {
                            $group: {
                                _id: "$customDate",
                                count: {
                                    $sum: "$amount",
                                },
                            },
                        },
                    ],
                    posts: [
                        {
                            $match: {
                                productType: productEnum_1.ProductType.POSTS,
                            },
                        },
                        {
                            $group: {
                                _id: "$customDate",
                                count: {
                                    $sum: "$amount",
                                },
                            },
                        },
                    ],
                },
            },
        ]);
        const dateRange = (0, getDatesBetRange_1.default)(startDate, endDate);
        let dateSet = new Set(dateRange);
        Object.entries(transaction[0]).forEach((item) => {
            const date = item[1].map((sub) => sub._id);
            date.map((date) => dateSet.add(date));
        });
        let dateSetArray = [...dateSet];
        const statsData = Object.entries(transaction[0]).map((item) => {
            return {
                label: item[0],
                data: dateSetArray.map((date) => {
                    const exist = item[1].find((subs) => subs._id == date);
                    if (exist) {
                        return exist.count / 100;
                    }
                    else {
                        return 0;
                    }
                }),
                paymentMethod: "Card",
            };
        });
        // const { id } = req.params;
        // let formattedDates = dateSetArray.map((date) => dateFormatter(date));
        return res.status(200).json({
            data: {
                labels: dateSetArray,
                datasets: statsData,
            },
            //   dateSetArray,
            //   dateSet,
            //   transaction,
        });
    }
    catch (error) {
        console.error("Error while fetching user earnings", error);
        return res.status(500).json({ error: "Something went wrong." });
    }
};
exports.getUserEarningChart = getUserEarningChart;
//# sourceMappingURL=getUserEarningChartAction.js.map