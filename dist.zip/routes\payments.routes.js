"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Payments_1 = __importDefault(require("../app/Controllers/Payments"));
const Middlewares_1 = require("../app/Middlewares");
const PaymentRoutes = (0, express_1.Router)();
PaymentRoutes.post("/create-session", Middlewares_1.Auth, Payments_1.default.createSession);
PaymentRoutes.get("/status", Middlewares_1.Auth, Payments_1.default.status);
exports.default = PaymentRoutes;
//# sourceMappingURL=payments.routes.js.map