"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteInterest = void 0;
const Interest_1 = require("../../../Models/Interest");
const mongoose_1 = require("mongoose");
const deleteInterest = async (req, res) => {
    try {
        const { id } = req.params;
        if (!mongoose_1.Types.ObjectId.isValid(id)) {
            return res
                .status(400)
                .json({ error: { message: "Invalid interest ID." } });
        }
        const interest = await Interest_1.Interest.findById(id);
        if (!interest) {
            return res
                .status(404)
                .json({ error: { message: "Interest not found." } });
        }
        interest.isDeleted = true;
        interest.deletedAt = new Date();
        await interest.save();
        return res.json({
            data: interest,
            message: "Interest deleted successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error in deleting a interest");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.deleteInterest = deleteInterest;
//# sourceMappingURL=deleteInterestAction.js.map