"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userConnection = void 0;
const mongoose_1 = require("mongoose");
const ConnectionsSchema_1 = require("../../database/schemas/ConnectionsSchema");
const userConnection = (0, mongoose_1.model)('userConnection', ConnectionsSchema_1.UserConnectionSchema);
exports.userConnection = userConnection;
//# sourceMappingURL=Connection.js.map