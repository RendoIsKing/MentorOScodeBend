"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Notifications_1 = require("../app/Controllers/Notifications");
const NotificationRoutes = (0, express_1.Router)();
// NotificationRoutes.post("/", Auth, NotificationController.sendNotification);
NotificationRoutes.get("/", Middlewares_1.Auth, Notifications_1.NotificationController.getNotifications);
NotificationRoutes.delete("/:id", Middlewares_1.Auth, Notifications_1.NotificationController.deleteNotification);
exports.default = NotificationRoutes;
//# sourceMappingURL=notification.routes.js.map