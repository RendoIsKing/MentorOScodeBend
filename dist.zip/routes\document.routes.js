"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Documents_1 = require("../app/Controllers/Documents");
const document = (0, express_1.Router)();
document.get("/:id", Middlewares_1.Auth, Documents_1.DocumentController.getDocumentById);
document.post("/verify/:id", Middlewares_1.OnlyAdmins, Documents_1.DocumentController.verifyDocument);
document.post("/", Middlewares_1.Auth, Documents_1.DocumentController.postDocument);
document.get("/", Middlewares_1.OnlyAdmins, Documents_1.DocumentController.getAllDocuments);
exports.default = document;
//# sourceMappingURL=document.routes.js.map