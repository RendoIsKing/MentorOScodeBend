"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadUserData = void 0;
const UserData_1 = require("../../../Models/UserData");
const archiver_1 = __importDefault(require("archiver"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const fs_extra_1 = __importDefault(require("fs-extra"));
const FILE_CHUNK_SIZE = parseInt(process.env.FILE_CHUNK_SIZE || "50") * 1024 * 1024;
const downloadUserData = async (req, res) => {
    try {
        const user = req.user;
        const userId = user.id;
        const userData = await UserData_1.UserData.find({ userId }).lean();
        if (!userData) {
            return res
                .status(404)
                .json({ error: { message: "User Data not found" } });
        }
        let fileData;
        let fileName;
        if (req.body.fileFormat === "text") {
            fileData = JSON.stringify(userData, null, 2);
            fileName = "userData.txt";
        }
        else {
            fileData = JSON.stringify(userData);
            fileName = "userData.json";
        }
        const tempDir = path_1.default.join(__dirname, "../../../temp", userId);
        fs_extra_1.default.ensureDirSync(tempDir);
        const zipFilePath = path_1.default.join(tempDir, "userData.zip");
        const output = fs_1.default.createWriteStream(zipFilePath);
        const archive = (0, archiver_1.default)("zip", {
            zlib: { level: 9 },
        });
        archive.pipe(output);
        archive.append(fileData, { name: fileName });
        await archive.finalize();
        const fileStats = fs_1.default.statSync(zipFilePath);
        if (fileStats.size > FILE_CHUNK_SIZE) {
            Math.ceil(fileStats.size / FILE_CHUNK_SIZE);
            const chunkFiles = [];
            const readStream = fs_1.default.createReadStream(zipFilePath, {
                highWaterMark: FILE_CHUNK_SIZE,
            });
            let chunkIndex = 0;
            for await (const chunk of readStream) {
                const chunkFilePath = path_1.default.join(tempDir, `userData.part${chunkIndex + 1}.zip`);
                fs_1.default.writeFileSync(chunkFilePath, chunk);
                chunkFiles.push(chunkFilePath);
                chunkIndex++;
            }
            const downloadLinks = chunkFiles.map((file, index) => ({
                part: index + 1,
                // link: `${req.protocol}://${req.get(
                //   "host"
                // )}/download/${userId}/userData.part${index + 1}.zip`,
                link: `/download/${userId}/userData.part${index + 1}.zip`,
            }));
            return res.json({
                message: "User data ready for download",
                downloadLinks,
            });
        }
        else {
            // const downloadLink = `${req.protocol}://${req.get(
            //   "host"
            // )}/download/${userId}/userData.zip`;
            const downloadLink = `/download/${userId}/userData.zip`;
            return res.json({
                message: "User data ready for download",
                downloadLink,
            });
        }
    }
    catch (error) {
        console.log("Error while downloading user data", error);
        res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.downloadUserData = downloadUserData;
//# sourceMappingURL=downloadUserData.js.map