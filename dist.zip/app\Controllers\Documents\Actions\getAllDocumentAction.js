"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllDocuments = void 0;
const RolesEnum_1 = require("../../../../types/RolesEnum");
const Document_1 = require("../../../Models/Document");
const getAllDocuments = async (_req, res) => {
    var _a;
    try {
        const LIMIT = 10;
        const perPage = _req.query &&
            _req.query.perPage &&
            parseInt(_req.query.perPage) > 0
            ? parseInt(_req.query.perPage)
            : LIMIT;
        const page = _req.query && _req.query.page && parseInt(_req.query.page) > 0
            ? parseInt(_req.query.page)
            : 1;
        let skip = (page - 1) * perPage;
        let dataToFind = {
            role: { $ne: RolesEnum_1.RolesEnum.ADMIN },
            isDeleted: false,
        };
        if (_req.query.search) {
            dataToFind = {
                ...dataToFind,
                $or: [{ title: { $regex: _req.query.search } }],
            };
            skip = 0;
        }
        const [query] = await Document_1.Document.aggregate([
            {
                $facet: {
                    results: [
                        { $match: dataToFind },
                        {
                            $lookup: {
                                from: "users",
                                localField: "userId",
                                foreignField: "_id",
                                as: "userInfo",
                            },
                        },
                        { $skip: skip },
                        { $limit: perPage },
                        { $sort: { createdAt: -1 } },
                    ],
                    documentCount: [{ $match: dataToFind }, { $count: "count" }],
                },
            },
        ]);
        const documentCount = ((_a = query.documentCount[0]) === null || _a === void 0 ? void 0 : _a.count) || 0;
        const totalPages = Math.ceil(documentCount / perPage);
        return res.json({
            data: query.results,
            meta: {
                perPage: perPage,
                page: _req.query.page || 1,
                pages: totalPages,
                total: documentCount,
            },
        });
    }
    catch (err) {
        console.log(err, "Error in getting all documents");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.getAllDocuments = getAllDocuments;
//# sourceMappingURL=getAllDocumentAction.js.map