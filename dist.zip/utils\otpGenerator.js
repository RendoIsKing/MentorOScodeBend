"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const otpGenerator = () => Math.floor(100000 + Math.random() * 900000);
exports.default = otpGenerator;
//# sourceMappingURL=otpGenerator.js.map