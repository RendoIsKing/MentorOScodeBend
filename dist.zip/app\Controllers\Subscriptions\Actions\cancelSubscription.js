"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelSubscriptions = void 0;
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const Subscription_1 = require("../../../Models/Subscription");
const SubscriptionStatusEnum_1 = require("../../../../types/enums/SubscriptionStatusEnum");
const cancelSubscriptions = async (params) => {
    const { userId } = params;
    try {
        const activeSubscriptions = await Subscription_1.Subscription.find({
            userId,
            status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
        });
        if (activeSubscriptions.length > 0) {
            const cancelPromises = activeSubscriptions.map(async (activeSubscription) => {
                const stripeSubscription = await stripe_1.default.subscriptions.cancel(activeSubscription.StripeSubscriptionId);
                activeSubscription.status = SubscriptionStatusEnum_1.SubscriptionStatusEnum.CANCEL;
                await activeSubscription.save();
                return stripeSubscription;
            });
            await Promise.all(cancelPromises);
        }
    }
    catch (error) {
        console.error("Error cancelling subscriptions:", error);
        throw new Error(error.message);
    }
};
exports.cancelSubscriptions = cancelSubscriptions;
//# sourceMappingURL=cancelSubscription.js.map