"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import { Express } from "express";
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const CardDetails_1 = require("../app/Controllers/CardDetails");
const card = (0, express_1.Router)();
card.post("/", Middlewares_1.Auth, CardDetails_1.CardDetailsController.getCardDetails);
card.get("/", Middlewares_1.Auth, CardDetails_1.CardDetailsController.listAllCardsOfUser);
card.post("/:cardId", Middlewares_1.Auth, CardDetails_1.CardDetailsController.setDefaultCard);
card.delete("/:cardId", Middlewares_1.Auth, CardDetails_1.CardDetailsController.deleteCard);
exports.default = card;
//# sourceMappingURL=cardDetails.routes.js.map