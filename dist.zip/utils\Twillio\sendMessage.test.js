"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendMessageTest = sendMessageTest;
const twilio_1 = __importDefault(require("twilio"));
async function sendMessageTest(to, message) {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_FROM_NUMBER;
    const client = (0, twilio_1.default)(sid, token);
    return client.messages.create({ body: message, to: `+${to}`, from });
}
//# sourceMappingURL=sendMessage.test.js.map