"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NutritionPlanSchema = void 0;
const mongoose_1 = require("mongoose");
exports.NutritionPlanSchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    version: { type: Number, required: true },
    isCurrent: { type: Boolean, default: true },
    dailyTargets: { kcal: Number, protein: Number, carbs: Number, fat: Number },
    notes: String,
    sourceText: String,
    meals: [{ name: String, items: [String] }],
    guidelines: { type: [String], default: [] },
    days: [{ label: String, meals: [{ name: String, items: [String] }] }],
}, { timestamps: true });
exports.NutritionPlanSchema.index({ userId: 1, version: -1 });
//# sourceMappingURL=NutritionPlanSchema.js.map