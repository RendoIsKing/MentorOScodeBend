"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoalSchema = void 0;
const mongoose_1 = require("mongoose");
exports.GoalSchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    version: { type: Number, required: true },
    isCurrent: { type: Boolean, default: true },
    targetWeightKg: Number,
    strengthTargets: String,
    horizonWeeks: Number,
    sourceText: String,
    caloriesDailyDeficit: Number,
    weeklyWeightLossKg: Number,
    weeklyExerciseMinutes: Number,
    hydrationLiters: Number,
    plan: {
        shortTerm: [String],
        mediumTerm: [String],
        longTerm: [String],
        tips: [String],
    },
}, { timestamps: true });
exports.GoalSchema.index({ userId: 1, version: -1 });
//# sourceMappingURL=GoalSchema.js.map