"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOwnTransactions = void 0;
const mongoose_1 = require("mongoose");
const Transaction_1 = require("../../../Models/Transaction");
const getOwnTransactions = async (_req, res) => {
    var _a;
    try {
        const user = _req.user;
        const LIMIT = 10;
        const perPage = _req.query &&
            _req.query.perPage &&
            parseInt(_req.query.perPage) > 0
            ? parseInt(_req.query.perPage)
            : LIMIT;
        const page = _req.query && _req.query.page && parseInt(_req.query.page) > 0
            ? parseInt(_req.query.page)
            : 1;
        let skip = (page - 1) * perPage;
        const [query] = await Transaction_1.Transaction.aggregate([
            {
                $match: {
                    userId: new mongoose_1.Types.ObjectId(user.id),
                },
            },
            {
                $facet: {
                    results: [
                        { $skip: skip },
                        { $limit: perPage },
                        { $sort: { createdAt: -1 } },
                    ],
                    transactionCount: [{ $count: "count" }],
                },
            },
        ]);
        const transactionCount = ((_a = query.transactionCount[0]) === null || _a === void 0 ? void 0 : _a.count) || 0;
        const totalPages = Math.ceil(transactionCount / perPage);
        return res.json({
            data: query.results,
            meta: {
                perPage: perPage,
                page: _req.query.page || 1,
                pages: totalPages,
                total: transactionCount,
            },
        });
        // if (!transactions) {
        //   return res.status(404).json({ error: "No Transactions found" });
        // }
        // return res.json({
        //   data: transactions,
        // });
    }
    catch (error) {
        console.error("Error retrieving Transactions of the user:", error);
        return res.status(500).json({ error: "Internal Server Error" });
    }
};
exports.getOwnTransactions = getOwnTransactions;
//# sourceMappingURL=GetTransactionsofUser.js.map