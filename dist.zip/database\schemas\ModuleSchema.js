"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModuleSchema = void 0;
const mongoose_1 = require("mongoose");
const ModuleSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: true,
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: {
        type: Date,
        default: null,
    },
}, { timestamps: true });
exports.ModuleSchema = ModuleSchema;
//# sourceMappingURL=ModuleSchema.js.map