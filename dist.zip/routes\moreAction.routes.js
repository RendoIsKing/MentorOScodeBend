"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const MoreUserActions_1 = require("../app/Controllers/MoreUserActions");
const moreActionRoutes = (0, express_1.Router)();
moreActionRoutes.post("/", Middlewares_1.Auth, MoreUserActions_1.MoreActionsController.notInterested);
moreActionRoutes.post("/query", Middlewares_1.Auth, MoreUserActions_1.MoreActionsController.postUserQuery);
moreActionRoutes.get("/query", 
//   OnlyAdmins,
MoreUserActions_1.MoreActionsController.getUserQueries);
moreActionRoutes.post("/update-report/:id", Middlewares_1.OnlyAdmins, MoreUserActions_1.MoreActionsController.updateUserReport);
exports.default = moreActionRoutes;
//# sourceMappingURL=moreAction.routes.js.map