"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const StudentSnapshot_1 = __importDefault(require("../../models/StudentSnapshot"));
const r = (0, express_1.Router)();
r.get("/:userId/snapshot", async (req, res) => {
    try {
        const { userId } = req.params;
        const snap = await StudentSnapshot_1.default.findOne({ user: userId });
        if (!snap)
            return res.status(404).json({ error: "No snapshot" });
        return res.json({ ok: true, snapshot: snap });
    }
    catch (e) {
        return res.status(500).json({ error: "Snapshot fetch failed" });
    }
});
exports.default = r;
//# sourceMappingURL=snapshot.js.map