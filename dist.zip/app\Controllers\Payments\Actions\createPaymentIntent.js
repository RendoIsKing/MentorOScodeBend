"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const transactionStatusEnum_1 = require("../../../../types/enums/transactionStatusEnum");
const transactionTypeEnum_1 = require("../../../../types/enums/transactionTypeEnum");
const Transaction_1 = require("../../../Models/Transaction");
const createPaymentIntent = async (params) => {
    try {
        if (!process.env.STRIPE_CURRENCY) {
            throw new Error("STRIPE_CURRENCY is mising");
        }
        if (params.amount === 0) {
            let intentInstance = await stripe_1.default.setupIntents.create({
                usage: "off_session",
                payment_method_types: ["card"],
                customer: params.clientStripeId,
                metadata: { userId: String(params.userId) },
            }, params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : undefined);
            await Transaction_1.Transaction.create({
                userId: params.userId,
                amount: 0,
                type: transactionTypeEnum_1.TransactionType.CARD_ADD,
                status: transactionStatusEnum_1.TransactionStatus.SUCCESS,
                description: "Card added successfully",
                referenceId: intentInstance.id,
            });
            return intentInstance;
        }
        else {
            let paymentInstanceIntent = await stripe_1.default.paymentIntents.create({
                amount: params.amount,
                currency: `${process.env.STRIPE_CURRENCY}`,
                automatic_payment_methods: { enabled: true },
                customer: params.clientStripeId,
                metadata: { userId: String(params.userId) },
            }, params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : undefined);
            await Transaction_1.Transaction.create({
                userId: params.userId,
                amount: params.amount,
                // type: TransactionType.BALANCE_ADD,
                status: transactionStatusEnum_1.TransactionStatus.PENDING,
                description: "Balance adding transaction initiated",
                referenceId: paymentInstanceIntent.id,
            });
            return paymentInstanceIntent;
        }
    }
    catch (err) {
        await Transaction_1.Transaction.create({
            userId: params.userId,
            amount: params.amount,
            // type:
            //   params.amount === 0
            //     ? TransactionType.CARD_ADD
            //     // : TransactionType.BALANCE_ADD,
            status: transactionStatusEnum_1.TransactionStatus.FAILED,
            description: `Transaction failed: ${err.message}`,
            referenceId: null,
        });
        throw err;
    }
};
exports.default = createPaymentIntent;
//# sourceMappingURL=createPaymentIntent.js.map