"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.notInterested = void 0;
const class_validator_1 = require("class-validator");
const Post_1 = require("../../../Models/Post");
const postTypeEnum_1 = require("../../../../types/enums/postTypeEnum");
const MoreAction_1 = require("../../../Models/MoreAction");
const userActionTypeEnum_1 = require("../../../../types/enums/userActionTypeEnum");
const User_1 = require("../../../Models/User");
const mongoose_1 = __importDefault(require("mongoose"));
const reportingStatusEnum_1 = require("../../../../types/enums/reportingStatusEnum");
const notInterested = async (req, res) => {
    try {
        const user = req.user;
        const validationErrors = await (0, class_validator_1.validate)(req.body);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        let moreAction;
        if (req.body.actionType === userActionTypeEnum_1.userActionType.NOT_INTERESTED) {
            const post = Post_1.Post.findOne({
                _id: new mongoose_1.default.Types.ObjectId(req.body.actionOnPost),
                type: postTypeEnum_1.PostType.POST,
                isDeleted: false,
                deletedAt: null,
            });
            if (!post) {
                return res.status(404).json({ error: { message: "Post not found" } });
            }
            moreAction = new MoreAction_1.MoreAction({
                actionByUser: user.id,
                actionOnPost: req.body.actionOnPost,
                actionType: userActionTypeEnum_1.userActionType.NOT_INTERESTED,
            });
            await moreAction.save();
        }
        else {
            const userToReport = await User_1.User.findOne({
                _id: new mongoose_1.default.Types.ObjectId(req.body.actionToUser),
                isDeleted: false,
                deletedAt: null,
            });
            if (!userToReport) {
                return res.status(404).json({ error: { message: "Post not found" } });
            }
            moreAction = new MoreAction_1.MoreAction({
                actionByUser: user.id,
                actionToUser: userToReport.id,
                actionType: userActionTypeEnum_1.userActionType.REPORT,
                reason: req.body.reason,
                rreportStatus: reportingStatusEnum_1.ReportStatusEnum.PENDING,
            });
            await moreAction.save();
        }
        return res.json({
            data: moreAction,
            message: "Action added successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while marking the post not Interested");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.notInterested = notInterested;
//# sourceMappingURL=notInterested.js.map