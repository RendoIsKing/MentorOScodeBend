"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDatabase = void 0;
const mongoose_1 = require("mongoose");
const connectDatabase = async () => {
    if (mongoose_1.connection.readyState !== 0) {
        return;
    }
    const raw = (process.env.DB_URL || process.env.MONGO_URI || process.env.MONGODB_URI || process.env.DATABASE_URL);
    const uri = (raw || '').trim();
    const source = process.env.DB_URL ? 'DB_URL' : (process.env.MONGO_URI ? 'MONGO_URI' : (process.env.MONGODB_URI ? 'MONGODB_URI' : (process.env.DATABASE_URL ? 'DATABASE_URL' : 'none')));
    if (!uri) {
        throw new Error("DB_URL (or MONGO_URI/MONGODB_URI/DATABASE_URL) is not set. Add it to backend/.env or Railway Variables");
    }
    console.log(`[DB] Connecting using ${source}`);
    await (0, mongoose_1.connect)(uri);
    console.log(`Database connected Successfully`);
};
exports.connectDatabase = connectDatabase;
//# sourceMappingURL=dbConnection.js.map