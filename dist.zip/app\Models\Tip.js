"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tips = void 0;
const mongoose_1 = require("mongoose");
const TipSchema_1 = require("../../database/schemas/TipSchema");
const Tips = (0, mongoose_1.model)("tips", TipSchema_1.TipsSchema);
exports.Tips = Tips;
//# sourceMappingURL=Tip.js.map