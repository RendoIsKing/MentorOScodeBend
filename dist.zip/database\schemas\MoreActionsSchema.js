"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MoreActionSchema = void 0;
const mongoose_1 = require("mongoose");
const userActionTypeEnum_1 = require("../../types/enums/userActionTypeEnum");
const reportReasonEnum_1 = require("../../types/enums/reportReasonEnum");
const reportingStatusEnum_1 = require("../../types/enums/reportingStatusEnum");
const MoreActionSchema = new mongoose_1.Schema({
    actionType: {
        type: String,
        enum: [
            userActionTypeEnum_1.userActionType.NOT_INTERESTED,
            userActionTypeEnum_1.userActionType.REPORT,
            userActionTypeEnum_1.userActionType.USER_QUERY,
        ],
    },
    reportStatus: {
        type: String,
        enum: [
            reportingStatusEnum_1.ReportStatusEnum.APPROVED,
            reportingStatusEnum_1.ReportStatusEnum.CANCEL,
            reportingStatusEnum_1.ReportStatusEnum.PENDING,
        ],
    },
    reason: {
        type: String,
        enum: [
            reportReasonEnum_1.ReasonEnum.FRAUD,
            reportReasonEnum_1.ReasonEnum.HATE_OR_HARASSMENT,
            reportReasonEnum_1.ReasonEnum.INTELLECTUAL_PROPERTY_VIOLATION,
            reportReasonEnum_1.ReasonEnum.OTHER,
            reportReasonEnum_1.ReasonEnum.PRETENDING_TO_BE_SOMEONE_ELSE,
            reportReasonEnum_1.ReasonEnum.REGULATED_GOODS_AND_ACTIVITIES,
            reportReasonEnum_1.ReasonEnum.SPAM,
            reportReasonEnum_1.ReasonEnum.VIOLENCE,
        ],
    },
    query: {
        type: String,
    },
    actionByUser: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    actionToUser: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    actionOnPost: {
        type: mongoose_1.Types.ObjectId,
        ref: "Post",
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: {
        type: Date,
        default: null,
    },
}, { timestamps: true });
exports.MoreActionSchema = MoreActionSchema;
//# sourceMappingURL=MoreActionsSchema.js.map