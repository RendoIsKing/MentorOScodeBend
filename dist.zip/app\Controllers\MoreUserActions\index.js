"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MoreActionsController = void 0;
const notInterested_1 = require("./Actions/notInterested");
const postUserQuery_1 = require("./Actions/postUserQuery");
const getAllUserQuery_1 = require("./Actions/getAllUserQuery");
const updateUserReport_1 = require("./Actions/updateUserReport");
class MoreActionsController {
}
exports.MoreActionsController = MoreActionsController;
_a = MoreActionsController;
MoreActionsController.notInterested = async (req, res) => {
    return (0, notInterested_1.notInterested)(req, res);
};
MoreActionsController.postUserQuery = async (req, res) => {
    return (0, postUserQuery_1.postUserQuery)(req, res);
};
MoreActionsController.getUserQueries = async (req, res) => {
    return (0, getAllUserQuery_1.getUserQueries)(req, res);
};
MoreActionsController.updateUserReport = async (req, res) => {
    return (0, updateUserReport_1.updateUserReport)(req, res);
};
//# sourceMappingURL=index.js.map