"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCustomerOnStripe = void 0;
const axios_1 = __importDefault(require("axios"));
const User_1 = require("../../app/Models/User");
const qs = require("qs");
const POST = "post";
const createCustomerOnStripe = (params) => {
    return new Promise((resolve, reject) => {
        const secret = process.env.STRIPE_SECRET_KEY;
        const url = process.env.STRIPE_CUSTOMER_CREATE_URL;
        if (!secret || !url) {
            console.error("❌ Stripe ENV missing:", {
                STRIPE_SECRET_KEY: secret,
                STRIPE_CUSTOMER_CREATE_URL: url,
            });
            return reject(new Error("STRIPE_SECRET_KEY or STRIPE_CUSTOMER_CREATE_URL is Missing"));
        }
        const config = {
            method: POST,
            url,
            headers: {
                Authorization: `Bearer ${secret}`,
            },
            data: qs.stringify({
                name: params.firstName,
                email: params === null || params === void 0 ? void 0 : params.email,
            }),
        };
        (0, axios_1.default)(config)
            .then(async (response) => {
            if (response.data.id) {
                await User_1.User.findByIdAndUpdate(params.userId, {
                    isStripeCustomer: true,
                    stripeClientId: response.data.id,
                });
            }
            resolve(response);
        })
            .catch((err) => {
            var _a, _b;
            console.log("Stripe create error:", (_a = err.response) === null || _a === void 0 ? void 0 : _a.data);
            reject((_b = err.response) === null || _b === void 0 ? void 0 : _b.data);
        });
    });
};
exports.createCustomerOnStripe = createCustomerOnStripe;
//# sourceMappingURL=createCustomerOnStripe.js.map