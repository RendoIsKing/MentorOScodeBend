"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const SubscriptionPlan_1 = require("../app/Controllers/SubscriptionPlan");
const subscriptionPlan = (0, express_1.Router)();
subscriptionPlan.post("/product", Middlewares_1.Auth, SubscriptionPlan_1.SubscriptionPlanController.createProduct);
subscriptionPlan.post("/", Middlewares_1.Auth, SubscriptionPlan_1.SubscriptionPlanController.createPlan);
subscriptionPlan.get("/", Middlewares_1.Auth, SubscriptionPlan_1.SubscriptionPlanController.getSubscriptionPlan);
subscriptionPlan.post("/:id", Middlewares_1.Auth, SubscriptionPlan_1.SubscriptionPlanController.updateSubscriptionPlan);
subscriptionPlan.delete("/:id", Middlewares_1.Auth, SubscriptionPlan_1.SubscriptionPlanController.softDeleteSubscriptionPlan);
subscriptionPlan.get("/subscription", Middlewares_1.Auth, SubscriptionPlan_1.SubscriptionPlanController.oneSameSubscirptionPlanForAllUsers);
exports.default = subscriptionPlan;
//# sourceMappingURL=subscriptionPlan.routes.js.map