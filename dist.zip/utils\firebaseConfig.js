"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const firebase_admin_1 = __importDefault(require("firebase-admin"));
if (!firebase_admin_1.default.apps.length) {
    const json = process.env.FIREBASE_SERVICE_ACCOUNT_JSON
        ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
        : undefined;
    firebase_admin_1.default.initializeApp({
        credential: json ? firebase_admin_1.default.credential.cert(json) : firebase_admin_1.default.credential.applicationDefault(),
    });
}
exports.default = firebase_admin_1.default;
//# sourceMappingURL=firebaseConfig.js.map