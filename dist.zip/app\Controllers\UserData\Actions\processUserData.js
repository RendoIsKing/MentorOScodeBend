"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processUserData = void 0;
const Interaction_1 = require("../../../Models/Interaction");
const Post_1 = require("../../../Models/Post");
const Subscription_1 = require("../../../Models/Subscription");
const Transaction_1 = require("../../../Models/Transaction");
const User_1 = require("../../../Models/User");
const UserData_1 = require("../../../Models/UserData");
const fileFormatEnum_1 = require("../../../../types/enums/fileFormatEnum");
const processUserData = async (req, res) => {
    try {
        const user = req.user;
        const requestedUserId = user._id;
        const { fileFormat } = req.body;
        if (!fileFormat) {
            return res
                .status(400)
                .json({ error: { message: "File format is required" } });
        }
        if (!Object.values(fileFormatEnum_1.FileFormatEnum).includes(fileFormat)) {
            return res
                .status(400)
                .json({ error: { message: "Invalid file format" } });
        }
        const existingDatasets = await UserData_1.UserData.find({
            user: requestedUserId,
            fileFormat,
            isExpired: false,
        });
        if (existingDatasets.length > 1) {
            await UserData_1.UserData.updateMany({ user: requestedUserId, fileFormat, isExpired: false }, { $set: { isExpired: true } });
        }
        const userInfo = await User_1.User.findById(requestedUserId, "username photoId bio email completePhoneNumber").lean();
        const posts = await Post_1.Post.find({ user: requestedUserId }).lean();
        const interactions = await Interaction_1.Interaction.find({
            interactedBy: requestedUserId,
        }).lean();
        const transactions = await Transaction_1.Transaction.find({
            userId: requestedUserId,
        }).lean();
        const subscriptions = await Subscription_1.Subscription.find({
            userId: requestedUserId,
        }).lean();
        const aggregatedData = {
            userInfo,
            posts,
            interactions,
            transactions,
            subscriptions,
        };
        const userData = new UserData_1.UserData({
            user: requestedUserId,
            data: aggregatedData,
            fileFormat,
            downloadBefore: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        });
        await userData.save();
        return res.json({ userData });
    }
    catch (error) {
        console.log("Error while processing user data", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.processUserData = processUserData;
//# sourceMappingURL=processUserData.js.map