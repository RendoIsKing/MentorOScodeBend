"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupportController = void 0;
const FAQ_1 = require("../../Models/FAQ");
class SupportController {
}
exports.SupportController = SupportController;
_a = SupportController;
SupportController.getFAQ = async (req, res) => {
    try {
        const faqs = await FAQ_1.FAQ.find().exec();
        return res.status(200).json(faqs);
    }
    catch (err) {
        console.error("Error fetching FAQs:", err);
        return res.status(500).json({ error: "Failed to fetch FAQs" });
    }
};
SupportController.createFAQ = async (req, res) => {
    try {
        const { topics, isDeleted, deletedAt } = req.body;
        if (!topics) {
            return res.status(400).json({ error: "Topics array is required" });
        }
        const newFAQ = new FAQ_1.FAQ({
            topics,
            isDeleted: isDeleted || false,
            deletedAt: deletedAt || null,
        });
        const savedFAQ = await newFAQ.save();
        return res.status(201).json(savedFAQ);
    }
    catch (err) {
        console.error("Error creating FAQ:", err);
        return res.status(500).json({ error: "Failed to create FAQ" });
    }
};
//# sourceMappingURL=index.js.map