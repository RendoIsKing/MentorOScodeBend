"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Support_1 = require("../app/Controllers/Support");
const SupportRoutes = (0, express_1.Router)();
SupportRoutes.get("/faq", Support_1.SupportController.getFAQ);
SupportRoutes.post("/faq", Middlewares_1.OnlyAdmins, Support_1.SupportController.createFAQ);
exports.default = SupportRoutes;
//# sourceMappingURL=support.routes.js.map