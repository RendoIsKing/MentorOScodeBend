"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Stats_1 = require("../app/Controllers/Stats");
const StatsRoutes = (0, express_1.Router)();
StatsRoutes.get("/followers/:id", Middlewares_1.Auth, Stats_1.StatsController.getFollowers);
StatsRoutes.get("/following/:id", Middlewares_1.Auth, Stats_1.StatsController.getFollowing);
StatsRoutes.get("/posts-likes/:id", Middlewares_1.Auth, Stats_1.StatsController.getPostLikes);
StatsRoutes.post("/user-earning", Middlewares_1.Auth, Stats_1.StatsController.getEarning);
StatsRoutes.post("/user-chart", Middlewares_1.Auth, Stats_1.StatsController.getEarningChart);
StatsRoutes.get("/subscribers/:id", Stats_1.StatsController.getSubscribers);
StatsRoutes.post("/creator", Middlewares_1.Auth, Stats_1.StatsController.creatorStats);
exports.default = StatsRoutes;
//# sourceMappingURL=stats.routes.js.map