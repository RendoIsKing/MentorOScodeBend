"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDataController = void 0;
const processUserData_1 = require("./Actions/processUserData");
const downloadUserData_1 = require("./Actions/downloadUserData");
const getUserData_1 = require("./Actions/getUserData");
class UserDataController {
}
exports.UserDataController = UserDataController;
UserDataController.processUserData = (req, res) => {
    (0, processUserData_1.processUserData)(req, res);
};
UserDataController.downloadUserData = (req, res) => {
    (0, downloadUserData_1.downloadUserData)(req, res);
};
UserDataController.getUserData = (req, res) => {
    (0, getUserData_1.getUserData)(req, res);
};
//# sourceMappingURL=index.js.map