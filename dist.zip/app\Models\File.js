"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.File = void 0;
const mongoose_1 = require("mongoose");
const FileSchema_1 = require("../../database/schemas/FileSchema");
const File = (0, mongoose_1.model)('File', FileSchema_1.FileSchema);
exports.File = File;
//# sourceMappingURL=File.js.map