"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostSchema = void 0;
const mongoose_1 = require("mongoose");
const mediaTypeEnum_1 = require("../../types/enums/mediaTypeEnum");
const privacyEnums_1 = require("../../types/enums/privacyEnums");
const postStatuseEnum_1 = require("../../types/enums/postStatuseEnum");
const postTypeEnum_1 = require("../../types/enums/postTypeEnum");
const featureSchema_1 = require("./featureSchema");
const LocationSchema = new mongoose_1.Schema({
    x: { type: Number, required: true },
    y: { type: Number, required: true },
});
const UserTagSchema = new mongoose_1.Schema({
    location: { type: LocationSchema, required: true },
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", required: true },
});
const MediaSchema = new mongoose_1.Schema({
    mediaId: mongoose_1.Types.ObjectId,
    mediaType: {
        type: String,
        enum: [mediaTypeEnum_1.MediaType.IMAGE, mediaTypeEnum_1.MediaType.LIVE, mediaTypeEnum_1.MediaType.VIDEO, mediaTypeEnum_1.MediaType.STORY],
    },
});
const PostSchema = new mongoose_1.Schema({
    media: [MediaSchema],
    content: String,
    price: {
        type: Number,
        default: 0,
    },
    orientation: String,
    tags: {
        type: [String],
    },
    privacy: {
        type: String,
        enum: [
            privacyEnums_1.Privacy.FOLLOWERS,
            privacyEnums_1.Privacy.FRIENDS,
            privacyEnums_1.Privacy.PRIVATE,
            privacyEnums_1.Privacy.PUBLIC,
            privacyEnums_1.Privacy.SUBSCRIBER,
            privacyEnums_1.Privacy.PAY_PER_VIEW,
        ],
    },
    status: {
        type: String,
        enum: [
            postStatuseEnum_1.PostStatusEnum.DRAFT,
            postStatuseEnum_1.PostStatusEnum.FLAGGED,
            postStatuseEnum_1.PostStatusEnum.PUBLISHED,
            postStatuseEnum_1.PostStatusEnum.RESTRICTED,
            postStatuseEnum_1.PostStatusEnum.UNPUBLISHED,
        ],
    },
    user: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    isActive: {
        default: true,
        type: Boolean,
    },
    isPinned: {
        default: false,
        type: Boolean,
    },
    isDeleted: {
        default: false,
        type: Boolean,
    },
    deletedAt: Date,
    type: {
        type: String,
        enum: [postTypeEnum_1.PostType.POST, postTypeEnum_1.PostType.STORY],
    },
    accessibleTo: {
        type: [{ type: featureSchema_1.FeatureSchema }],
        default: [],
    },
    userTags: {
        type: [{ type: UserTagSchema }],
        default: [],
    },
    stripeProductId: String,
    stripeProduct: {
        type: {},
        required: false,
    },
}, {
    timestamps: true,
});
exports.PostSchema = PostSchema;
//# sourceMappingURL=postSchema.js.map