"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const UserData_1 = require("../app/Controllers/UserData");
const userDataRoutes = (0, express_1.Router)();
userDataRoutes.post("/", Middlewares_1.Auth, UserData_1.UserDataController.processUserData);
userDataRoutes.post("/download", Middlewares_1.Auth, UserData_1.UserDataController.downloadUserData);
userDataRoutes.get("/", Middlewares_1.Auth, UserData_1.UserDataController.getUserData);
exports.default = userDataRoutes;
//# sourceMappingURL=userData.routes.js.map