"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionController = void 0;
const GetTransactionsofUser_1 = require("./Actions/GetTransactionsofUser");
const getAllTransactions_1 = require("./Actions/getAllTransactions");
class TransactionController {
}
exports.TransactionController = TransactionController;
TransactionController.getOwnTransactions = (req, res) => {
    (0, GetTransactionsofUser_1.getOwnTransactions)(req, res);
};
TransactionController.getAllTransactions = (req, res) => {
    (0, getAllTransactions_1.getAllTransactions)(req, res);
};
//# sourceMappingURL=index.js.map