"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategoryController = exports.ModuleController = exports.ProfileController = exports.UsersControllers = exports.AuthController = void 0;
const auth_controller_1 = require("./auth.controller");
Object.defineProperty(exports, "AuthController", { enumerable: true, get: function () { return auth_controller_1.AuthController; } });
const user_controller_1 = require("./user.controller");
Object.defineProperty(exports, "UsersControllers", { enumerable: true, get: function () { return user_controller_1.UsersControllers; } });
const profile_controller_1 = require("./profile.controller");
Object.defineProperty(exports, "ProfileController", { enumerable: true, get: function () { return profile_controller_1.ProfileController; } });
const module_controller_1 = require("./module.controller");
Object.defineProperty(exports, "ModuleController", { enumerable: true, get: function () { return module_controller_1.ModuleController; } });
const category_controller_1 = require("./category.controller");
Object.defineProperty(exports, "CategoryController", { enumerable: true, get: function () { return category_controller_1.CategoryController; } });
//# sourceMappingURL=index.js.map