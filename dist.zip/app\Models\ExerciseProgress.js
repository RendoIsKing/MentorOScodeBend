"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExerciseProgress = void 0;
const mongoose_1 = require("mongoose");
const ExerciseProgressSchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', index: true, required: true },
    exercise: { type: String, index: true, required: true },
    date: { type: String, index: true, required: true },
    value: { type: Number, required: true },
}, { timestamps: true });
ExerciseProgressSchema.index({ userId: 1, exercise: 1, date: 1 }, { unique: true });
exports.ExerciseProgress = (0, mongoose_1.model)('ExerciseProgress', ExerciseProgressSchema);
//# sourceMappingURL=ExerciseProgress.js.map