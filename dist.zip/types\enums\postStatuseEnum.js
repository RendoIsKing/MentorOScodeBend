"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostStatusEnum = void 0;
var PostStatusEnum;
(function (PostStatusEnum) {
    PostStatusEnum["DRAFT"] = "draft";
    PostStatusEnum["PUBLISHED"] = "published";
    PostStatusEnum["UNPUBLISHED"] = "unpublished";
    PostStatusEnum["RESTRICTED"] = "restricted";
    PostStatusEnum["FLAGGED"] = "flagged";
})(PostStatusEnum || (exports.PostStatusEnum = PostStatusEnum = {}));
//# sourceMappingURL=postStatuseEnum.js.map