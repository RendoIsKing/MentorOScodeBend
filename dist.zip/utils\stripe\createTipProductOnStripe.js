"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTipProductOnStripe = void 0;
const _1 = __importDefault(require("."));
const createTipProductOnStripe = async (product) => {
    try {
        const stripeTipProduct = await _1.default.products.create({
            name: product.title,
        });
        return stripeTipProduct;
    }
    catch (error) {
        console.error(error, "ERROR IN CREATING TIP PRODUCT");
        // return error;
    }
};
exports.createTipProductOnStripe = createTipProductOnStripe;
//# sourceMappingURL=createTipProductOnStripe.js.map