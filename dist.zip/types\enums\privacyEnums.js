"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Privacy = void 0;
var Privacy;
(function (Privacy) {
    Privacy["PUBLIC"] = "public";
    Privacy["PRIVATE"] = "private";
    Privacy["FRIENDS"] = "friends";
    Privacy["FOLLOWERS"] = "followers";
    Privacy["SUBSCRIBER"] = "subscriber";
    Privacy["PAY_PER_VIEW"] = "pay-per-view";
})(Privacy || (exports.Privacy = Privacy = {}));
//# sourceMappingURL=privacyEnums.js.map