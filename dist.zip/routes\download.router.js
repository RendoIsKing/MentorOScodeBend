"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const router = express_1.default.Router();
router.get("/download/:userId/:fileName", (req, res) => {
    const { userId, fileName } = req.params;
    const filePath = path_1.default.join(__dirname, `../app/temp/${userId}/${fileName}`);
    //@ts-ignore
    fs_1.default.access(filePath, fs_1.default.constants.F_OK, (err) => {
        if (err) {
            console.error("File not found:", err);
            return res.status(404).json({ error: { message: "File not found" } });
        }
        res.download(filePath, fileName, (err) => {
            if (err) {
                console.error("Error downloading file:", err);
                res.status(500).json({
                    error: { message: "Something went wrong while downloading file" },
                });
            }
            else {
                console.log("File successfully downloaded:", fileName);
            }
        });
    });
});
exports.default = router;
//# sourceMappingURL=download.router.js.map