"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateInterest = void 0;
const class_validator_1 = require("class-validator");
const Interest_1 = require("../../../Models/Interest");
const updateInterestInput_1 = require("../Inputs/updateInterestInput");
const updateInterest = async (req, res) => {
    const { id } = req.params;
    const interest = await Interest_1.Interest.findById(id);
    if (!interest) {
        return res.status(400).json({ error: { message: "No Interest found" } });
    }
    const updateInput = new updateInterestInput_1.UpdateInterestInput();
    updateInput.isAvailable = req.body.isAvailable;
    const validationErrors = await (0, class_validator_1.validate)(updateInput);
    if (validationErrors.length > 0) {
        return res.status(400).json({ errors: validationErrors });
    }
    try {
        interest.isAvailable = req.body.isAvailable;
        await interest.save();
        return res.json({
            data: interest,
            message: "Interest updated successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error in updating interest");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.updateInterest = updateInterest;
//# sourceMappingURL=updateInterestAction.js.map