"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangeLog = exports.Goal = exports.NutritionPlan = exports.TrainingPlan = void 0;
const mongoose_1 = require("mongoose");
const TrainingPlanSchema_1 = require("../../database/schemas/TrainingPlanSchema");
const NutritionPlanSchema_1 = require("../../database/schemas/NutritionPlanSchema");
const GoalSchema_1 = require("../../database/schemas/GoalSchema");
const ChangeLogSchema_1 = require("../../database/schemas/ChangeLogSchema");
const TrainingPlan = (0, mongoose_1.model)('TrainingPlan', TrainingPlanSchema_1.TrainingPlanSchema);
exports.TrainingPlan = TrainingPlan;
const NutritionPlan = (0, mongoose_1.model)('NutritionPlan', NutritionPlanSchema_1.NutritionPlanSchema);
exports.NutritionPlan = NutritionPlan;
const Goal = (0, mongoose_1.model)('Goal', GoalSchema_1.GoalSchema);
exports.Goal = Goal;
const ChangeLog = (0, mongoose_1.model)('ChangeLog', ChangeLogSchema_1.ChangeLogSchema);
exports.ChangeLog = ChangeLog;
//# sourceMappingURL=PlanModels.js.map