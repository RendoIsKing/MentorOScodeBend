"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardDetailsController = void 0;
const getCardDetails_1 = require("./Actions/getCardDetails");
const listCardOfUser_1 = require("./Actions/listCardOfUser");
const setCardtoDefault_1 = require("./Actions/setCardtoDefault");
const deleteCard_1 = require("./Actions/deleteCard");
class CardDetailsController {
}
exports.CardDetailsController = CardDetailsController;
_a = CardDetailsController;
// To add card details into db by extracting from token, token is generated from frontend side.
CardDetailsController.getCardDetails = async (req, res) => {
    return (0, getCardDetails_1.getCardDetails)(req, res);
};
CardDetailsController.listAllCardsOfUser = async (req, res) => {
    return (0, listCardOfUser_1.listAllCardsOfUser)(req, res);
};
CardDetailsController.setDefaultCard = async (req, res) => {
    return (0, setCardtoDefault_1.setDefaultCard)(req, res);
};
CardDetailsController.deleteCard = async (req, res) => {
    return (0, deleteCard_1.deleteCard)(req, res);
};
//# sourceMappingURL=index.js.map