"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterFeatureOnStripe = exports.EntitlementInput = void 0;
const createSlug_1 = __importDefault(require("../../../../utils/regx/createSlug"));
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const Feature_1 = require("../../../Models/Feature");
class EntitlementInput {
    constructor(feature, description) {
        this.feature = feature;
        this.description = description;
    }
}
exports.EntitlementInput = EntitlementInput;
const RegisterFeatureOnStripe = async (entitlements) => {
    try {
        const createFeaturePromises = entitlements.map(async (entitlement) => {
            const featureSlug = (0, createSlug_1.default)(entitlement.feature);
            const existingFeature = await Feature_1.Feature.findOne({
                feature: entitlement.feature,
            });
            if (!existingFeature) {
                throw new Error(`Feature "${entitlement.feature}" doesnt exists.`);
            }
            if (existingFeature.stripeFeatureId) {
                return {
                    existingFeatureId: existingFeature.id,
                    stripeFeatureId: existingFeature.stripeFeatureId,
                };
            }
            const stripeFeature = await stripe_1.default.entitlements.features.create({
                name: entitlement.feature,
                lookup_key: featureSlug,
            });
            existingFeature.stripeFeatureId = stripeFeature.id;
            existingFeature.stripeFeatureObject = stripeFeature;
            await existingFeature.save();
            // return stripeFeature.id;
            return {
                existingFeatureId: existingFeature.id,
                stripeFeatureId: stripeFeature.id,
            };
        });
        const featureIds = await Promise.all(createFeaturePromises);
        return featureIds;
    }
    catch (error) {
        console.log("Error in creating entitlements", error);
        throw error;
    }
};
exports.RegisterFeatureOnStripe = RegisterFeatureOnStripe;
//# sourceMappingURL=registerFeatureOnStripeAction.js.map