"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=CollectionInterface.js.map