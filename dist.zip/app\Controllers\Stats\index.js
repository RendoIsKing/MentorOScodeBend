"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatsController = void 0;
const getFollowersAction_1 = require("./Actions/getFollowersAction");
const getFollowingAction_1 = require("./Actions/getFollowingAction");
const getPostLikesAction_1 = require("./Actions/getPostLikesAction");
const getSubscribersAction_1 = require("./Actions/getSubscribersAction");
const creatorStats_1 = require("./Actions/creatorStats");
const getUserEarningChartAction_1 = require("./Actions/getUserEarningChartAction");
const getUserEarningStats_action_1 = require("./Actions/getUserEarningStats.action");
class StatsController {
}
exports.StatsController = StatsController;
StatsController.getFollowers = (req, res) => {
    (0, getFollowersAction_1.getFollowers)(req, res);
};
StatsController.getFollowing = (req, res) => {
    (0, getFollowingAction_1.getFollowing)(req, res);
};
StatsController.getPostLikes = (req, res) => {
    (0, getPostLikesAction_1.getPostLikes)(req, res);
};
StatsController.getSubscribers = (req, res) => {
    (0, getSubscribersAction_1.getSubscribers)(req, res);
};
StatsController.creatorStats = (req, res) => {
    (0, creatorStats_1.creatorStats)(req, res);
};
StatsController.getEarning = (req, res) => {
    (0, getUserEarningStats_action_1.getUserEarningStats)(req, res);
};
StatsController.getEarningChart = (req, res) => {
    (0, getUserEarningChartAction_1.getUserEarningChart)(req, res);
};
//# sourceMappingURL=index.js.map