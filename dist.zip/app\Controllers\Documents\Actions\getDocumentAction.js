"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDocumentById = void 0;
const Document_1 = require("../../../Models/Document");
const getDocumentById = async (req, res) => {
    const { id } = req.params;
    try {
        const document = await Document_1.Document.findById({ _id: id });
        if (document) {
            return res.json({ data: document });
        }
        return res.status(404).json({ error: { message: "Document not found." } });
    }
    catch (err) {
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.getDocumentById = getDocumentById;
//# sourceMappingURL=getDocumentAction.js.map