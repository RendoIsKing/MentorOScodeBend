"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = OnlyAdmins;
const passport_1 = __importDefault(require("passport"));
function OnlyAdmins(req, res, next) {
    return passport_1.default.authenticate('jwt', { session: false }, (err, payload) => {
        if (err) {
            return res.status(500).json({ error: { message: 'Something went wrong' } });
        }
        if (!payload) {
            return res.status(401).json({ error: { message: 'Invalid Token. Access Denied!' } });
        }
        if (payload.role !== 'admin') {
            return res.status(401).json({ error: { message: 'You dont\'t have access to this resource.!' } });
        }
        req.user = payload;
        return next();
    })(req, res, next);
}
//# sourceMappingURL=onlyAdmins.js.map