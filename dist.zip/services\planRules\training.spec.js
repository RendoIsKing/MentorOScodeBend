"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const training_1 = require("./training");
const plan = [
    { day: 'Mon', focus: 'Full', exercises: [{ name: 'Back Squat', sets: 3, reps: '8-10', rpe: '7-8' }] },
    { day: 'Wed', focus: 'Full', exercises: [{ name: 'Bench Press', sets: 3, reps: '6-8', rpe: '7-8' }] },
    { day: 'Fri', focus: 'Full', exercises: [{ name: 'Lat Pulldown', sets: 3, reps: '10-12', rpe: '7-8' }] },
];
test('swap is deterministic and does not change volume', () => {
    var _a;
    const p = (0, training_1.patchSwapExercise)(plan, 'Mon', 'Back Squat', 'Leg Press');
    expect((_a = p.swaps) === null || _a === void 0 ? void 0 : _a[0]).toEqual({ day: 'Mon', from: 'Back Squat', to: 'Leg Press' });
    expect(p.reason.summary).toMatch(/Byttet/);
});
test('set days/week prunes to N days without duplicating', () => {
    const p = (0, training_1.patchSetDaysPerWeek)(plan, 2);
    expect(p.targetDaysPerWeek).toBe(2);
});
test('progression caps volume increase (~≤20%)', () => {
    var _a;
    const p = (0, training_1.patchProgression)(plan);
    expect((_a = p.volumeTweaks) === null || _a === void 0 ? void 0 : _a.length).toBeGreaterThan(0);
});
test('deload reduces volume and RPE', () => {
    var _a;
    const p = (0, training_1.patchDeload)(plan);
    expect(p.deload).toBe(true);
    expect((_a = p.intensityTweaks) === null || _a === void 0 ? void 0 : _a.length).toBeGreaterThan(0);
});
//# sourceMappingURL=training.spec.js.map