"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startSnapshotReconciler = startSnapshotReconciler;
const node_cron_1 = __importDefault(require("node-cron"));
const StudentState_1 = __importDefault(require("../models/StudentState"));
const rebuildSnapshot_1 = require("../services/snapshot/rebuildSnapshot");
function startSnapshotReconciler() {
    // 02:30 every night
    node_cron_1.default.schedule("30 2 * * *", async () => {
        const since = new Date(Date.now() - 24 * 3600 * 1000);
        const dirty = await StudentState_1.default.find({ lastEventAt: { $gte: since } }, { user: 1 });
        for (const s of dirty) {
            try {
                await (0, rebuildSnapshot_1.rebuildSnapshot)(s.user);
            }
            catch (e) {
                console.error("Reconcile failed", s.user, e);
            }
        }
    });
}
//# sourceMappingURL=snapshot.reconciler.js.map