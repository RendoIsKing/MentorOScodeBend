"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategoryController = void 0;
const class_validator_1 = require("class-validator");
const Category_1 = require("../Models/Category");
const createCategory_input_1 = require("../Inputs/createCategory.input");
const Module_1 = require("../Models/Module");
const CreateSubCategory_input_1 = require("../Inputs/CreateSubCategory.input");
const ObjectId = require('mongoose').Types.ObjectId;
const LIMIT = 10;
class CategoryController {
}
exports.CategoryController = CategoryController;
_a = CategoryController;
CategoryController.create = async (req, res) => {
    const input = req.body;
    const categoryInput = new createCategory_input_1.CreateCategoryInput();
    categoryInput.title = input.title;
    categoryInput.moduleId = input.moduleId;
    const errors = await (0, class_validator_1.validate)(categoryInput);
    if (errors.length) {
        const errorsInfo = errors.map(error => ({
            property: error.property,
            constraints: error.constraints
        }));
        return res.status(400).json({ error: { message: 'VALIDATIONS_ERROR', info: errorsInfo } });
    }
    if (!input.title) {
        return res.status(400).json({ error: { message: 'VALIDATIONS_ERROR', info: "title is required" } });
    }
    try {
        if (!ObjectId.isValid(input.moduleId)) {
            return res.status(400).json({ error: { message: 'Invalid moduleId.' } });
        }
        const module = await Module_1.Module.findById(input.moduleId);
        if (!module) {
            return res.status(400).json({ error: { message: 'Invalid moduleId.' } });
        }
        const dataToSave = {
            title: input.title,
            moduleId: input.moduleId,
            isActive: true
        };
        const category = await Category_1.Category.create(dataToSave);
        return res.json({ data: category, message: "category created sucessfully" });
    }
    catch (err) {
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
CategoryController.index = async (_req, res) => {
    var _b;
    try {
        const perPage = (_req.query && _req.query.perPage > 0 ? parseInt(_req.query.perPage) : LIMIT);
        let skip = (_req.query && _req.query.page > 0 ? parseInt(_req.query.page) - 1 : 0) * perPage;
        let dataToFind = { isActive: true };
        if (_req.query.title) {
            dataToFind.title = _req.query.title;
            dataToFind = { ...dataToFind, title: { $regex: new RegExp(".*" + _req.query.title + ".*", "i") } };
            skip = 0;
        }
        if (_req.query.moduleId) {
            dataToFind.moduleId = _req.query.moduleId;
            dataToFind = { ...dataToFind, moduleId: ObjectId(_req.query.moduleId) };
            skip = 0;
        }
        const [query] = await Category_1.Category.aggregate([{
                $facet: {
                    results: [
                        { $match: dataToFind },
                        // { $lookup: {from: 'Module', localField: 'moduleId', foreignField: 'id', as: 'module'}},
                        { $skip: skip },
                        { $limit: perPage },
                        { $sort: { createdAt: -1 } }
                    ],
                    moduleCount: [
                        { $match: dataToFind },
                        { $count: 'count' }
                    ]
                }
            }]);
        const categoryCount = ((_b = query.moduleCount[0]) === null || _b === void 0 ? void 0 : _b.count) || 0;
        const totalPages = Math.ceil(categoryCount / perPage);
        return res.json({
            data: query.results,
            meta: { "perPage": perPage, "page": _req.query.page || 1, "pages": totalPages, "total": categoryCount, }
        });
    }
    catch (err) {
        console.log(err);
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
CategoryController.show = async (req, res) => {
    const { id } = req.params;
    try {
        const category = await Category_1.Category.findById(id).populate('moduleId');
        if (category) {
            return res.json({ data: { category } });
        }
        return res.status(404).json({ error: { message: 'category not found.' } });
    }
    catch (err) {
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
CategoryController.update = async (req, res) => {
    const { id } = req.params;
    const input = req.body;
    try {
        const dataToSave = { ...input };
        const categoryData = await Category_1.Category.findByIdAndUpdate(id, {
            ...dataToSave
        });
        if (!categoryData) {
            return res.status(400).json({ error: { message: 'category to update does not exists.' } });
        }
        const categoryUpdatedData = await Category_1.Category.findById(id, '-isActive -activatedAt -isDeleted -deletedAt');
        return res.json({ data: { categoryUpdatedData } });
    }
    catch (err) {
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
CategoryController.destroy = async (req, res) => {
    const { id } = req.params;
    try {
        const categoryData = await Category_1.Category.findByIdAndUpdate(id, {
            isDeleted: true,
            deletedAt: new Date()
        });
        if (!categoryData) {
            return res.status(400).json({ error: { message: 'category to delete does not exists.' } });
        }
        return res.json({ data: { message: 'category deleted successfully.' } });
    }
    catch (err) {
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
CategoryController.createSubCategory = async (req, res) => {
    const input = req.body;
    const categoryInput = new CreateSubCategory_input_1.CreateSubCategoryInput();
    categoryInput.title = input.title;
    categoryInput.categoryId = input.categoryId;
    const errors = await (0, class_validator_1.validate)(categoryInput);
    if (errors.length) {
        const errorsInfo = errors.map(error => ({
            property: error.property,
            constraints: error.constraints
        }));
        return res.status(400).json({ error: { message: 'VALIDATIONS_ERROR', info: errorsInfo } });
    }
    try {
        if (!ObjectId.isValid(input.categoryId)) {
            return res.status(400).json({ error: { message: 'Invalid categoryId.' } });
        }
        const category = await Category_1.Category.findById(input.categoryId);
        if (!category) {
            return res.status(400).json({ error: { message: 'Invalid categoryId.' } });
        }
        const subCategory = await Category_1.Category.create({ title: input.title, parentId: input.categoryId, isActive: true });
        const categoryData = await Category_1.Category.findById(subCategory.id, '-isActive -activatedAt -isDeleted -deletedAt').populate('parentId');
        return res.json({ data: categoryData, message: 'sub category created successfully.' });
    }
    catch (err) {
        console.log("ERR", err);
        return res.status(500).json({ error: { message: 'Something went wrong.' } });
    }
};
//# sourceMappingURL=category.controller.js.map