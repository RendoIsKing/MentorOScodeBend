"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InteractionSchema = void 0;
const mongoose_1 = require("mongoose");
const InteractionTypeEnum_1 = require("../../types/enums/InteractionTypeEnum");
const InteractionSchema = new mongoose_1.Schema({
    type: {
        type: String,
        enum: [
            InteractionTypeEnum_1.InteractionType.LIKE_POST,
            InteractionTypeEnum_1.InteractionType.LIKE_STORY,
            InteractionTypeEnum_1.InteractionType.COMMENT,
            InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED,
            InteractionTypeEnum_1.InteractionType.LIKE_COMMENT,
            InteractionTypeEnum_1.InteractionType.IMPRESSION,
            InteractionTypeEnum_1.InteractionType.VIEW,
        ],
    },
    post: {
        type: mongoose_1.Types.ObjectId,
        ref: "Post",
    },
    user: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    replies: [
        {
            type: mongoose_1.Types.ObjectId,
            ref: "Interaction",
            // default: [],
        },
    ],
    likes: [
        {
            type: mongoose_1.Types.ObjectId,
            ref: "Interaction",
            default: [],
        },
    ],
    interactedBy: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    comment: String,
    isDeleted: {
        default: false,
        type: Boolean,
    },
    deletedAt: Date,
}, {
    timestamps: true,
});
exports.InteractionSchema = InteractionSchema;
//# sourceMappingURL=InteractionsSchema.js.map