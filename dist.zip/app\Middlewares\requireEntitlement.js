"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireEntitlement = requireEntitlement;
const User_1 = require("../Models/User");
async function requireEntitlement(req, res, next) {
    try {
        // @ts-ignore
        const user = req.user;
        if (!user)
            return res.status(401).json({ error: { message: 'Unauthorized' } });
        // Simple guard: require status SUBSCRIBED or active subscription in request context
        if ((user === null || user === void 0 ? void 0 : user.status) === 'SUBSCRIBED')
            return next();
        // Re-fetch fresh user from DB to account for status flips during session
        try {
            // @ts-ignore
            const userId = user._id || user.id;
            if (userId) {
                const fresh = await User_1.User.findById(userId).select('status').lean();
                if ((fresh === null || fresh === void 0 ? void 0 : fresh.status) === 'SUBSCRIBED')
                    return next();
            }
        }
        catch { }
        // Optionally check a hydrated flag on req (set upstream) or roles
        return res.status(403).json({ error: { message: 'Subscription required' } });
    }
    catch {
        return res.status(500).json({ error: { message: 'Guard failed' } });
    }
}
//# sourceMappingURL=requireEntitlement.js.map