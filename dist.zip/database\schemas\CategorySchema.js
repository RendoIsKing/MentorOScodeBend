"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategorySchema = void 0;
const mongoose_1 = require("mongoose");
const CategorySchema = new mongoose_1.Schema({
    moduleId: {
        type: mongoose_1.Types.ObjectId,
        default: null,
        ref: "Module",
    },
    parentId: {
        type: mongoose_1.Types.ObjectId,
        default: null,
        ref: "Category",
    },
    title: {
        type: String,
        required: true,
    },
    isActive: {
        type: Boolean,
        default: false
    },
    activatedAt: {
        type: Date,
        default: null
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    deletedAt: {
        type: Date,
        default: null
    },
}, { timestamps: true });
exports.CategorySchema = CategorySchema;
//# sourceMappingURL=CategorySchema.js.map