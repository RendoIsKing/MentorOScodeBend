"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardTypeEnum = void 0;
var CardTypeEnum;
(function (CardTypeEnum) {
    CardTypeEnum["DEBIT"] = "debit";
    CardTypeEnum["CREDIT"] = "credit";
})(CardTypeEnum || (exports.CardTypeEnum = CardTypeEnum = {}));
//# sourceMappingURL=cardTypeEnum.js.map