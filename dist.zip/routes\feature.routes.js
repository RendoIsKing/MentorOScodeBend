"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Features_1 = require("../app/Controllers/Features");
const Middlewares_1 = require("../app/Middlewares");
const requireEntitlement_1 = require("../app/Middlewares/requireEntitlement");
const feature = (0, express_1.Router)();
feature.post("/", Middlewares_1.OnlyAdmins, Features_1.FeatureController.createFeature);
// feature.post("/product-feat/:id", FeatureController.addFeatureToProduct);
// Make feature list public to prevent 403 blocking plan creation UI
feature.get("/", Features_1.FeatureController.getAllFeaturesActions);
// Simple entitlement-protected probe used by FE smoke to confirm gating works
feature.get('/protected-check', Middlewares_1.Auth, requireEntitlement_1.requireEntitlement, (req, res) => {
    return res.json({ ok: true });
});
exports.default = feature;
//# sourceMappingURL=feature.routes.js.map