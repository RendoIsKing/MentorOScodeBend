"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyTrainingPatch = applyTrainingPatch;
exports.applyNutritionPatch = applyNutritionPatch;
const TrainingPlanVersion_1 = __importDefault(require("../../models/TrainingPlanVersion"));
const NutritionPlanVersion_1 = __importDefault(require("../../models/NutritionPlanVersion"));
const StudentState_1 = __importDefault(require("../../models/StudentState"));
const ChangeEvent_1 = __importDefault(require("../../models/ChangeEvent"));
const publish_1 = require("../events/publish");
const nextVersion_1 = require("../versioning/nextVersion");
async function applyTrainingPatch(user, current, patch) {
    var _a, _b, _c, _d;
    let days = [...((current === null || current === void 0 ? void 0 : current.days) || [])];
    (_a = patch.swaps) === null || _a === void 0 ? void 0 : _a.forEach((s) => {
        days = days.map((d) => d.day !== s.day ? d : ({
            ...d, exercises: (d.exercises || []).map((e) => e.name === s.from ? { ...e, name: s.to } : e)
        }));
    });
    (_b = patch.volumeTweaks) === null || _b === void 0 ? void 0 : _b.forEach((t) => {
        days = days.map((d) => d.day !== t.day ? d : ({
            ...d, exercises: (d.exercises || []).map((e) => e.name !== t.name ? e : { ...e, sets: Math.max(1, (e.sets || 3) + (t.deltaSets || 0)) })
        }));
    });
    (_c = patch.intensityTweaks) === null || _c === void 0 ? void 0 : _c.forEach((t) => {
        days = days.map((d) => d.day !== t.day ? d : ({
            ...d, exercises: (d.exercises || []).map((e) => e.name !== t.name ? e : { ...e, rpe: t.newRpe || e.rpe })
        }));
    });
    const version = await (0, nextVersion_1.nextTrainingVersion)(user);
    const reason = patch.reason.summary + (((_d = patch.reason.bullets) === null || _d === void 0 ? void 0 : _d.length) ? " — " + patch.reason.bullets.join("; ") : "");
    const doc = await TrainingPlanVersion_1.default.create({ user, version, source: "action", reason, days });
    await StudentState_1.default.findOneAndUpdate({ user }, { $set: { currentTrainingPlanVersion: doc._id } }, { upsert: true });
    try {
        await ChangeEvent_1.default.create({ user, type: "PLAN_EDIT", summary: reason, refId: doc._id });
    }
    catch { }
    await (0, publish_1.publish)({ type: "PLAN_UPDATED", user });
    return { version, id: doc._id };
}
async function applyNutritionPatch(user, patch) {
    var _a;
    const version = await (0, nextVersion_1.nextNutritionVersion)(user);
    const reason = patch.reason.summary + (((_a = patch.reason.bullets) === null || _a === void 0 ? void 0 : _a.length) ? " — " + patch.reason.bullets.join("; ") : "");
    const doc = await NutritionPlanVersion_1.default.create({
        user, version, source: "action", reason,
        kcal: patch.kcal, proteinGrams: patch.proteinGrams, carbsGrams: patch.carbsGrams, fatGrams: patch.fatGrams
    });
    await StudentState_1.default.findOneAndUpdate({ user }, { $set: { currentNutritionPlanVersion: doc._id } }, { upsert: true });
    try {
        await ChangeEvent_1.default.create({ user, type: "NUTRITION_EDIT", summary: reason, refId: doc._id });
    }
    catch { }
    await (0, publish_1.publish)({ type: "NUTRITION_UPDATED", user });
    return { version, id: doc._id };
}
//# sourceMappingURL=materialize.js.map