"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.onWeightLogged = onWeightLogged;
exports.onPlanUpdated = onPlanUpdated;
exports.onWorkoutLogged = onWorkoutLogged;
exports.onWeightDeleted = onWeightDeleted;
const StudentSnapshot_1 = __importDefault(require("../../models/StudentSnapshot"));
const StudentState_1 = __importDefault(require("../../models/StudentState"));
const TrainingPlanVersion_1 = __importDefault(require("../../models/TrainingPlanVersion"));
const WorkoutLog_1 = __importDefault(require("../../models/WorkoutLog"));
// kept for future KPI delta; not used in tests
// function movingAvg(series: { t: string; v: number }[], window = 7) {
//   if (!series.length) return { latestAvg: null as number|null, prevAvg: null as number|null, delta: null as number|null };
//   const parse = (d: string) => new Date(d + "T00:00:00Z").getTime();
//   const sorted = [...series].sort((a, b) => parse(a.t) - parse(b.t));
//   const recent = sorted.slice(-window);
//   const prev = sorted.slice(-window*2, -window);
//   const sum = (arr: any[]) => arr.reduce((s, x) => s + x.v, 0);
//   const latestAvg = recent.length ? sum(recent) / recent.length : null;
//   const prevAvg = prev.length ? sum(prev) / prev.length : null;
//   const delta = latestAvg != null && prevAvg != null ? latestAvg - prevAvg : null;
//   return { latestAvg, prevAvg, delta };
// }
async function onWeightLogged(user, date, kg) {
    var _a, _b;
    const snap = (await StudentSnapshot_1.default.findOne({ user })) || new StudentSnapshot_1.default({ user, weightSeries: [] });
    const map = new Map((snap.weightSeries || []).map((p) => [p.t, p.v]));
    map.set(date, kg);
    snap.weightSeries = Array.from(map.entries()).sort((ea, eb) => String(ea[0]).localeCompare(String(eb[0]))).map(([t, v]) => ({ t, v }));
    snap.kpis = { ...(snap.kpis || {}), lastCheckIn: date, adherence7d: (_a = snap.kpis) === null || _a === void 0 ? void 0 : _a.adherence7d, nextWorkout: (_b = snap.kpis) === null || _b === void 0 ? void 0 : _b.nextWorkout };
    await snap.save();
}
async function onPlanUpdated(user) {
    const snap = (await StudentSnapshot_1.default.findOne({ user })) || new StudentSnapshot_1.default({ user, weightSeries: [] });
    const state = await StudentState_1.default.findOne({ user });
    const tp = (state === null || state === void 0 ? void 0 : state.currentTrainingPlanVersion) ? await TrainingPlanVersion_1.default.findById(state.currentTrainingPlanVersion) : null;
    const daysPerWeek = tp ? (tp.days || []).filter((d) => { var _a, _b; return ((_b = (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) > 0; }).length : 0;
    const todayIdx = new Date().getUTCDay();
    const order = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const hasWork = (d) => { var _a, _b; return ((_b = (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) > 0; };
    let nextWorkout;
    if (tp) {
        for (let i = 0; i < 7; i++) {
            const idx = (todayIdx + i) % 7;
            const dayName = order[idx];
            const day = (tp.days || []).find((d) => d.day === dayName);
            if (day && hasWork(day)) {
                nextWorkout = dayName;
                break;
            }
        }
    }
    snap.trainingPlanSummary = { daysPerWeek };
    snap.kpis = { ...(snap.kpis || {}), nextWorkout };
    await snap.save();
}
async function onWorkoutLogged(user, date) {
    var _a;
    const snap = (await StudentSnapshot_1.default.findOne({ user })) || new StudentSnapshot_1.default({ user, weightSeries: [] });
    const since = new Date(Date.now() - 7 * 24 * 3600 * 1000);
    const seven = await WorkoutLog_1.default.find({ user, date: { $gte: since.toISOString().slice(0, 10) } });
    const unique = new Set(seven.map((w) => w.date)).size;
    const state = await StudentState_1.default.findOne({ user });
    const tp = (state === null || state === void 0 ? void 0 : state.currentTrainingPlanVersion) ? await TrainingPlanVersion_1.default.findById(state.currentTrainingPlanVersion) : null;
    const daysPerWeek = tp ? (tp.days || []).filter((d) => { var _a, _b; return ((_b = (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) > 0; }).length : 0;
    const adherence7d = daysPerWeek ? Math.min(1, unique / daysPerWeek) : 0;
    snap.kpis = { ...(snap.kpis || {}), adherence7d, lastCheckIn: date, nextWorkout: (_a = snap.kpis) === null || _a === void 0 ? void 0 : _a.nextWorkout };
    await snap.save();
}
async function onWeightDeleted(user, date) {
    const snap = (await StudentSnapshot_1.default.findOne({ user })) || new StudentSnapshot_1.default({ user, weightSeries: [] });
    snap.weightSeries = (snap.weightSeries || []).filter((p) => p.t !== date);
    await snap.save();
}
//# sourceMappingURL=incremental.js.map