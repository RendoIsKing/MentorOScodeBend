"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const User_1 = require("../app/Models/User");
const TrainingPlanVersion_1 = __importDefault(require("../models/TrainingPlanVersion"));
const NutritionPlanVersion_1 = __importDefault(require("../models/NutritionPlanVersion"));
const StudentState_1 = __importDefault(require("../models/StudentState"));
const StudentSnapshot_1 = __importDefault(require("../models/StudentSnapshot"));
const r = (0, express_1.Router)();
r.post("/dev/bootstrap", async (req, res) => {
    var _a;
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
        if (!devOn)
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const email = String((((_a = req.body) === null || _a === void 0 ? void 0 : _a.email) || "demo@mentoros.app").toLowerCase());
        let user = await User_1.User.findOne({ email });
        if (!user)
            user = await User_1.User.create({ email, fullName: "Demo User" });
        // Ensure initial plan versions and state
        let state = await StudentState_1.default.findOne({ user: user._id });
        if (!state) {
            const tp = await TrainingPlanVersion_1.default.create({
                user: user._id,
                version: 1,
                source: "manual",
                reason: "Bootstrap",
                days: [
                    { day: 'Mon', focus: 'Full body', exercises: [{ name: 'Squat', sets: 3, reps: '8' }] },
                    { day: 'Wed', focus: 'Pull', exercises: [{ name: 'Row', sets: 3, reps: '10' }] },
                    { day: 'Fri', focus: 'Push', exercises: [{ name: 'Bench', sets: 3, reps: '8' }] },
                ],
            });
            const np = await NutritionPlanVersion_1.default.create({
                user: user._id,
                version: 1,
                source: "manual",
                reason: "Bootstrap",
                kcal: 2400,
                proteinGrams: 140,
                carbsGrams: 300,
                fatGrams: 70,
            });
            state = await StudentState_1.default.create({ user: user._id, currentTrainingPlanVersion: tp._id, currentNutritionPlanVersion: np._id });
            await StudentSnapshot_1.default.findOneAndUpdate({ user: user._id }, { $setOnInsert: { weightSeries: [], trainingPlanSummary: { daysPerWeek: 3 }, nutritionSummary: { kcal: 2400, protein: 140, carbs: 300, fat: 70 }, kpis: { adherence7d: 0 } } }, { upsert: true });
        }
        return res.json({ ok: true, userId: user._id.toString() });
    }
    catch (e) {
        return res.status(500).json({ error: "bootstrap failed" });
    }
});
exports.default = r;
//# sourceMappingURL=dev.bootstrap.js.map