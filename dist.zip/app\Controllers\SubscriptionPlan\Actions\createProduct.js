"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createProduct = void 0;
const stripeCurrency_1 = require("../../../../utils/consts/stripeCurrency");
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const subscriptionPlanInput_1 = require("../Inputs/subscriptionPlanInput");
const registerFeatureOnStripeAction_1 = require("../../Features/Actions/registerFeatureOnStripeAction");
const associateFeatureToProduct_1 = require("../../Features/Actions/associateFeatureToProduct");
const subscriptionPlanEnum_1 = require("../../../../types/enums/subscriptionPlanEnum");
const mongoose_1 = require("mongoose");
const createProduct = async (req, res) => {
    try {
        const body = req.body;
        const user = req.user;
        const subscriptionPlanInput = (0, class_transformer_1.plainToClass)(subscriptionPlanInput_1.SubscriptionPlanInput, req.body);
        const validationErrors = await (0, class_validator_1.validate)(subscriptionPlanInput);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        if (subscriptionPlanInput.planType === subscriptionPlanEnum_1.SubscriptionPlanType.FIXED) {
            const plan = await SubscriptionPlan_1.SubscriptionPlan.findOne({
                userId: new mongoose_1.Types.ObjectId(user.id),
                planType: subscriptionPlanEnum_1.SubscriptionPlanType.FIXED,
                isDeleted: false,
            });
            if (plan) {
                return res.status(422).json({
                    error: {
                        message: "You already have a fixed plan, pls delete it and then create a new one...... ",
                    },
                });
            }
        }
        const stripeProduct = await stripe_1.default.products.create({
            name: body.title,
            description: body.description,
            metadata: {},
            default_price_data: {
                currency: stripeCurrency_1.stripe_currency,
                recurring: {
                    interval: "month", // @future should be dynamic from api, @todo if not dynamic move to constants
                },
                unit_amount: body.price,
                // name: body.name,
            },
        });
        let productFeatures = [];
        let updatedProduct;
        const product = await SubscriptionPlan_1.SubscriptionPlan.create({
            ...subscriptionPlanInput,
            userId: user.id,
            stripeProductId: stripeProduct.id,
            stripeProductObject: stripeProduct,
        });
        if (subscriptionPlanInput.entitlements) {
            const featureIds = await (0, registerFeatureOnStripeAction_1.RegisterFeatureOnStripe)(subscriptionPlanInput.entitlements);
            const existingFeatureIds = featureIds.map((fi) => fi.existingFeatureId);
            const stripeFeatureIds = featureIds.map((fi) => fi.stripeFeatureId);
            const featureAssociationParams = {
                productId: stripeProduct.id,
                featureIds: subscriptionPlanInput.entitlements.map((entitlement) => entitlement.feature),
            };
            productFeatures = await (0, associateFeatureToProduct_1.associateFeatureToProduct)(featureAssociationParams);
            updatedProduct = await SubscriptionPlan_1.SubscriptionPlan.findByIdAndUpdate(product.id, {
                $addToSet: {
                    featureIds: { $each: existingFeatureIds },
                    stripeProductFeatureIds: { $each: stripeFeatureIds },
                    stripeProductFeatureId: {
                        $each: productFeatures.map((pf) => pf.stripeProductFeatureId),
                    },
                },
            }, { new: true });
        }
        return res.json({ data: updatedProduct });
    }
    catch (error) {
        console.log(error, "error creating product");
        return res.status(500).json({
            messsage: "Something went wrong",
            error: error,
        });
    }
};
exports.createProduct = createProduct;
exports.default = exports.createProduct;
//# sourceMappingURL=createProduct.js.map