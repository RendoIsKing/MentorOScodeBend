"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.jwt = exports.local = void 0;
const local_1 = __importDefault(require("./local"));
exports.local = local_1.default;
const jwt_1 = __importDefault(require("./jwt"));
exports.jwt = jwt_1.default;
//# sourceMappingURL=index.js.map