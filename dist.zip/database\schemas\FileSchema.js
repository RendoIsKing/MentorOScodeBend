"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileSchema = void 0;
const mongoose_1 = require("mongoose");
const FileSchema = new mongoose_1.Schema({
    path: {
        type: String,
        required: true,
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    deletedAt: {
        type: Date,
        default: null
    },
}, { timestamps: true });
exports.FileSchema = FileSchema;
//# sourceMappingURL=FileSchema.js.map