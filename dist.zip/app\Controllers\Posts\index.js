"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostsController = void 0;
const createPost_action_1 = require("./Actions/createPost.action");
const updatePost_action_1 = require("./Actions/updatePost.action");
const deletePost_action_1 = require("./Actions/deletePost.action");
const getAllPosts_action_1 = require("./Actions/getAllPosts.action");
const getPostByIdAction_1 = require("./Actions/getPostByIdAction");
const getPostsOfUserAction_1 = require("./Actions/getPostsOfUserAction");
const getAllStoriesAction_1 = require("./Actions/getAllStoriesAction");
const getStoriesOfUser_1 = require("./Actions/getStoriesOfUser");
const getTaggedUserOfPost_action_1 = require("./Actions/getTaggedUserOfPost.action");
const testPostAction_1 = require("./Actions/testPostAction");
class PostsController {
}
exports.PostsController = PostsController;
PostsController.createPost = (req, res) => {
    (0, createPost_action_1.createPostAction)(req, res);
};
PostsController.updatePost = (req, res) => {
    (0, updatePost_action_1.updatePostAction)(req, res);
};
PostsController.deletePost = (req, res) => {
    (0, deletePost_action_1.deletePostsAction)(req, res);
};
PostsController.getAllPosts = (req, res) => {
    (0, getAllPosts_action_1.getAllPostsActions)(req, res);
};
PostsController.getPostById = (req, res) => {
    (0, getPostByIdAction_1.getPostById)(req, res);
};
PostsController.getPostsOfUserByUserName = (req, res) => {
    (0, getPostsOfUserAction_1.getPostsOfUserByUserName)(req, res);
};
PostsController.getAllStoriesActions = (req, res) => {
    (0, getAllStoriesAction_1.getAllStoriesActions)(req, res);
};
PostsController.getStoriesOfUserByUserName = (req, res) => {
    (0, getStoriesOfUser_1.getStoriesOfUserByUserName)(req, res);
};
PostsController.getTaggedUsers = (req, res) => {
    (0, getTaggedUserOfPost_action_1.getTaggedUsers)(req, res);
};
PostsController.getFirstPost = (req, res) => {
    (0, testPostAction_1.getFirstPost)(req, res);
};
//# sourceMappingURL=index.js.map