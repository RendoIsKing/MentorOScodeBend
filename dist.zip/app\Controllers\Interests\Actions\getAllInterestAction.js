"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllInterest = void 0;
const Interest_1 = require("../../../Models/Interest");
const getAllInterest = async (_req, res) => {
    var _a;
    try {
        const LIMIT = 10;
        const perPage = _req.query &&
            _req.query.perPage &&
            parseInt(_req.query.perPage) > 0
            ? parseInt(_req.query.perPage)
            : LIMIT;
        const page = _req.query && _req.query.page && parseInt(_req.query.page) > 0
            ? parseInt(_req.query.page)
            : 1;
        let skip = (page - 1) * perPage;
        const [query] = await Interest_1.Interest.aggregate([
            {
                $match: {
                    $or: [{ isDeleted: { $ne: true } }, { deletedAt: null }],
                },
            },
            {
                $facet: {
                    results: [
                        { $skip: skip },
                        { $limit: perPage },
                        { $sort: { createdAt: -1 } },
                    ],
                    interestCount: [{ $count: "count" }],
                },
            },
        ]);
        const interestCount = ((_a = query.interestCount[0]) === null || _a === void 0 ? void 0 : _a.count) || 0;
        const totalPages = Math.ceil(interestCount / perPage);
        return res.json({
            data: query.results,
            meta: {
                perPage: perPage,
                page: _req.query.page || 1,
                pages: totalPages,
                total: interestCount,
            },
        });
    }
    catch (err) {
        console.log(err, "Error in getting all interest");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.getAllInterest = getAllInterest;
//# sourceMappingURL=getAllInterestAction.js.map