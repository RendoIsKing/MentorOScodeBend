"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoachKnowledge = void 0;
const mongoose_1 = require("mongoose");
const CoachKnowledgeSchema_1 = require("../../database/schemas/CoachKnowledgeSchema");
const CoachKnowledge = (0, mongoose_1.model)('CoachKnowledge', CoachKnowledgeSchema_1.CoachKnowledgeSchema);
exports.CoachKnowledge = CoachKnowledge;
//# sourceMappingURL=CoachKnowledge.js.map