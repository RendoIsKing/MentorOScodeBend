"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.publish = publish;
const incremental_1 = require("../snapshot/incremental");
const StudentState_1 = __importDefault(require("../../models/StudentState"));
async function publish(event) {
    try {
        await StudentState_1.default.updateOne({ user: event.user }, { $set: { lastEventAt: new Date() } }, { upsert: true });
    }
    catch { }
    switch (event.type) {
        case "PLAN_UPDATED":
            await (0, incremental_1.onPlanUpdated)(event.user);
            break;
        case "NUTRITION_UPDATED":
            await (0, incremental_1.onPlanUpdated)(event.user);
            break;
        case "WEIGHT_LOGGED":
            if (event.date && event.kg != null)
                await (0, incremental_1.onWeightLogged)(event.user, event.date, event.kg);
            break;
        case "WEIGHT_DELETED":
            if (event.date)
                await (0, incremental_1.onWeightDeleted)(event.user, event.date);
            break;
        case "WORKOUT_LOGGED":
            if (event.date)
                await (0, incremental_1.onWorkoutLogged)(event.user, event.date);
            break;
        case "GOAL_UPDATED":
            // For now, reuse onPlanUpdated to refresh snapshot
            await (0, incremental_1.onPlanUpdated)(event.user);
            break;
    }
    // Optionally also do full rebuild for robustness in dev
    // await rebuildSnapshot(event.user);
}
//# sourceMappingURL=publish.js.map