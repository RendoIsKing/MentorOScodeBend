"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentController = void 0;
const verifyDocumentAction_1 = require("./Actions/verifyDocumentAction");
const postDocumentAction_1 = require("./Actions/postDocumentAction");
const getDocumentAction_1 = require("./Actions/getDocumentAction");
const getAllDocumentAction_1 = require("./Actions/getAllDocumentAction");
class DocumentController {
}
exports.DocumentController = DocumentController;
_a = DocumentController;
DocumentController.verifyDocument = async (req, res) => {
    return (0, verifyDocumentAction_1.verifyDocument)(req, res);
};
DocumentController.postDocument = (req, res) => {
    return (0, postDocumentAction_1.postDocument)(req, res);
};
DocumentController.getDocumentById = (req, res) => {
    return (0, getDocumentAction_1.getDocumentById)(req, res);
};
DocumentController.getAllDocuments = (req, res) => {
    return (0, getAllDocumentAction_1.getAllDocuments)(req, res);
};
//# sourceMappingURL=index.js.map