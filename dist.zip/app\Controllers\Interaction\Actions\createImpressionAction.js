"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createImpression = void 0;
const Interaction_1 = require("../../../Models/Interaction"); // Update the import path as necessary
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const Post_1 = require("../../../Models/Post");
const createImpression = async (req, res) => {
    try {
        const { postId } = req.body;
        const user = req.user;
        if (!postId) {
            return res
                .status(404)
                .json({ error: { message: "Post Id is required" } });
        }
        const post = await Post_1.Post.findById(postId);
        if (!post) {
            return res.status(404).json({ error: { message: "Post not found" } });
        }
        const interactionExists = await Interaction_1.Interaction.findOne({
            type: InteractionTypeEnum_1.InteractionType.IMPRESSION,
            post: postId,
            user: post.user,
            interactedBy: user._id,
        });
        if (interactionExists) {
            return res.json({
                data: {
                    message: "Interaction exists",
                },
            });
        }
        const impression = new Interaction_1.Interaction({
            type: InteractionTypeEnum_1.InteractionType.IMPRESSION,
            post: postId,
            user: post.user,
            interactedBy: user._id,
            isDeleted: false,
        });
        await impression.save();
        return res.json({
            data: impression,
            message: "impression created successfully",
        });
    }
    catch (error) {
        console.error("Error liking comment:", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.createImpression = createImpression;
//# sourceMappingURL=createImpressionAction.js.map