"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.softDeleteSubscriptionPlan = void 0;
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const mongoose_1 = __importDefault(require("mongoose"));
const SubscriptionStatusEnum_1 = require("../../../../types/enums/SubscriptionStatusEnum");
const Subscription_1 = require("../../../Models/Subscription");
const softDeleteSubscriptionPlan = async (req, res) => {
    try {
        const user = req.user;
        const planId = req.params.id;
        const subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.findById(planId);
        if (!subscriptionPlan) {
            return res
                .status(404)
                .json({ error: { message: "Subscription plan not found." } });
        }
        if (subscriptionPlan.userId.toString() !== user.id) {
            return res.status(403).json({
                error: {
                    message: "You do not have permission to delete this subscription plan.",
                },
            });
        }
        const activeSubscriptions = await Subscription_1.Subscription.aggregate([
            {
                $match: {
                    planId: new mongoose_1.default.Types.ObjectId(planId),
                    status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
                    endDate: { $gt: new Date() },
                },
            },
            {
                $count: "activeSubscriptionsCount",
            },
        ]);
        if (activeSubscriptions.length > 0 &&
            activeSubscriptions[0].activeSubscriptionsCount > 0) {
            return res.status(400).json({
                error: { message: "Cannot delete plan with active subscribers." },
            });
        }
        subscriptionPlan.isDeleted = true;
        subscriptionPlan.deletedAt = new Date();
        await subscriptionPlan.save();
        return res.json({
            data: subscriptionPlan,
            message: "Plan deleted successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while deleting plan");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.softDeleteSubscriptionPlan = softDeleteSubscriptionPlan;
//# sourceMappingURL=deleteSubscriptionPlanAction.js.map