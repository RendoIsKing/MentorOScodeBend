"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toggleLikeStoryAction = void 0;
const Post_1 = require("../../../Models/Post");
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const postTypeEnum_1 = require("../../../../types/enums/postTypeEnum");
const getAllStoriesAction_1 = require("../../Posts/Actions/getAllStoriesAction");
const User_1 = require("../../../Models/User");
const notificationService_1 = require("../../../../utils/Notifications/notificationService");
const FirebaseNotificationEnum_1 = require("../../../../types/enums/FirebaseNotificationEnum");
const saveNotification_1 = require("../../Notifications/Actions/saveNotification");
const toggleLikeStoryAction = async (req, res) => {
    try {
        const user = req.user;
        const storyId = req.params.id;
        const storyExists = (await Post_1.Post.findOne({
            _id: storyId,
            type: postTypeEnum_1.PostType.STORY,
            isDeleted: false,
            createdAt: { $gte: getAllStoriesAction_1.twentyFourHoursAgo },
        }));
        if (!storyExists || (storyExists === null || storyExists === void 0 ? void 0 : storyExists.isDeleted)) {
            return res.status(400).json({ error: { message: "Story not exist" } });
        }
        const intreactionExist = (await Interaction_1.Interaction.findOne({
            user: storyExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.LIKE_STORY,
            post: storyExists,
        }));
        if (intreactionExist) {
            await Interaction_1.Interaction.deleteOne({ _id: intreactionExist.id });
            return res.json({
                data: {
                    message: "Story disliked",
                },
            });
        }
        const like = await Interaction_1.Interaction.create({
            user: storyExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.LIKE_STORY,
            post: storyId,
        });
        try {
            const userStory = await User_1.User.findById(storyExists.user);
            const interactedByUser = await User_1.User.findById(user.id);
            if (!interactedByUser) {
                return res
                    .status(404)
                    .json({ error: { message: "Username not found" } });
            }
            if (userStory && userStory.fcm_token) {
                const notificationToken = userStory.fcm_token;
                if (notificationToken) {
                    const notificationTitle = "New Like on your story";
                    const notificationDescription = `${interactedByUser.userName} liked your story`;
                    await (0, notificationService_1.sendNotification)(notificationToken, notificationTitle, notificationDescription, FirebaseNotificationEnum_1.FirebaseNotificationEnum.LIKE_STORY, userStory.userName);
                    await (0, saveNotification_1.saveNotification)({
                        title: notificationTitle,
                        description: notificationDescription,
                        sentTo: [userStory._id],
                        type: FirebaseNotificationEnum_1.FirebaseNotificationEnum.LIKE_STORY,
                        notificationOnPost: null,
                        notificationFromUser: null
                    });
                }
                else {
                    console.error("FCM token for the user not found");
                }
            }
        }
        catch (error) {
            console.log("Error sending like notification", error);
        }
        return res.json({
            data: like,
            message: "Story liked",
        });
    }
    catch (error) {
        console.log(error, "error in liking story");
        if (error.code === 11000) {
            return res
                .status(500)
                .json({ error: { message: "User already liked the story", error } });
        }
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.toggleLikeStoryAction = toggleLikeStoryAction;
//# sourceMappingURL=likeStoryAction.js.map