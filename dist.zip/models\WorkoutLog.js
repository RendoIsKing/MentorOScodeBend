"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const WorkoutLogSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    date: { type: String, index: true, required: true },
    entries: [{ name: String, sets: Number, reps: Number, loadKg: Number }]
}, { timestamps: true });
WorkoutLogSchema.index({ user: 1, date: 1 }, { unique: true });
exports.default = (0, mongoose_1.model)("WorkoutLog", WorkoutLogSchema);
//# sourceMappingURL=WorkoutLog.js.map