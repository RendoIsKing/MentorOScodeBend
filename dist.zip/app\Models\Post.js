"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Post = void 0;
const mongoose_1 = require("mongoose");
const postSchema_1 = require("../../database/schemas/postSchema");
const Post = (0, mongoose_1.model)("Post", postSchema_1.PostSchema);
exports.Post = Post;
//# sourceMappingURL=Post.js.map