"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const createSlug = (text) => {
    return text === null || text === void 0 ? void 0 : text.trim().toLowerCase().replace(/\s+/g, "-");
};
exports.default = createSlug;
//# sourceMappingURL=createSlug.js.map