"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commentAction = void 0;
const Post_1 = require("../../../Models/Post");
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const class_validator_1 = require("class-validator");
const postCommentInput_1 = require("../Inputs/postCommentInput");
const class_transformer_1 = require("class-transformer");
const User_1 = require("../../../Models/User");
const notificationService_1 = require("../../../../utils/Notifications/notificationService");
const FirebaseNotificationEnum_1 = require("../../../../types/enums/FirebaseNotificationEnum");
const saveNotification_1 = require("../../Notifications/Actions/saveNotification");
const commentAction = async (req, res) => {
    try {
        const user = req.user;
        const postId = req.params.id;
        const postInput = (0, class_transformer_1.plainToClass)(postCommentInput_1.CommentInput, req.body);
        const postExists = (await Post_1.Post.findById(postId));
        if (!postExists || (postExists === null || postExists === void 0 ? void 0 : postExists.isDeleted)) {
            return res.status(400).json({ error: { message: "Post not exist" } });
        }
        const validationErrors = await (0, class_validator_1.validate)(postInput);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        const commentInteraction = await Interaction_1.Interaction.create({
            comment: req.body.comment,
            user: postExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.COMMENT,
            post: postId,
        });
        try {
            const userComment = await User_1.User.findById(postExists.user);
            const interactedByUser = await User_1.User.findById(user.id);
            if (!interactedByUser) {
                return res
                    .status(404)
                    .json({ error: { message: "Username not found" } });
            }
            if (userComment && userComment.fcm_token) {
                const notificationToken = userComment.fcm_token;
                if (notificationToken) {
                    const notificationTitle = "New Comment on your post";
                    const notificationDescription = `${interactedByUser.userName} commented on your post`;
                    await (0, notificationService_1.sendNotification)(notificationToken, notificationTitle, notificationDescription, FirebaseNotificationEnum_1.FirebaseNotificationEnum.COMMENT, postExists.id);
                    await (0, saveNotification_1.saveNotification)({
                        title: notificationTitle,
                        description: notificationDescription,
                        sentTo: [userComment._id],
                        type: FirebaseNotificationEnum_1.FirebaseNotificationEnum.COMMENT,
                        notificationOnPost: postExists.id,
                        notificationFromUser: null,
                    });
                }
                else {
                    console.error("FCM token for the user not found");
                }
            }
        }
        catch (error) {
            console.log("Error sending like notification", error);
        }
        return res.json({
            data: commentInteraction,
            message: "Comment posted successfully.",
        });
    }
    catch (error) {
        console.log("error in posting comment", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.commentAction = commentAction;
//# sourceMappingURL=commentPost.action.js.map