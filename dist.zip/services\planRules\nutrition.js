"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nutritionFromProfile = nutritionFromProfile;
const safety_1 = require("./safety");
function nutritionFromProfile(profile) {
    var _a, _b;
    const goal = (_a = profile === null || profile === void 0 ? void 0 : profile.goals) !== null && _a !== void 0 ? _a : "maintain";
    const bw = (_b = profile === null || profile === void 0 ? void 0 : profile.bodyWeightKg) !== null && _b !== void 0 ? _b : 70;
    const vegan = (profile === null || profile === void 0 ? void 0 : profile.diet) === "vegan";
    const kcalMult = goal === "cut" ? 28 : goal === "gain" ? 33 : 30;
    const kcal = (0, safety_1.clampKcal)(bw * kcalMult);
    const proteinPerKg = vegan ? 2.2 : 2.0;
    const proteinGrams = Math.round(bw * proteinPerKg);
    const carbsGrams = Math.round(((kcal - proteinGrams * 4) * 0.55) / 4);
    const fatGrams = Math.round(((kcal - proteinGrams * 4) * 0.45) / 9);
    return {
        kcal, proteinGrams, carbsGrams, fatGrams,
        reason: {
            summary: "Makroer fra profil",
            bullets: [
                `${goal} mål → ${kcalMult} kcal/kg`,
                vegan ? "Protein ~2.2 g/kg (plantekilder)" : "Protein ~2.0 g/kg",
                "55/45 fordeling karb/fett for etterlevelse",
            ]
        }
    };
}
//# sourceMappingURL=nutrition.js.map