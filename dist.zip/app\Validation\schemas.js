"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionSchema = exports.SwapExerciseSchema = exports.DaysPerWeekSchema = exports.NutritionCaloriesSchema = exports.WeightDeleteSchema = exports.WeightLogSchema = exports.chatMessageSchema = void 0;
const zod_1 = require("zod");
exports.chatMessageSchema = zod_1.z.object({
    text: zod_1.z.string().trim().min(1, 'message required').max(1000, 'message too long'),
});
exports.WeightLogSchema = zod_1.z.object({
    date: zod_1.z.string().min(6),
    kg: zod_1.z.number().positive().max(400),
});
exports.WeightDeleteSchema = zod_1.z.object({
    date: zod_1.z.string().min(6),
});
exports.NutritionCaloriesSchema = zod_1.z.object({
    kcal: zod_1.z.number().int(),
});
exports.DaysPerWeekSchema = zod_1.z.object({
    daysPerWeek: zod_1.z.number().int().min(1).max(7),
});
exports.SwapExerciseSchema = zod_1.z.object({
    day: zod_1.z.enum(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']).optional(),
    from: zod_1.z.string().trim().min(1),
    to: zod_1.z.string().trim().min(1),
});
exports.ActionSchema = zod_1.z.object({
    type: zod_1.z.enum(['PLAN_SWAP_EXERCISE', 'PLAN_SET_DAYS_PER_WEEK', 'NUTRITION_SET_CALORIES', 'WEIGHT_LOG', 'WEIGHT_DELETE']),
    payload: zod_1.z.union([
        exports.SwapExerciseSchema,
        exports.DaysPerWeekSchema,
        exports.NutritionCaloriesSchema,
        exports.WeightLogSchema,
        exports.WeightDeleteSchema,
        zod_1.z.record(zod_1.z.any()).optional(),
    ]).optional(),
});
//# sourceMappingURL=schemas.js.map