"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipsSchema = void 0;
const mongoose_1 = require("mongoose");
const TipsSchema = new mongoose_1.Schema({
    message: {
        type: String,
        required: false,
    },
    tipTo: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    tipBy: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    tipOn: {
        type: mongoose_1.Types.ObjectId,
        ref: "Post",
    },
}, { timestamps: true });
exports.TipsSchema = TipsSchema;
//# sourceMappingURL=TipSchema.js.map