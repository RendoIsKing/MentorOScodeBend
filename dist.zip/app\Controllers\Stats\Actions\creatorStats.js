"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creatorStats = void 0;
const mongoose_1 = require("mongoose");
const Connection_1 = require("../../../Models/Connection");
const isValidDate_1 = require("../../../../utils/regx/isValidDate");
const Subscription_1 = require("../../../Models/Subscription");
const SubscriptionStatusEnum_1 = require("../../../../types/enums/SubscriptionStatusEnum");
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const Post_1 = require("../../../Models/Post");
const Transaction_1 = require("../../../Models/Transaction");
const transactionTypeEnum_1 = require("../../../../types/enums/transactionTypeEnum");
const transactionStatusEnum_1 = require("../../../../types/enums/transactionStatusEnum");
const datesFromRange = (range) => {
    switch (range.toLowerCase()) {
        case "yesterday": {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            return {
                startDate: yesterday.toISOString().split("T")[0],
                endDate: yesterday.toISOString().split("T")[0],
            };
        }
        case "tomorrow": {
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            return {
                startDate: tomorrow.toISOString().split("T")[0],
                endDate: tomorrow.toISOString().split("T")[0],
            };
        }
        case "today": {
            const today = new Date();
            return {
                startDate: today.toISOString().split("T")[0],
                endDate: today.toISOString().split("T")[0],
            };
        }
        case "this_week": {
            const today = new Date();
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay());
            const endOfWeek = new Date(today);
            endOfWeek.setDate(today.getDate() - today.getDay() + 6);
            return {
                startDate: startOfWeek.toISOString().split("T")[0],
                endDate: endOfWeek.toISOString().split("T")[0],
            };
        }
        case "14_days": {
            const endDate = new Date();
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - 13);
            return {
                startDate: startDate.toISOString().split("T")[0],
                endDate: endDate.toISOString().split("T")[0],
            };
        }
        case "30_days": {
            const endDate = new Date();
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - 29);
            return {
                startDate: startDate.toISOString().split("T")[0],
                endDate: endDate.toISOString().split("T")[0],
            };
        }
        case "90_days": {
            const endDate = new Date();
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - 89);
            return {
                startDate: startDate.toISOString().split("T")[0],
                endDate: endDate.toISOString().split("T")[0],
            };
        }
        default:
            return {};
    }
};
const computeDateRange = (body) => {
    let { startDate, endDate, range } = body;
    if (!(startDate || !endDate) && range) {
        const { startDate: computedStart, endDate: computedEnd } = datesFromRange(range);
        startDate = computedStart;
        endDate = computedEnd;
    }
    return {
        startDate: startDate,
        endDate: endDate,
    };
};
const creatorStats = async (req, res) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
    try {
        const { startDate, endDate } = computeDateRange(req.body);
        const user = req.user;
        if (!startDate || !endDate) {
            return res
                .status(400)
                .json({ error: "startDate and endDate are required." });
        }
        if (!(0, isValidDate_1.isValidDateFormat)(startDate) || !(0, isValidDate_1.isValidDateFormat)(endDate)) {
            return res
                .status(400)
                .json({ error: "Invalid date format. Use YYYY-MM-DD." });
        }
        const start = new Date(startDate);
        const end = new Date(endDate);
        const followersCountAggregation = await Connection_1.userConnection.aggregate([
            {
                $match: {
                    followingTo: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $gte: start, $lte: end },
                },
            },
            {
                $group: {
                    _id: "$followingTo",
                    followersCount: { $sum: 1 },
                },
            },
        ]);
        const initialFollowersCountAggregation = await Connection_1.userConnection.aggregate([
            {
                $match: {
                    followingTo: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $lt: start },
                },
            },
            {
                $group: {
                    _id: "$followingTo",
                    initialFollowersCount: { $sum: 1 },
                },
            },
        ]);
        const finalFollowersCountAggregation = await Connection_1.userConnection.aggregate([
            {
                $match: {
                    followingTo: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $lte: end },
                },
            },
            {
                $group: {
                    _id: "$followingTo",
                    finalFollowersCount: { $sum: 1 },
                },
            },
        ]);
        const followersCount = ((_a = followersCountAggregation[0]) === null || _a === void 0 ? void 0 : _a.followersCount) || 0;
        const initialFollowersCount = ((_b = initialFollowersCountAggregation[0]) === null || _b === void 0 ? void 0 : _b.initialFollowersCount) || 0;
        const finalFollowersCount = ((_c = finalFollowersCountAggregation[0]) === null || _c === void 0 ? void 0 : _c.finalFollowersCount) || 0;
        let percentageChange;
        if (initialFollowersCount === 0) {
            percentageChange = finalFollowersCount > 0 ? 100 : 0;
        }
        else {
            percentageChange =
                ((finalFollowersCount - initialFollowersCount) /
                    initialFollowersCount) *
                    100;
        }
        const activeSubscriptionsAggregation = await Subscription_1.Subscription.aggregate([
            {
                $match: {
                    userId: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $gte: start, $lte: end },
                    status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
                },
            },
            {
                $group: {
                    _id: null,
                    activeSubscriptionsCount: { $sum: 1 },
                },
            },
        ]);
        const initialActiveSubscriptionsAggregation = await Subscription_1.Subscription.aggregate([
            {
                $match: {
                    userId: new mongoose_1.Types.ObjectId(user.id),
                    createdAt: { $lt: start },
                    status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
                },
            },
            {
                $group: {
                    _id: null,
                    initialActiveSubscriptionsCount: { $sum: 1 },
                },
            },
        ]);
        const activeSubscriptionsCount = ((_d = activeSubscriptionsAggregation[0]) === null || _d === void 0 ? void 0 : _d.activeSubscriptionsCount) || 0;
        const initialActiveSubscriptionsCount = ((_e = initialActiveSubscriptionsAggregation[0]) === null || _e === void 0 ? void 0 : _e.initialActiveSubscriptionsCount) || 0;
        let subscriptionPercentageChange;
        if (initialActiveSubscriptionsCount === 0) {
            subscriptionPercentageChange = activeSubscriptionsCount > 0 ? 100 : 0;
        }
        else {
            subscriptionPercentageChange =
                ((activeSubscriptionsCount - initialActiveSubscriptionsCount) /
                    initialActiveSubscriptionsCount) *
                    100;
        }
        const likesCountAggregation = await Interaction_1.Interaction.aggregate([
            {
                $match: {
                    user: new mongoose_1.Types.ObjectId(user.id),
                    type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
                    createdAt: { $gte: start, $lte: end },
                },
            },
            {
                $group: {
                    _id: null,
                    likesCount: { $sum: 1 },
                },
            },
        ]);
        const finalLikesCount = ((_f = likesCountAggregation[0]) === null || _f === void 0 ? void 0 : _f.likesCount) || 0;
        const initialLikesCountAggregation = await Interaction_1.Interaction.aggregate([
            {
                $match: {
                    user: new mongoose_1.Types.ObjectId(user.id),
                    type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
                    createdAt: { $lt: start },
                },
            },
            {
                $group: {
                    _id: null,
                    initialLikesCount: { $sum: 1 },
                },
            },
        ]);
        const initialLikesCount = ((_g = initialLikesCountAggregation[0]) === null || _g === void 0 ? void 0 : _g.initialLikesCount) || 0;
        let percentageChangeLikes;
        if (initialLikesCount === 0) {
            percentageChangeLikes = finalLikesCount > 0 ? 100 : 0;
        }
        else {
            percentageChangeLikes =
                ((finalLikesCount - initialLikesCount) / initialLikesCount) * 100;
        }
        const mostRecentPost = await Post_1.Post.findOne({ user: user.id })
            .sort({ createdAt: -1 })
            .select("_id")
            .lean();
        if (!mostRecentPost) {
            console.log("No post found");
        }
        const likesCountOnRecentPostAggregation = await Interaction_1.Interaction.aggregate([
            {
                $match: {
                    post: mostRecentPost === null || mostRecentPost === void 0 ? void 0 : mostRecentPost._id,
                    type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
                },
            },
            {
                $group: {
                    _id: null,
                    likesCountOnRecentPost: { $sum: 1 },
                },
            },
        ]);
        const likesCountOnRecentPost = ((_h = likesCountOnRecentPostAggregation[0]) === null || _h === void 0 ? void 0 : _h.likesCountOnRecentPost) || 0;
        let tippedmostRecentPost = 0;
        if (mostRecentPost === null || mostRecentPost === void 0 ? void 0 : mostRecentPost._id) {
            const transactions = await Transaction_1.Transaction.find({
                productId: mostRecentPost === null || mostRecentPost === void 0 ? void 0 : mostRecentPost._id.toString(),
                type: transactionTypeEnum_1.TransactionType.CREDIT,
                status: transactionStatusEnum_1.TransactionStatus.SUCCESS,
            });
            transactions.forEach((transaction) => {
                tippedmostRecentPost += transaction.amount;
            });
        }
        const mostLikedPostAggregation = await Interaction_1.Interaction.aggregate([
            {
                $match: {
                    user: new mongoose_1.Types.ObjectId(user.id),
                    type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
                    createdAt: { $gte: start, $lte: end },
                },
            },
            {
                $group: {
                    _id: "$post",
                    likesCount: { $sum: 1 },
                },
            },
            {
                $sort: { likesCount: -1 },
            },
            {
                $limit: 1,
            },
        ]);
        const mostLikedPostId = (_j = mostLikedPostAggregation[0]) === null || _j === void 0 ? void 0 : _j._id;
        let likesCountOnMostLikedPost = 0;
        if (mostLikedPostId) {
            const likesOnMostLikedPostAggregation = await Interaction_1.Interaction.aggregate([
                {
                    $match: {
                        post: mostLikedPostId,
                        type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
                    },
                },
                {
                    $group: {
                        _id: null,
                        likesCount: { $sum: 1 },
                    },
                },
            ]);
            likesCountOnMostLikedPost =
                ((_k = likesOnMostLikedPostAggregation[0]) === null || _k === void 0 ? void 0 : _k.likesCount) || 0;
        }
        let tippedmostLikedPost = 0;
        if (mostLikedPostId === null || mostLikedPostId === void 0 ? void 0 : mostLikedPostId._id) {
            const transactions = await Transaction_1.Transaction.find({
                productId: mostLikedPostId === null || mostLikedPostId === void 0 ? void 0 : mostLikedPostId._id.toString(),
                type: transactionTypeEnum_1.TransactionType.CREDIT,
                status: transactionStatusEnum_1.TransactionStatus.SUCCESS,
            });
            transactions.forEach((transaction) => {
                tippedmostLikedPost += transaction.amount;
            });
        }
        const userPosts = await Post_1.Post.find({ user: user.id }).select("_id").lean();
        const postIds = userPosts.map((post) => post._id.toString());
        const transactionsForUserPosts = await Transaction_1.Transaction.aggregate([
            {
                $match: {
                    productId: { $in: postIds },
                    type: transactionTypeEnum_1.TransactionType.CREDIT,
                    status: transactionStatusEnum_1.TransactionStatus.SUCCESS,
                },
            },
            {
                $group: {
                    _id: "$productId",
                    totalTippedAmount: { $sum: "$amount" },
                },
            },
            {
                $sort: { totalTippedAmount: -1 },
            },
            {
                $limit: 1,
            },
        ]);
        const mostTippedPostId = (_l = transactionsForUserPosts[0]) === null || _l === void 0 ? void 0 : _l._id;
        const mostTippedAmount = ((_m = transactionsForUserPosts[0]) === null || _m === void 0 ? void 0 : _m.totalTippedAmount) || 0;
        let likesCountOnMostTippedPost = 0;
        if (mostTippedPostId) {
            const likesOnMostTippedPostAggregation = await Interaction_1.Interaction.aggregate([
                {
                    $match: {
                        post: new mongoose_1.Types.ObjectId(mostTippedPostId),
                        type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
                    },
                },
                {
                    $group: {
                        _id: null,
                        likesCount: { $sum: 1 },
                    },
                },
            ]);
            likesCountOnMostTippedPost =
                ((_o = likesOnMostTippedPostAggregation[0]) === null || _o === void 0 ? void 0 : _o.likesCount) || 0;
        }
        const response = {
            statistics: [
                {
                    title: "Followers",
                    value: followersCount.toString(),
                    percentageChange: parseFloat(percentageChange.toFixed(2)),
                },
                {
                    title: "Subscribers",
                    value: activeSubscriptionsCount.toString(),
                    percentageChange: parseFloat(subscriptionPercentageChange.toFixed(2)),
                },
                {
                    title: "Likes",
                    value: finalLikesCount.toString(),
                    percentageChange: parseFloat(percentageChangeLikes.toFixed(2)),
                },
            ],
            postAnalytics: [
                {
                    title: "Your Recent post",
                    liked: likesCountOnRecentPost,
                    tipped: tippedmostRecentPost,
                },
                {
                    title: "Most Liked post",
                    liked: likesCountOnMostLikedPost,
                    tipped: tippedmostLikedPost,
                },
                {
                    title: "Most Tipped post",
                    liked: likesCountOnMostTippedPost,
                    tipped: mostTippedAmount,
                },
            ],
        };
        return res.json(response);
    }
    catch (error) {
        console.error(error, "Error while fetching creator stats");
        return res.status(500).json({ error: "Internal server error." });
    }
};
exports.creatorStats = creatorStats;
//# sourceMappingURL=creatorStats.js.map