"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.likeAComment = void 0;
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const User_1 = require("../../../Models/User");
const notificationService_1 = require("../../../../utils/Notifications/notificationService");
const FirebaseNotificationEnum_1 = require("../../../../types/enums/FirebaseNotificationEnum");
const saveNotification_1 = require("../../Notifications/Actions/saveNotification");
const likeAComment = async (req, res) => {
    try {
        const commentId = req.params.id;
        const user = req.user;
        const comment = await Interaction_1.Interaction.findById(commentId);
        if (!comment) {
            return res
                .status(404)
                .json({ error: { message: "Parent comment not found" } });
        }
        if (comment.type !== InteractionTypeEnum_1.InteractionType.COMMENT) {
            return res.status(404).json({
                error: { message: "You can only like to a comment type interaction" },
            });
        }
        const commentLikeExist = await Interaction_1.Interaction.findOne({
            type: InteractionTypeEnum_1.InteractionType.LIKE_COMMENT,
            post: comment.post,
            user: comment.user,
            interactedBy: user._id,
            isDeleted: false,
            comment: comment.comment,
        });
        if (commentLikeExist) {
            console.log("HERERERERERE");
            await Interaction_1.Interaction.deleteOne({ _id: commentLikeExist.id });
            return res.json({
                data: {
                    message: "Comment disliked",
                },
            });
        }
        const likeToComment = new Interaction_1.Interaction({
            type: InteractionTypeEnum_1.InteractionType.LIKE_COMMENT,
            post: comment.post,
            user: comment.user,
            interactedBy: user._id,
            isDeleted: false,
            comment: comment.comment,
        });
        await likeToComment.save();
        if (!comment.likes) {
            comment.likes = [];
        }
        comment.likes.push(user._id);
        try {
            const userComment = await User_1.User.findById(comment.user);
            const interactedByUser = await User_1.User.findById(user.id);
            if (!interactedByUser) {
                return res
                    .status(404)
                    .json({ error: { message: "Username not found" } });
            }
            if (userComment && userComment.fcm_token) {
                const notificationToken = userComment.fcm_token;
                if (notificationToken) {
                    const notificationTitle = "New like on your comment";
                    const notificationDescription = `${interactedByUser.userName} liked your comment`;
                    await (0, notificationService_1.sendNotification)(notificationToken, "New Like on your comment", `${interactedByUser === null || interactedByUser === void 0 ? void 0 : interactedByUser.userName} liked your comment`, FirebaseNotificationEnum_1.FirebaseNotificationEnum.LIKE_COMMENT, comment.post);
                    await (0, saveNotification_1.saveNotification)({
                        title: notificationTitle,
                        description: notificationDescription,
                        sentTo: [userComment._id],
                        type: FirebaseNotificationEnum_1.FirebaseNotificationEnum.LIKE_COMMENT,
                        notificationOnPost: comment.post,
                        notificationFromUser: null,
                    });
                }
                else {
                    console.error("FCM token for the user not found");
                }
            }
        }
        catch (error) {
            console.log("Error sending like notification", error);
        }
        await comment.save();
        const updatedComment = await Interaction_1.Interaction.findById(commentId)
            .populate({
            path: "likes",
            populate: {
                path: "interactedBy",
                select: "username",
            },
        })
            .exec();
        return res.json({
            data: updatedComment,
            message: "Comment liked successfully",
        });
    }
    catch (error) {
        console.error("Error liking comment:", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.likeAComment = likeAComment;
//# sourceMappingURL=likeACommentAction.js.map