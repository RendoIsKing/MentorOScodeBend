"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionController = void 0;
const createSubscription_1 = require("./Actions/createSubscription");
const createOneTimeSubscription_1 = require("./Actions/createOneTimeSubscription");
const provideTip_1 = require("./Actions/provideTip");
class SubscriptionController {
}
exports.SubscriptionController = SubscriptionController;
SubscriptionController.createSubscription = (req, res) => {
    (0, createSubscription_1.createSubscription)(req, res);
};
SubscriptionController.createOneTimePayment = (req, res) => {
    (0, createOneTimeSubscription_1.createOneTimeSubscription)(req, res);
};
SubscriptionController.provideTipToCreator = (req, res) => {
    (0, provideTip_1.provideTipToCreator)(req, res);
};
//# sourceMappingURL=index.js.map