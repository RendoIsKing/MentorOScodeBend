"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const User_1 = require("../../app/Models/User");
const Post_1 = require("../../app/Models/Post");
const mongoose_1 = require("mongoose");
const bcryptjs_1 = require("bcryptjs");
const jwt_1 = require("../../utils/jwt");
const r = (0, express_1.Router)();
r.post("/dev/login-as", async (req, res) => {
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
        if (!devOn)
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const { email } = req.body;
        if (!email)
            return res.status(400).json({ error: "email required" });
        let user = await User_1.User.findOne({ email });
        if (!user)
            return res.status(404).json({ error: "user not found" });
        // Ensure dev user can pass Auth checks
        if (user.isDeleted || !user.isActive || !user.isVerified) {
            await User_1.User.updateOne({ _id: user._id }, { $set: { isDeleted: false, isActive: true, isVerified: true } });
            user = await User_1.User.findById(user._id);
        }
        req.session = req.session || {};
        req.session.user = { id: user._id.toString() };
        try {
            const token = (0, jwt_1.generateAuthToken)(user);
            res.cookie('auth_token', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 24 * 30, path: '/' });
        }
        catch { }
        return res.json({ ok: true, userId: user._id.toString() });
    }
    catch (e) {
        return res.status(500).json({ error: "login failed" });
    }
});
// GET variant for convenience (dev only)
r.get("/dev/login-as", async (req, res) => {
    var _a, _b;
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
        if (!devOn)
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const email = (_a = req.query) === null || _a === void 0 ? void 0 : _a.email;
        const userName = (_b = req.query) === null || _b === void 0 ? void 0 : _b.userName;
        if (!email && !userName)
            return res.status(400).json({ error: "email or userName query required" });
        let user = email ? await User_1.User.findOne({ email }) : null;
        if (!user && userName)
            user = await User_1.User.findOne({ userName });
        if (!user)
            return res.status(404).json({ error: "user not found" });
        if (user.isDeleted || !user.isActive || !user.isVerified) {
            await User_1.User.updateOne({ _id: user._id }, { $set: { isDeleted: false, isActive: true, isVerified: true } });
            user = await User_1.User.findById(user._id);
        }
        req.session = req.session || {};
        req.session.user = { id: user._id.toString() };
        try {
            const token = (0, jwt_1.generateAuthToken)(user);
            res.cookie('auth_token', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 24 * 30, path: '/' });
        }
        catch { }
        return res.json({ ok: true, userId: user._id.toString() });
    }
    catch (e) {
        return res.status(500).json({ error: "login failed" });
    }
});
exports.default = r;
// Dev-only sanity endpoints
r.get('/me', (req, res) => {
    var _a, _b;
    const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
    const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
    if (!devOn)
        return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
    const id = (_b = (_a = req.session) === null || _a === void 0 ? void 0 : _a.user) === null || _b === void 0 ? void 0 : _b.id;
    if (id)
        return res.json({ ok: true, userId: id });
    return res.status(401).json({ ok: false });
});
const ChangeEvent_1 = __importDefault(require("../../models/ChangeEvent"));
r.get('/events', async (req, res) => {
    var _a, _b;
    const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
    const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
    if (!devOn)
        return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
    const id = (_b = (_a = req.session) === null || _a === void 0 ? void 0 : _a.user) === null || _b === void 0 ? void 0 : _b.id;
    if (!id)
        return res.status(401).json({ ok: false });
    const items = await ChangeEvent_1.default.find({ user: id }).sort({ createdAt: -1 }).limit(10).lean();
    return res.json({ ok: true, items });
});
// Dev-only: set current user's username
r.post('/dev/set-username', async (req, res) => {
    var _a, _b, _c;
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
        if (!devOn)
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const newUserName = (_a = req.body) === null || _a === void 0 ? void 0 : _a.userName;
        if (!newUserName)
            return res.status(400).json({ error: 'userName required' });
        const current = ((_c = (_b = req.session) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.id) ? await User_1.User.findById(req.session.user.id) : null;
        if (!current)
            return res.status(401).json({ error: 'no session' });
        const taken = await User_1.User.findOne({ userName: newUserName });
        if (taken && String(taken._id) !== String(current._id))
            return res.status(400).json({ error: 'username taken' });
        current.userName = newUserName;
        await current.save();
        return res.json({ ok: true, userId: current._id.toString(), userName: current.userName });
    }
    catch (e) {
        return res.status(500).json({ error: 'set username failed' });
    }
});
// Dev-only: migrate posts from source userId to current session user
r.post('/dev/migrate-posts', async (req, res) => {
    var _a, _b, _c, _d;
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
        if (!devOn)
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const source = (_a = req.body) === null || _a === void 0 ? void 0 : _a.sourceUserId;
        if (!source || !mongoose_1.Types.ObjectId.isValid(source))
            return res.status(400).json({ error: 'valid sourceUserId required' });
        const targetId = (_c = (_b = req.session) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.id;
        if (!targetId || !mongoose_1.Types.ObjectId.isValid(targetId))
            return res.status(401).json({ error: 'no session' });
        const result = await Post_1.Post.updateMany({ user: new mongoose_1.Types.ObjectId(source) }, { $set: { user: new mongoose_1.Types.ObjectId(targetId) } });
        return res.json({ ok: true, modified: (_d = result.modifiedCount) !== null && _d !== void 0 ? _d : result.nModified });
    }
    catch (e) {
        return res.status(500).json({ error: 'migrate failed' });
    }
});
// Dev-only: set password for the current session user
r.post('/dev/set-password', async (req, res) => {
    var _a, _b, _c;
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        const devOn = enabled === 'true' || (process.env.NODE_ENV !== 'production');
        if (!devOn)
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const pwd = (_a = req.body) === null || _a === void 0 ? void 0 : _a.password;
        if (!pwd || pwd.length < 6)
            return res.status(400).json({ error: 'password (>=6 chars) required' });
        const userId = (_c = (_b = req.session) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.id;
        if (!userId || !mongoose_1.Types.ObjectId.isValid(userId))
            return res.status(401).json({ error: 'no session' });
        const salt = (0, bcryptjs_1.genSaltSync)(10);
        const hashed = (0, bcryptjs_1.hashSync)(pwd, salt);
        await User_1.User.updateOne({ _id: new mongoose_1.Types.ObjectId(userId) }, { $set: { password: hashed } });
        return res.json({ ok: true });
    }
    catch (e) {
        return res.status(500).json({ error: 'set password failed' });
    }
});
// GET convenience for password set (dev only)
r.get('/dev/set-password', async (req, res) => {
    var _a, _b, _c;
    try {
        const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
        if (enabled !== 'true')
            return res.status(404).json({ error: 'DEV_LOGIN_DISABLED', value: process.env.DEV_LOGIN_ENABLED });
        const pwd = (_a = req.query) === null || _a === void 0 ? void 0 : _a.password;
        if (!pwd || pwd.length < 6)
            return res.status(400).json({ error: 'password (>=6 chars) required' });
        const userId = (_c = (_b = req.session) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.id;
        if (!userId || !mongoose_1.Types.ObjectId.isValid(userId))
            return res.status(401).json({ error: 'no session' });
        const salt = (0, bcryptjs_1.genSaltSync)(10);
        const hashed = (0, bcryptjs_1.hashSync)(pwd, salt);
        await User_1.User.updateOne({ _id: new mongoose_1.Types.ObjectId(userId) }, { $set: { password: hashed } });
        return res.json({ ok: true });
    }
    catch (e) {
        return res.status(500).json({ error: 'set password failed' });
    }
});
//# sourceMappingURL=loginAs.js.map