"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoachKnowledgeSchema = void 0;
const mongoose_1 = require("mongoose");
exports.CoachKnowledgeSchema = new mongoose_1.Schema({
    coachId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String },
    text: { type: String },
    filePath: { type: String },
    mimeType: { type: String },
    sizeBytes: { type: Number },
}, { timestamps: true });
exports.CoachKnowledgeSchema.index({ coachId: 1, createdAt: -1 });
//# sourceMappingURL=CoachKnowledgeSchema.js.map