"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const PlanPreviewSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", index: true, required: true, unique: true },
    trainingWeek: [
        {
            day: String,
            focus: String,
            exercises: [
                {
                    name: String,
                    sets: Number,
                    reps: String,
                    rpe: String,
                    rationale: String,
                },
            ],
        },
    ],
    nutrition: {
        kcal: Number,
        proteinGrams: Number,
        carbsGrams: Number,
        fatGrams: Number,
        rationale: String,
    },
    hash: { type: String, index: true },
}, { timestamps: true });
exports.default = (0, mongoose_1.model)("PlanPreview", PlanPreviewSchema);
//# sourceMappingURL=PlanPreview.js.map