"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Auth;
const passport_1 = __importDefault(require("passport"));
const User_1 = require("../Models/User");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
async function Auth(req, res, next) {
    var _a;
    try {
        // Support session-based auth first
        // @ts-ignore - session is provided by express-session
        const sessionUser = (_a = req.session) === null || _a === void 0 ? void 0 : _a.user;
        if (sessionUser === null || sessionUser === void 0 ? void 0 : sessionUser.id) {
            const user = await User_1.User.findById(sessionUser.id);
            if (!user) {
                return res.status(401).json({ error: { message: "User not found" } });
            }
            if (user.isDeleted) {
                return res
                    .status(401)
                    .json({ error: { message: "User is deleted.Please contact admin!" } });
            }
            if (!user.isActive || !user.isVerified) {
                return res.status(401).json({
                    error: { message: "User is not verified or not active.Please contact admin!" },
                });
            }
            // @ts-ignore
            req.user = user;
            return next();
        }
        // Fallback 1: Try Bearer header
        const authHeader = req.headers.authorization;
        let token = undefined;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.slice('Bearer '.length);
        }
        // Fallback 2: Try auth_token cookie without introducing cookie-parser
        if (!token && typeof req.headers.cookie === 'string') {
            const match = req.headers.cookie.split(';').map(s => s.trim()).find(c => c.startsWith('auth_token='));
            if (match) {
                const raw = match.split('=').slice(1).join('=');
                try {
                    token = decodeURIComponent(raw);
                }
                catch {
                    token = raw;
                }
                // Some proxies mutate '+' to spaces; fix common case
                if (token && token.includes(' '))
                    token = token.replace(/\s/g, '+');
            }
        }
        if (token) {
            try {
                const primary = process.env.APP_SECRET || process.env.JWT_SECRET || 'secret_secret';
                let payload;
                try {
                    payload = jsonwebtoken_1.default.verify(token, primary);
                }
                catch (e) {
                    // Try fallback dev secret used elsewhere
                    try {
                        payload = jsonwebtoken_1.default.verify(token, 'dev_session_secret_change_me');
                    }
                    catch { }
                }
                if (!(payload === null || payload === void 0 ? void 0 : payload.id))
                    return res.status(401).json({ error: { message: 'Invalid Token. Access Denied!' } });
                const dbUser = await User_1.User.findById(payload.id);
                if (!dbUser)
                    return res.status(401).json({ error: { message: 'User not found' } });
                if (dbUser.isDeleted)
                    return res.status(401).json({ error: { message: 'User is deleted.Please contact admin!' } });
                if (!dbUser.isActive || !dbUser.isVerified)
                    return res.status(401).json({ error: { message: 'User is not verified or not active.Please contact admin!' } });
                // @ts-ignore
                req.user = dbUser;
                return next();
            }
            catch (e) {
                // fall through to passport jwt below
            }
        }
        // Last resort: passport JWT (Bearer only)
        return passport_1.default.authenticate("jwt", { session: false }, async (err, payload) => {
            if (err) {
                return res.status(500).json({ error: { message: "Something went wrong" } });
            }
            if (!payload) {
                return res.status(401).json({ error: { message: "Invalid Token. Access Denied!" } });
            }
            const dbUser = await User_1.User.findById(payload.id);
            if (!dbUser)
                return res.status(401).json({ error: { message: "User not found" } });
            if (dbUser.isDeleted)
                return res.status(401).json({ error: { message: "User is deleted.Please contact admin!" } });
            if (!dbUser.isActive || !dbUser.isVerified)
                return res.status(401).json({ error: { message: "User is not verified or not active.Please contact admin!" } });
            // @ts-ignore
            req.user = dbUser;
            return next();
        })(req, res, next);
    }
    catch (e) {
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
}
//# sourceMappingURL=auth.js.map