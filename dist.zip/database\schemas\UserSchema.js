"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserSchema = void 0;
const mongoose_1 = require("mongoose");
const RolesEnum_1 = require("../../types/RolesEnum");
const UserSchema = new mongoose_1.Schema({
    fullName: {
        type: String,
    },
    firstName: {
        type: String,
    },
    lastName: {
        type: String,
    },
    userName: {
        type: String,
    },
    password: {
        type: String,
        default: null,
    },
    dob: {
        type: String,
    },
    bio: {
        type: String,
    },
    gender: {
        type: String,
    },
    email: {
        type: String,
        // unique: true,
    },
    googleId: {
        type: String,
        index: true,
        default: null,
    },
    hasPersonalInfo: {
        type: Boolean,
        default: false,
    },
    hasPhotoInfo: {
        type: Boolean,
        default: false,
    },
    hasSelectedInterest: {
        type: Boolean,
        default: false,
    },
    hasConfirmedAge: {
        type: Boolean,
        default: false,
    },
    hasDocumentUploaded: {
        type: Boolean,
        default: false,
    },
    hasDocumentVerified: {
        type: Boolean,
        default: false,
    },
    location: {
        type: [
            {
                lat: {
                    type: Number,
                    required: true,
                    min: -90,
                    max: 90,
                },
                long: {
                    type: Number,
                    required: true,
                    min: -180,
                    max: 180,
                },
            },
        ],
        default: [],
    },
    dialCode: {
        type: String,
    },
    phoneNumber: {
        type: String,
        // unique: true,
        default: null,
    },
    photoId: {
        type: mongoose_1.Types.ObjectId,
        required: false,
        ref: "File",
    },
    coverPhotoId: {
        type: mongoose_1.Types.ObjectId,
        required: false,
        ref: "File",
    },
    interests: [
        {
            type: mongoose_1.Types.ObjectId,
            ref: "Interest",
        },
    ],
    primaryCollection: {
        type: mongoose_1.Types.ObjectId,
        ref: "Collection",
    },
    isStripeCustomer: {
        type: Boolean,
        default: false,
    },
    stripeClientId: {
        type: String,
        default: null,
    },
    instagramLink: {
        type: String,
        default: null,
    },
    facebookLink: {
        type: String,
        default: null,
    },
    tiktokLink: {
        type: String,
        default: null,
    },
    youtubeLink: {
        type: String,
        default: null,
    },
    stripeProductId: String,
    stripeProduct: {
        type: {},
        required: false,
    },
    role: {
        type: String,
        default: RolesEnum_1.RolesEnum.USER,
    },
    // Mentor mode (UI/UX gating). This does NOT grant admin privileges.
    // Default false for all existing users.
    isMentor: {
        type: Boolean,
        default: false,
        index: true,
    },
    isActive: {
        type: Boolean,
        default: true,
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: {
        type: Date,
        default: null,
    },
    verifiedAt: {
        type: Date,
        default: null,
    },
    verifiedBy: {
        type: String,
        default: null,
    },
    isVerified: {
        type: Boolean,
        default: false,
    },
    fcm_token: {
        type: String,
    },
    completePhoneNumber: String,
    otp: {
        type: String,
    },
    isFreeSubscription: {
        type: Boolean,
        default: false,
    },
    otpInvalidAt: Date,
    status: {
        type: String,
        enum: ["VISITOR", "LEAD", "TRIAL", "SUBSCRIBED"],
        default: "VISITOR",
        index: true,
    },
    acceptedTosAt: {
        type: Date,
        default: null,
    },
    tosVersion: {
        type: String,
        default: null,
    },
    profileId: {
        type: mongoose_1.Types.ObjectId,
        ref: "Profile",
    },
}, { timestamps: true });
exports.UserSchema = UserSchema;
UserSchema.pre("save", async function (next) {
    try {
        const dial = this.dialCode;
        const phone = this.phoneNumber;
        if (dial && phone) {
            this.completePhoneNumber = `${dial}--${phone}`;
        }
        else {
            // Avoid setting a duplicate placeholder value that could violate a unique index
            this.completePhoneNumber = undefined;
        }
        next();
    }
    catch (error) {
        next(error);
    }
});
UserSchema.pre("findOneAndUpdate", function (next) {
    var _a, _b, _c, _d;
    const update = this.getUpdate();
    if (update) {
        const updateDoc = update;
        const dialCode = (_a = updateDoc.dialCode) !== null && _a !== void 0 ? _a : (_b = updateDoc.$set) === null || _b === void 0 ? void 0 : _b.dialCode;
        const phoneNumber = (_c = updateDoc.phoneNumber) !== null && _c !== void 0 ? _c : (_d = updateDoc.$set) === null || _d === void 0 ? void 0 : _d.phoneNumber;
        if (dialCode !== undefined || phoneNumber !== undefined) {
            if (!updateDoc.$set)
                updateDoc.$set = {};
            if (dialCode && phoneNumber) {
                updateDoc.$set.completePhoneNumber = `${dialCode}--${phoneNumber}`;
            }
            else {
                // If one is missing, clear the computed field to avoid duplicate placeholders
                updateDoc.$set.completePhoneNumber = undefined;
            }
        }
    }
    next();
});
UserSchema.set("toObject", { virtuals: true });
UserSchema.set("toJSON", { virtuals: true });
UserSchema.virtual("photo", {
    ref: "File",
    localField: "photoId",
    foreignField: "_id",
    justOne: true,
});
//# sourceMappingURL=UserSchema.js.map