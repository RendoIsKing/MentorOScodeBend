"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePaymentStatusWebhookStripe = void 0;
const User_1 = require("../../../Models/User");
const Transaction_1 = require("../../../Models/Transaction");
const transactionStatusEnum_1 = require("../../../../types/enums/transactionStatusEnum");
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const Subscription_1 = require("../../../Models/Subscription");
const mongoose_1 = require("mongoose");
const Sentry = __importStar(require("@sentry/node"));
const SubscriptionStatusEnum_1 = require("../../../../types/enums/SubscriptionStatusEnum");
const handlePaymentStatusWebhookStripe = async (req, res) => {
    const stripe = stripe_1.default;
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!endpointSecret) {
        throw new Error("STRIPE_WEBHOOK_SECRET is missing");
    }
    if (req.method !== "POST") {
        res.setHeader("Allow", "POST");
        return res.status(405).end("Method Not Allowed");
    }
    const sig = req.headers["stripe-signature"];
    if (!sig) {
        console.log(`⚠️  Missing Stripe signature.`);
        return res.status(400).send(`Webhook Error: Missing Stripe signature.`);
    }
    let event;
    try {
        event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    }
    catch (err) {
        console.log(`⚠️  Webhook signature verification failed.`, err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    try {
        Sentry.addBreadcrumb({ category: 'stripe', message: 'webhook', data: { type: event === null || event === void 0 ? void 0 : event.type } });
    }
    catch { }
    switch (event.type) {
        case "customer.subscription.created":
        case "customer.subscription.trial_will_end":
        case "customer.subscription.paused":
        case "customer.subscription.resumed":
            await handleSubscriptionEvent(event);
            break;
        case "payment_intent.created":
            await handlePaymentIntentCreated(event);
            break;
        case "payment_intent.succeeded":
            await handlePaymentSuccess(event);
            break;
        case "invoice.payment_failed":
        case "payment_intent.payment_failed":
            await handlePaymentFailed(event);
            break;
        default:
            console.log(`Unhandled event type ${event.type}`);
    }
    return res.json({ received: true });
};
exports.handlePaymentStatusWebhookStripe = handlePaymentStatusWebhookStripe;
const handleSubscriptionEvent = async (event) => {
    const subscriptionData = event.data.object;
    console.log("Handling subscription event:", subscriptionData);
    try {
        let updatedSubscription = await Subscription_1.Subscription.findOneAndUpdate({
            StripeSubscriptionId: subscriptionData.id,
            status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.INACTIVE,
        }, {
            status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
            startDate: new Date(subscriptionData.start_date * 1000),
            endDate: new Date(subscriptionData.current_period_end * 1000),
            stripeSubscriptionObject: JSON.stringify(subscriptionData),
        }, { new: true });
        if (!updatedSubscription) {
            // Fallback: upsert by user (metadata.userId or stripe customer -> User)
            let userId;
            const metaUserId = ((subscriptionData === null || subscriptionData === void 0 ? void 0 : subscriptionData.metadata) && (subscriptionData.metadata.userId || subscriptionData.metadata.userid)) || undefined;
            if (metaUserId)
                userId = metaUserId;
            if (!userId && (subscriptionData === null || subscriptionData === void 0 ? void 0 : subscriptionData.customer)) {
                try {
                    const user = await User_1.User.findOne({ stripeClientId: subscriptionData.customer }).lean();
                    if (user === null || user === void 0 ? void 0 : user._id)
                        userId = String(user._id);
                }
                catch { }
            }
            if (!userId) {
                console.error('Unable to resolve user for subscription', typeof subscriptionData.customer === 'string' ? subscriptionData.customer.slice(-6) : 'unknown');
                return;
            }
            const priceId = (() => {
                var _a, _b, _c, _d;
                try {
                    return ((_d = (_c = (_b = (_a = subscriptionData === null || subscriptionData === void 0 ? void 0 : subscriptionData.items) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.price) === null || _d === void 0 ? void 0 : _d.id) || '';
                }
                catch {
                    return '';
                }
            })();
            updatedSubscription = await Subscription_1.Subscription.findOneAndUpdate({ StripeSubscriptionId: subscriptionData.id }, {
                userId: new mongoose_1.Types.ObjectId(userId),
                planId: new mongoose_1.Types.ObjectId(),
                StripeSubscriptionId: subscriptionData.id,
                StripePriceId: priceId || 'price_unknown',
                status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
                startDate: new Date(subscriptionData.start_date * 1000),
                endDate: new Date(subscriptionData.current_period_end * 1000),
                stripeSubscriptionObject: JSON.stringify(subscriptionData),
            }, { upsert: true, new: true });
        }
        try {
            if (!updatedSubscription)
                return; // TS guard
            // Mark user as subscribed and persist entitlement flag for access guard
            await User_1.User.updateOne({ _id: updatedSubscription.userId }, { $set: { status: 'SUBSCRIBED' } });
        }
        catch (e) {
            console.log('user entitlement update failed');
        }
        if (updatedSubscription)
            console.log("Subscription Updated:", { id: updatedSubscription._id, status: updatedSubscription.status });
    }
    catch (error) {
        console.error("Error handling subscription event:", error);
    }
};
const handlePaymentIntentCreated = async (event) => {
    const paymentIntent = event.data.object;
    console.log("Payment Intent Created:", paymentIntent);
};
const handlePaymentSuccess = async (event) => {
    const paymentIntent = event.data.object;
    const user = await User_1.User.findOne({ stripeClientId: paymentIntent.customer });
    if (!user) {
        console.error("User not found for customer ID:", typeof paymentIntent.customer === 'string' ? paymentIntent.customer.slice(-6) : 'unknown');
        return;
    }
    console.log("paymentIntentpaymentIntent In webhook-->>", paymentIntent);
    const updatedTransaction = await Transaction_1.Transaction.updateMany({
        stripePaymentIntentId: paymentIntent.id,
        status: transactionStatusEnum_1.TransactionStatus.PENDING,
    }, {
        status: transactionStatusEnum_1.TransactionStatus.SUCCESS,
    }, { new: true });
    console.log("Payment Success Transaction recorded:", updatedTransaction);
};
const handlePaymentFailed = async (event) => {
    const paymentIntent = event.data.object;
    const user = await User_1.User.findOne({ stripeClientId: paymentIntent.customer });
    if (!user) {
        console.error("User not found for customer ID:", typeof paymentIntent.customer === 'string' ? paymentIntent.customer.slice(-6) : 'unknown');
        return;
    }
    console.log("paymentIntentpaymentIntent In webhook-->>", paymentIntent);
    const updatedTransaction = await Transaction_1.Transaction.updateMany({
        stripePaymentIntentId: paymentIntent.id,
        status: transactionStatusEnum_1.TransactionStatus.PENDING,
    }, {
        status: transactionStatusEnum_1.TransactionStatus.FAILED,
    }, { new: true });
    await Transaction_1.Transaction.create(updatedTransaction);
    console.log("Payment Failed Transaction recorded:", updatedTransaction);
};
//# sourceMappingURL=handlePaymentStatusStripeWebhook.js.map