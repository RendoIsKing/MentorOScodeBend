"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionPlanInput = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const subscriptionPlanEnum_1 = require("../../../../types/enums/subscriptionPlanEnum");
class EntitlementInput {
}
__decorate([
    (0, class_validator_1.IsString)({ message: "Feature should be a string." }),
    __metadata("design:type", String)
], EntitlementInput.prototype, "feature", void 0);
__decorate([
    (0, class_validator_1.IsString)({ message: "description should be a string." }),
    __metadata("design:type", String)
], EntitlementInput.prototype, "description", void 0);
class SubscriptionPlanInput {
}
exports.SubscriptionPlanInput = SubscriptionPlanInput;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Title should be a string." }),
    __metadata("design:type", String)
], SubscriptionPlanInput.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Description should be a string." }),
    __metadata("design:type", String)
], SubscriptionPlanInput.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)({}, { message: "Price should be a number." }),
    __metadata("design:type", Number)
], SubscriptionPlanInput.prototype, "price", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)({}, { message: "Duration should be a number." }),
    __metadata("design:type", Number)
], SubscriptionPlanInput.prototype, "duration", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(subscriptionPlanEnum_1.SubscriptionPlanType, {
        message: "Plan type must be either FIXED or CUSTOM.",
    }),
    __metadata("design:type", String)
], SubscriptionPlanInput.prototype, "planType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => EntitlementInput),
    __metadata("design:type", Array)
], SubscriptionPlanInput.prototype, "entitlements", void 0);
//# sourceMappingURL=subscriptionPlanInput.js.map