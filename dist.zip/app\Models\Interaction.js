"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Interaction = void 0;
const mongoose_1 = require("mongoose");
const InteractionsSchema_1 = require("../../database/schemas/InteractionsSchema");
const Interaction = (0, mongoose_1.model)("Interaction", InteractionsSchema_1.InteractionSchema);
exports.Interaction = Interaction;
//# sourceMappingURL=Interaction.js.map