"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WeightEntrySchema = void 0;
const mongoose_1 = require("mongoose");
exports.WeightEntrySchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    date: { type: String, required: true },
    kg: { type: Number, required: true },
}, { timestamps: true });
exports.WeightEntrySchema.index({ userId: 1, date: 1 }, { unique: true });
exports.WeightEntrySchema.index({ userId: 1, date: 1, kg: 1 });
//# sourceMappingURL=WeightEntrySchema.js.map