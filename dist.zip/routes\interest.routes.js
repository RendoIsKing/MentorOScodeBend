"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Interests_1 = require("../app/Controllers/Interests");
const interest = (0, express_1.Router)();
interest.post("/", Middlewares_1.OnlyAdmins, Interests_1.InterestController.createInterest);
interest.post("/user", Middlewares_1.Auth, Interests_1.InterestController.postInterest);
interest.get('/', Middlewares_1.Auth, Interests_1.InterestController.getAllInterest);
interest.delete("/:id", Middlewares_1.OnlyAdmins, Interests_1.InterestController.deleteInterest);
interest.post("/update/:id", Middlewares_1.OnlyAdmins, Interests_1.InterestController.updateInterest);
exports.default = interest;
//# sourceMappingURL=interest.routes.js.map