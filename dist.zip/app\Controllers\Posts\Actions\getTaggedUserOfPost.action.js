"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTaggedUsers = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const Post_1 = require("../../../Models/Post");
const getTaggedUsers = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;
        if (!mongoose_1.default.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ error: "Invalid ID format" });
        }
        const post = await Post_1.Post.aggregate([
            {
                $match: {
                    _id: new mongoose_1.default.Types.ObjectId(id),
                    deletedAt: null,
                    isDeleted: false,
                },
            },
            {
                $lookup: {
                    from: "users",
                    let: { userTags: "$userTags" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $in: ["$_id", "$$userTags.userId"],
                                },
                            },
                        },
                        {
                            $lookup: {
                                from: "userconnections",
                                let: { userId: "$_id" },
                                pipeline: [
                                    {
                                        $match: {
                                            $expr: {
                                                $and: [
                                                    {
                                                        $eq: [
                                                            "$owner",
                                                            new mongoose_1.default.Types.ObjectId(user._id),
                                                        ],
                                                    },
                                                    { $eq: ["$followingTo", "$$userId"] },
                                                ],
                                            },
                                        },
                                    },
                                ],
                                as: "isFollowing",
                            },
                        },
                        {
                            $addFields: {
                                isFollowing: { $gt: [{ $size: "$isFollowing" }, 0] },
                            },
                        },
                        {
                            $lookup: {
                                from: "files",
                                localField: "photoId",
                                foreignField: "_id",
                                as: "photo",
                            },
                        },
                        {
                            $unwind: {
                                path: "$photo",
                                preserveNullAndEmptyArrays: true,
                            },
                        },
                        {
                            $project: {
                                _id: 1,
                                fullName: 1,
                                userName: 1,
                                photoId: 1,
                                isFollowing: 1,
                                "photo.path": 1,
                            },
                        },
                    ],
                    as: "taggedUsers",
                },
            },
            {
                $project: {
                    taggedUsers: 1,
                },
            },
        ]);
        if (post.length === 0) {
            return res.status(404).json({ error: "Post not found" });
        }
        return res.json(post[0]);
    }
    catch (error) {
        console.error("Error retrieving tagged users:", error);
        return res.status(500).json({ error: "Internal Server Error" });
    }
};
exports.getTaggedUsers = getTaggedUsers;
//# sourceMappingURL=getTaggedUserOfPost.action.js.map