"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDataSchema = void 0;
const mongoose_1 = require("mongoose");
const fileFormatEnum_1 = require("../../types/enums/fileFormatEnum");
const UserDataSchema = new mongoose_1.Schema({
    user: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
        required: true,
    },
    data: {
        type: mongoose_1.Schema.Types.Mixed,
        required: true,
    },
    fileFormat: {
        type: String,
        enum: [fileFormatEnum_1.FileFormatEnum.JSON, fileFormatEnum_1.FileFormatEnum.TEXT],
    },
    downloadBefore: {
        type: Date,
        required: true,
    },
    isExpired: {
        type: Boolean,
        default: false,
    },
}, {
    timestamps: true,
});
exports.UserDataSchema = UserDataSchema;
//# sourceMappingURL=userDataSchema.js.map