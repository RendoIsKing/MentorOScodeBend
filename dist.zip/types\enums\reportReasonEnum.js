"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReasonEnum = void 0;
var ReasonEnum;
(function (ReasonEnum) {
    ReasonEnum["VIOLENCE"] = "violence";
    ReasonEnum["REGULATED_GOODS_AND_ACTIVITIES"] = "regulated-goods";
    ReasonEnum["HATE_OR_HARASSMENT"] = "hate-harassment";
    ReasonEnum["FRAUD"] = "fraud";
    ReasonEnum["PRETENDING_TO_BE_SOMEONE_ELSE"] = "pretending";
    ReasonEnum["INTELLECTUAL_PROPERTY_VIOLATION"] = "ip-violation";
    ReasonEnum["SPAM"] = "spam";
    ReasonEnum["OTHER"] = "other";
})(ReasonEnum || (exports.ReasonEnum = ReasonEnum = {}));
//# sourceMappingURL=reportReasonEnum.js.map