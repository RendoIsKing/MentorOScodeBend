"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const StudentSnapshotSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", unique: true, index: true, required: true },
    weightSeries: [{ t: String, v: Number }],
    trainingPlanSummary: { daysPerWeek: Number },
    nutritionSummary: { kcal: Number, protein: Number, carbs: Number, fat: Number },
    kpis: { nextWorkout: String, adherence7d: Number, lastCheckIn: String },
}, { timestamps: { createdAt: false, updatedAt: 'updatedAt' } });
exports.default = (0, mongoose_1.model)("StudentSnapshot", StudentSnapshotSchema);
//# sourceMappingURL=StudentSnapshot.js.map