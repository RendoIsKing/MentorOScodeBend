"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Transactions_1 = require("../app/Controllers/Transactions");
const TransactionRoutes = (0, express_1.Router)();
TransactionRoutes.get("/", Middlewares_1.Auth, Transactions_1.TransactionController.getOwnTransactions);
TransactionRoutes.get("/all", Middlewares_1.OnlyAdmins, Transactions_1.TransactionController.getAllTransactions);
exports.default = TransactionRoutes;
//# sourceMappingURL=transaction.routes.js.map