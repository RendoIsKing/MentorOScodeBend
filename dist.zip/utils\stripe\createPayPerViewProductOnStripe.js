"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPayPerViewProductOnStripe = void 0;
const _1 = __importDefault(require("."));
const createPayPerViewProductOnStripe = async (product) => {
    try {
        const stripePayPerViewProduct = await _1.default.products.create({
            name: product.title,
            description: product.description,
            metadata: {},
            default_price_data: {
                currency: product.stripe_currency,
                unit_amount: product.price,
                // name: body.name,
            },
        });
        return stripePayPerViewProduct;
    }
    catch (error) {
        console.log("Error creating pay per view product", error);
        // return error;
    }
};
exports.createPayPerViewProductOnStripe = createPayPerViewProductOnStripe;
//# sourceMappingURL=createPayPerViewProductOnStripe.js.map