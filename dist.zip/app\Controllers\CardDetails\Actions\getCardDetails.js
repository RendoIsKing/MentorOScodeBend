"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCardDetails = void 0;
const extractCardDetailsFromToken_1 = require("./extractCardDetailsFromToken");
const CardDetails_1 = require("../../../Models/CardDetails");
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const getCardDetails = async (req, res) => {
    try {
        const { tokenId } = req.body;
        const user = req.user;
        console.log("user ", user);
        if (!tokenId) {
            return res.status(400).json({ error: "Token ID is required" });
        }
        const paymentMethod = await stripe_1.default.paymentMethods.create({
            type: "card",
            card: { token: tokenId },
        });
        const existingCards = await stripe_1.default.paymentMethods.list({
            customer: user.stripeClientId,
            type: "card",
        });
        const isCardExist = existingCards.data.some((card) => {
            //@ts-ignore
            return card.card.fingerprint === paymentMethod.card.fingerprint;
        });
        if (isCardExist) {
            return res.status(400).json({ error: "Card already exists" });
        }
        const cardDetail = await (0, extractCardDetailsFromToken_1.extractCardDetailsFromToken)(tokenId);
        await stripe_1.default.paymentMethods.attach(paymentMethod.id, {
            customer: user.stripeClientId,
        });
        const userCardCount = await CardDetails_1.cardDetails.countDocuments({
            userId: user.id,
            isDeleted: false,
        });
        const isDefault = userCardCount === 0;
        const cardDetailsDocument = new CardDetails_1.cardDetails({
            userId: user.id,
            stripeCardId: cardDetail.id,
            object: cardDetail.object,
            address_city: cardDetail.address_city,
            address_country: cardDetail.address_country,
            brand: cardDetail.brand,
            country: cardDetail.country,
            cvc_check: cardDetail.cvc_check,
            dynamic_last4: cardDetail.dynamic_last4,
            exp_month: cardDetail.exp_month,
            exp_year: cardDetail.exp_year,
            fingerprint: cardDetail.fingerprint,
            funding: cardDetail.funding,
            last4: cardDetail.last4,
            tokenization_method: cardDetail.tokenization_method,
            paymentMethodId: paymentMethod.id,
            isActive: true,
            isDefault: isDefault,
            activatedAt: new Date(),
        });
        await stripe_1.default.customers.update(user.stripeClientId, {
            // metadata: {
            //   order_id: '6735',
            // },
            invoice_settings: {
                default_payment_method: paymentMethod.id,
            },
        });
        await stripe_1.default.customers.retrieve(user.stripeClientId);
        await cardDetailsDocument.save();
        return res.json({
            message: "Card details saved successfully",
            cardDetails: cardDetailsDocument,
        });
    }
    catch (error) {
        console.error("Error in getting card details", error);
        return res.status(500).json({
            message: "Something went wrong",
            error: error.message,
        });
    }
};
exports.getCardDetails = getCardDetails;
//# sourceMappingURL=getCardDetails.js.map