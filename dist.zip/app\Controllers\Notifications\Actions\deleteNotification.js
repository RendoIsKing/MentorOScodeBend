"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteNotification = void 0;
const Notification_1 = require("../../../Models/Notification");
const mongoose_1 = __importDefault(require("mongoose"));
const RolesEnum_1 = require("../../../../types/RolesEnum");
const deleteNotification = async (req, res) => {
    try {
        const user = req.user;
        const { id } = req.params;
        if (!mongoose_1.default.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ error: "Invalid notification ID." });
        }
        const notification = await Notification_1.Notification.findById(id);
        if (!notification) {
            return res.status(404).json({ error: "Notification not found." });
        }
        if (notification.sentTo != user._id && user.role !== RolesEnum_1.RolesEnum.ADMIN) {
            return res
                .status(403)
                .json({ error: "You are not authorized to delete this notification." });
        }
        if (user.role === RolesEnum_1.RolesEnum.ADMIN) {
            await notification.deleteOne();
        }
        else {
            notification.deletedAt = new Date();
            notification.isDeleted = true;
            await notification.save();
        }
        return res.json({
            message: "Notification deleted successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while deleting notification");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.deleteNotification = deleteNotification;
//# sourceMappingURL=deleteNotification.js.map