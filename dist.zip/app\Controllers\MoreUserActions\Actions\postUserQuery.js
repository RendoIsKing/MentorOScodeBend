"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postUserQuery = void 0;
const MoreAction_1 = require("../../../Models/MoreAction");
const userActionTypeEnum_1 = require("../../../../types/enums/userActionTypeEnum");
const postUserQuery = async (req, res) => {
    try {
        const user = req.user;
        const { query } = req.body;
        if (!query) {
            return res.status(400).json({ error: { message: "Query is required" } });
        }
        const moreAction = new MoreAction_1.MoreAction({
            actionByUser: user.id,
            query: query,
            actionType: userActionTypeEnum_1.userActionType.USER_QUERY,
        });
        await moreAction.save();
        return res.json({
            data: moreAction,
            message: "Query added successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while posting query");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.postUserQuery = postUserQuery;
//# sourceMappingURL=postUserQuery.js.map