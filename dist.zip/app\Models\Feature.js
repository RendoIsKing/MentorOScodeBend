"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Feature = void 0;
const mongoose_1 = require("mongoose");
const featureSchema_1 = require("../../database/schemas/featureSchema");
const Feature = (0, mongoose_1.model)('Feature', featureSchema_1.FeatureSchema);
exports.Feature = Feature;
//# sourceMappingURL=Feature.js.map