"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setDefaultCardOnStripe = void 0;
const _1 = __importDefault(require("."));
const setDefaultCardOnStripe = async (card) => {
    try {
        // const stripeTipProduct = await stripeInstance.products.create({
        //   name: product.title,
        // });
        // return stripeTipProduct;
        // Set the default payment method for the customer
        await _1.default.customers.update(card.customerId, {
            invoice_settings: {
                default_payment_method: card.paymentMethodId,
            },
        });
    }
    catch (error) {
        console.error(error, "ERROR IN SETTING CARD AS DEFAULT ON STRIPE");
        // return error;
    }
};
exports.setDefaultCardOnStripe = setDefaultCardOnStripe;
//# sourceMappingURL=setDefaultCardOnStripe.js.map