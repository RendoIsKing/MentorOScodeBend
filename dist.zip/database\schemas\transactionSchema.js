"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionSchema = void 0;
const mongoose_1 = require("mongoose");
const transactionStatusEnum_1 = require("../../types/enums/transactionStatusEnum");
const transactionTypeEnum_1 = require("../../types/enums/transactionTypeEnum");
const productEnum_1 = require("../../types/enums/productEnum");
const TransactionSchema = new mongoose_1.Schema({
    userId: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    amount: {
        type: Number,
    },
    title: {
        type: String,
        enum: Object.values(transactionTypeEnum_1.TransactionType),
    },
    currency: {
        type: String,
    },
    stripePaymentIntentId: {
        type: String,
    },
    stripeProductId: {
        type: String,
    },
    productId: {
        type: String,
    },
    status: {
        type: String,
        enum: Object.values(transactionStatusEnum_1.TransactionStatus),
        default: transactionStatusEnum_1.TransactionStatus.PENDING,
    },
    type: {
        type: String,
        // enum:
        enum: [transactionTypeEnum_1.TransactionType.DEBIT, transactionTypeEnum_1.TransactionType.CREDIT],
        // enum: [...Object.values(TransactionType)],
        // default: null,
    },
    productType: {
        type: String,
        enum: [productEnum_1.ProductType.POSTS, productEnum_1.ProductType.SUBSCRIPTION, productEnum_1.ProductType.TIPS]
    }
}, {
    timestamps: true,
});
exports.TransactionSchema = TransactionSchema;
//# sourceMappingURL=transactionSchema.js.map