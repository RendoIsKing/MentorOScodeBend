"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionSchema = void 0;
const mongoose_1 = require("mongoose");
const SubscriptionStatusEnum_1 = require("../../types/enums/SubscriptionStatusEnum");
const SubscriptionSchema = new mongoose_1.Schema({
    userId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "User",
        required: true,
    },
    planId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "SubscriptionPlan",
        required: true,
    },
    StripeSubscriptionId: {
        type: String,
        required: true,
    },
    StripePriceId: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        enum: [
            SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE,
            SubscriptionStatusEnum_1.SubscriptionStatusEnum.INACTIVE,
            SubscriptionStatusEnum_1.SubscriptionStatusEnum.PAUSED,
            SubscriptionStatusEnum_1.SubscriptionStatusEnum.CANCEL,
        ],
    },
    startDate: {
        type: Date,
        // required: true,
    },
    endDate: {
        type: Date,
        // required: true,
    },
    stripeSubscriptionObject: {
        type: String,
    },
}, {
    timestamps: true,
});
exports.SubscriptionSchema = SubscriptionSchema;
//# sourceMappingURL=SubscriptionSchema.js.map