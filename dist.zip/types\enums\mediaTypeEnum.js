"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaType = void 0;
var MediaType;
(function (MediaType) {
    MediaType["IMAGE"] = "image";
    MediaType["VIDEO"] = "video";
    MediaType["LIVE"] = "live";
    MediaType["STORY"] = "story";
})(MediaType || (exports.MediaType = MediaType = {}));
//# sourceMappingURL=mediaTypeEnum.js.map