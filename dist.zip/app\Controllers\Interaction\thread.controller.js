"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clearThread = exports.appendMessage = exports.getThread = void 0;
const mongoose_1 = require("mongoose");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const ChatModels_1 = require("../../Models/ChatModels");
function resolveUserId(req) {
    var _a, _b, _c, _d;
    if ((_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id)
        return String(req.user._id);
    if ((_b = req === null || req === void 0 ? void 0 : req.body) === null || _b === void 0 ? void 0 : _b.userId)
        return String(req.body.userId);
    if ((_c = req === null || req === void 0 ? void 0 : req.query) === null || _c === void 0 ? void 0 : _c.userId)
        return String(req.query.userId);
    const cookie = (_d = req.headers) === null || _d === void 0 ? void 0 : _d.cookie;
    const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
    if (!match)
        return undefined;
    try {
        const token = decodeURIComponent(match[1]);
        const secret = process.env.JWT_SECRET || 'secret_secret';
        const decoded = jsonwebtoken_1.default.verify(token, secret);
        return (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
    }
    catch {
        return undefined;
    }
}
const getThread = async (req, res) => {
    var _a;
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const partner = ((_a = req.params) === null || _a === void 0 ? void 0 : _a.partner) || 'coach-engh';
        const thread = await ChatModels_1.ChatThread.findOneAndUpdate({ userId, partner }, { $setOnInsert: { userId: new mongoose_1.Types.ObjectId(userId), partner } }, { upsert: true, new: true });
        const msgs = await ChatModels_1.ChatMessage.find({ threadId: thread._id }).sort({ createdAt: 1 }).lean();
        return res.json({ threadId: thread._id, messages: msgs });
    }
    catch (e) {
        return res.status(500).json({ message: 'thread fetch failed' });
    }
};
exports.getThread = getThread;
const appendMessage = async (req, res) => {
    var _a;
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const partner = ((_a = req.params) === null || _a === void 0 ? void 0 : _a.partner) || 'coach-engh';
        const { sender, text } = req.body || {};
        if (!sender || !text)
            return res.status(400).json({ message: 'sender and text required' });
        const thread = await ChatModels_1.ChatThread.findOneAndUpdate({ userId, partner }, { $setOnInsert: { userId: new mongoose_1.Types.ObjectId(userId), partner } }, { upsert: true, new: true });
        const msg = await ChatModels_1.ChatMessage.create({ threadId: thread._id, sender, text });
        return res.json({ data: msg });
    }
    catch (e) {
        return res.status(500).json({ message: 'append failed' });
    }
};
exports.appendMessage = appendMessage;
const clearThread = async (req, res) => {
    var _a;
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const partner = ((_a = req.params) === null || _a === void 0 ? void 0 : _a.partner) || 'coach-engh';
        const thread = await ChatModels_1.ChatThread.findOne({ userId, partner });
        if (thread) {
            await ChatModels_1.ChatMessage.deleteMany({ threadId: thread._id });
        }
        return res.json({ ok: true });
    }
    catch (e) {
        return res.status(500).json({ message: 'clear failed' });
    }
};
exports.clearThread = clearThread;
//# sourceMappingURL=thread.controller.js.map