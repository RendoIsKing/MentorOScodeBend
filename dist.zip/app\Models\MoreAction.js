"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MoreAction = void 0;
const mongoose_1 = require("mongoose");
const MoreActionsSchema_1 = require("../../database/schemas/MoreActionsSchema");
const MoreAction = (0, mongoose_1.model)("MoreAction", MoreActionsSchema_1.MoreActionSchema);
exports.MoreAction = MoreAction;
//# sourceMappingURL=MoreAction.js.map