"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirebaseNotificationEnum = void 0;
var FirebaseNotificationEnum;
(function (FirebaseNotificationEnum) {
    FirebaseNotificationEnum["FOLLOW"] = "follow";
    FirebaseNotificationEnum["LIKE_POST"] = "like_post";
    FirebaseNotificationEnum["LIKE_STORY"] = "like_story";
    FirebaseNotificationEnum["COMMENT"] = "comment";
    FirebaseNotificationEnum["LIKE_COMMENT"] = "like_comment";
})(FirebaseNotificationEnum || (exports.FirebaseNotificationEnum = FirebaseNotificationEnum = {}));
//# sourceMappingURL=FirebaseNotificationEnum.js.map