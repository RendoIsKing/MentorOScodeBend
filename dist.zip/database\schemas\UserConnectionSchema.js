"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserConnectionSchema = void 0;
const mongoose_1 = require("mongoose");
const UserConnectionSchema = new mongoose_1.Schema({
    owner: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
        //   required: true
    },
    followingTo: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
        //   required: true,
    },
}, {
    timestamps: true,
});
exports.UserConnectionSchema = UserConnectionSchema;
//# sourceMappingURL=UserConnectionSchema.js.map