"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateUserReport = void 0;
const MoreAction_1 = require("../../../Models/MoreAction");
const userActionTypeEnum_1 = require("../../../../types/enums/userActionTypeEnum");
const mongoose_1 = __importDefault(require("mongoose"));
const updateUserReport = async (req, res) => {
    try {
        const { id } = req.params;
        const { reportStatus } = req.body;
        if (!reportStatus) {
            return res
                .status(400)
                .json({ error: { message: "Report status is required." } });
        }
        if (!mongoose_1.default.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ error: { message: "Invalid ID format." } });
        }
        const updatedDocument = await MoreAction_1.MoreAction.findOneAndUpdate({
            _id: id,
            actionType: userActionTypeEnum_1.userActionType.REPORT,
        }, {
            reportStatus: reportStatus,
        }, {
            new: true,
        });
        if (!updatedDocument) {
            return res
                .status(404)
                .json({ error: { message: "Document not found." } });
        }
        return res.status(200).json({
            data: updatedDocument,
            message: "Report status updated successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while updating user report");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.updateUserReport = updateUserReport;
//# sourceMappingURL=updateUserReport.js.map