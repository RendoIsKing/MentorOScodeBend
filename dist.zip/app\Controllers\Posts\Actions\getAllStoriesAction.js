"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllStoriesActions = exports.twentyFourHoursAgo = void 0;
const class_transformer_1 = require("class-transformer");
const getPost_input_1 = require("../Inputs/getPost.input");
const class_validator_1 = require("class-validator");
const Post_1 = require("../../../Models/Post");
const commonPagination_1 = require("../../../../utils/pipeline/commonPagination");
const postTypeEnum_1 = require("../../../../types/enums/postTypeEnum");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
exports.twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
const getAllStoriesActions = async (req, res) => {
    var _a, _b, _c, _d, _e;
    try {
        const user = req.user;
        const postQuery = (0, class_transformer_1.plainToClass)(getPost_input_1.GetAllItemsInputs, req.query);
        const errors = await (0, class_validator_1.validate)(postQuery);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        const { perPage, page } = postQuery;
        let skip = (page > 0 ? page - 1 : 0) * perPage;
        const posts = await Post_1.Post.aggregate([
            // {
            //   $match: {
            //     user: user._id,
            //   },
            // },
            // {
            //   $unwind: "$media",
            // },
            {
                $match: {
                    type: postTypeEnum_1.PostType.STORY,
                    createdAt: { $gte: exports.twentyFourHoursAgo },
                    deletedAt: null,
                    isDeleted: false,
                },
            },
            {
                $lookup: {
                    from: "userconnections",
                    let: { userId: "$user" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$owner", user._id] },
                                        { $eq: ["$followingTo", "$$userId"] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "connections",
                },
            },
            {
                $match: {
                    "connections.0": { $exists: true },
                },
            },
            {
                $lookup: {
                    from: "files",
                    localField: "media.mediaId",
                    foreignField: "_id",
                    as: "mediaFiles",
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "user",
                    foreignField: "_id",
                    as: "userInfo",
                },
            },
            {
                $unwind: "$userInfo",
            },
            {
                $lookup: {
                    from: "files",
                    localField: "userInfo.photoId",
                    foreignField: "_id",
                    as: "userInfo.photo",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id", userId: user === null || user === void 0 ? void 0 : user._id },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$interactedBy", "$$userId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.LIKE_STORY] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "likeInteractions", //for isLiked key
                },
            },
            {
                $addFields: {
                    isLiked: { $gt: [{ $size: "$likeInteractions" }, 0] },
                },
            },
            // {
            //   $lookup: {
            //     from: "interactions",
            //     let: { postId: "$_id" },
            //     pipeline: [
            //       {
            //         $match: {
            //           $expr: {
            //             $and: [
            //               { $eq: ["$post", "$$postId"] },
            //               { $eq: ["$user", new Types.ObjectId(user._id)] },
            //               { $eq: ["$type", InteractionType.LIKE_STORY] },
            //             ],
            //           },
            //         },
            //       },
            //     ],
            //     as: "likes",
            //   },
            // },
            // {
            //   $addFields: {
            //     isLiked: { $gt: [{ $size: "$likes" }, 0] },
            //   },
            // },
            {
                $group: {
                    _id: "$user",
                    userInfo: { $first: "$userInfo" },
                    stories: {
                        $push: {
                            _id: "$_id",
                            media: "$media",
                            content: "$content",
                            isActive: "$isActive",
                            isDeleted: "$isDeleted",
                            type: "$type",
                            createdAt: "$createdAt",
                            updatedAt: "$updatedAt",
                            mediaFiles: "$mediaFiles",
                            isLiked: "$isLiked",
                        },
                    },
                },
            },
            {
                $project: {
                    _id: 0,
                    userInfo: {
                        $mergeObjects: ["$userInfo", { stories: "$stories" }],
                    },
                },
            },
            ...(0, commonPagination_1.commonPaginationPipeline)(page, perPage, skip),
        ]);
        let data = {
            data: (_b = (_a = posts[0]) === null || _a === void 0 ? void 0 : _a.data) !== null && _b !== void 0 ? _b : [],
            meta: (_e = (_d = (_c = posts[0]) === null || _c === void 0 ? void 0 : _c.metaData) === null || _d === void 0 ? void 0 : _d[0]) !== null && _e !== void 0 ? _e : {},
        };
        return res.json(data);
    }
    catch (err) {
        console.log("Error while getting stories", err);
        return res
            .status(500)
            .json({ error: { message: "Something went wrong.", err } });
    }
};
exports.getAllStoriesActions = getAllStoriesActions;
//# sourceMappingURL=getAllStoriesAction.js.map