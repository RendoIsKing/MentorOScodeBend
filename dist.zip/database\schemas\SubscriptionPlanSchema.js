"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionPlanSchema = void 0;
const mongoose_1 = require("mongoose");
const subscriptionPlanEnum_1 = require("../../types/enums/subscriptionPlanEnum");
const featureSchema_1 = require("./featureSchema");
// const PermissionSchema = new Schema({
//   feature: { type: String, required: true },
//   isAvailable: { type: Boolean, required: true },
// });
const SubscriptionPlanSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: false,
    },
    description: {
        type: String,
        required: false,
    },
    price: {
        type: Number,
        required: false,
    },
    duration: {
        type: Number,
        required: false,
    },
    stripeProductId: {
        type: String,
        required: false,
    },
    stripeProductFeatureIds: {
        type: [String],
        required: false,
    },
    featureIds: {
        type: [mongoose_1.Types.ObjectId],
        // required: false,
        // ref: "Feature",
    },
    stripeProductObject: {
        type: {},
        required: false,
    },
    planType: {
        type: String,
        enum: [
            subscriptionPlanEnum_1.SubscriptionPlanType.BASIC_FREE,
            subscriptionPlanEnum_1.SubscriptionPlanType.FIXED,
            subscriptionPlanEnum_1.SubscriptionPlanType.CUSTOM,
        ],
    },
    userId: {
        type: mongoose_1.Types.ObjectId,
        required: true,
        ref: "User",
    },
    permissions: { type: [featureSchema_1.FeatureSchema], required: false },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: {
        type: Date,
        default: null,
    },
}, { timestamps: true });
exports.SubscriptionPlanSchema = SubscriptionPlanSchema;
//# sourceMappingURL=SubscriptionPlanSchema.js.map