"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listAllCardsOfUser = void 0;
const CardDetails_1 = require("../../../Models/CardDetails");
const listAllCardsOfUser = async (req, res) => {
    try {
        const user = req.user;
        if (!user) {
            return res.status(404).json({ error: { message: "User not found." } });
        }
        const cards = await CardDetails_1.cardDetails.aggregate([
            {
                $match: {
                    userId: user._id,
                    isDeleted: false,
                    deletedAt: null,
                },
            },
            {
                $project: {
                    _id: 1,
                    brand: 1,
                    isDefault: 1,
                    last4: 1,
                    exp_month: 1,
                    exp_year: 1,
                },
            },
        ]);
        return res.json({ data: cards });
    }
    catch (error) {
        console.error(error, "Error in listing cards of user");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.listAllCardsOfUser = listAllCardsOfUser;
//# sourceMappingURL=listCardOfUser.js.map