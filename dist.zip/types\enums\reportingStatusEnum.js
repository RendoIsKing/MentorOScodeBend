"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportStatusEnum = void 0;
var ReportStatusEnum;
(function (ReportStatusEnum) {
    ReportStatusEnum["PENDING"] = "pending";
    ReportStatusEnum["APPROVED"] = "approved";
    ReportStatusEnum["CANCEL"] = "cancel";
})(ReportStatusEnum || (exports.ReportStatusEnum = ReportStatusEnum = {}));
//# sourceMappingURL=reportingStatusEnum.js.map