"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.nextTrainingVersion = nextTrainingVersion;
exports.nextNutritionVersion = nextNutritionVersion;
const TrainingPlanVersion_1 = __importDefault(require("../../models/TrainingPlanVersion"));
const NutritionPlanVersion_1 = __importDefault(require("../../models/NutritionPlanVersion"));
async function nextTrainingVersion(user) {
    var _a;
    const last = await TrainingPlanVersion_1.default.findOne({ user }).sort({ version: -1 });
    return ((_a = last === null || last === void 0 ? void 0 : last.version) !== null && _a !== void 0 ? _a : 0) + 1;
}
async function nextNutritionVersion(user) {
    var _a;
    const last = await NutritionPlanVersion_1.default.findOne({ user }).sort({ version: -1 });
    return ((_a = last === null || last === void 0 ? void 0 : last.version) !== null && _a !== void 0 ? _a : 0) + 1;
}
//# sourceMappingURL=nextVersion.js.map