"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNotifications = void 0;
const Notification_1 = require("../../../Models/Notification");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const commonPagination_1 = require("../../../../utils/pipeline/commonPagination");
const getPost_input_1 = require("../../Posts/Inputs/getPost.input");
const getNotifications = async (req, res) => {
    var _a, _b, _c, _d, _e;
    try {
        const user = req.user;
        const notificationQuery = (0, class_transformer_1.plainToClass)(getPost_input_1.GetAllItemsInputs, req.query);
        const errors = await (0, class_validator_1.validate)(notificationQuery);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        const { perPage, page } = notificationQuery;
        let skip = (page > 0 ? page - 1 : 0) * perPage;
        const notifications = await Notification_1.Notification.aggregate([
            { $match: { sentTo: user._id } },
            {
                $sort: { createdAt: -1 },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "sentTo",
                    foreignField: "_id",
                    as: "sentToUserDetails",
                },
            },
            {
                $lookup: {
                    from: "posts",
                    localField: "notificationOnPost",
                    foreignField: "_id",
                    as: "postDetails",
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "notificationFromUser",
                    foreignField: "_id",
                    as: "notificationFromUserDetails",
                },
            },
            {
                $project: {
                    title: 1,
                    description: 1,
                    sentTo: {
                        $map: {
                            input: "$sentToUserDetails",
                            as: "user",
                            in: {
                                _id: "$$user._id",
                                userName: "$$user.userName",
                            },
                        },
                    },
                    notificationOnPost: {
                        $arrayElemAt: ["$postDetails._id", 0],
                    },
                    notificationFromUserDetails: {
                        $arrayElemAt: ["$notificationFromUserDetails.userName", 0],
                    },
                    readAt: 1,
                    type: 1,
                    isDeleted: 1,
                    deletedAt: 1,
                    createdAt: 1,
                    updatedAt: 1,
                },
            },
            ...(0, commonPagination_1.commonPaginationPipeline)(page, perPage, skip),
        ]);
        let data = {
            data: (_b = (_a = notifications[0]) === null || _a === void 0 ? void 0 : _a.data) !== null && _b !== void 0 ? _b : [],
            meta: (_e = (_d = (_c = notifications[0]) === null || _c === void 0 ? void 0 : _c.metaData) === null || _d === void 0 ? void 0 : _d[0]) !== null && _e !== void 0 ? _e : {},
        };
        return res.json(data);
    }
    catch (err) {
        console.error(err, "Error while retrieving notifications");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.getNotifications = getNotifications;
//# sourceMappingURL=getNotification.js.map