"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.savePostAction = void 0;
const Post_1 = require("../../../Models/Post");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const Interaction_1 = require("../../../Models/Interaction");
const savePostAction = async (req, res) => {
    try {
        const user = req.user;
        const postId = req.params.id;
        const postExists = (await Post_1.Post.findById(postId));
        if (!postExists || (postExists === null || postExists === void 0 ? void 0 : postExists.isDeleted)) {
            return res.status(400).json({ error: { message: "Post not exist" } });
        }
        const saveIntereactionExist = await Interaction_1.Interaction.findOne({
            user: postExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED,
            post: postId,
            collectionId: { $in: [user.primaryCollection] },
        });
        if (saveIntereactionExist) {
            await Interaction_1.Interaction.deleteOne({ _id: saveIntereactionExist.id });
            return res.json({
                data: {
                    message: "Saved post removed",
                },
            });
        }
        const savedInteraction = await Interaction_1.Interaction.create({
            user: postExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED,
            post: postId,
            collectionId: [user.primaryCollection],
        });
        return res.json({
            data: savedInteraction,
            message: "Interaction saved .",
        });
    }
    catch (err) {
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.savePostAction = savePostAction;
//# sourceMappingURL=savePostAction.js.map