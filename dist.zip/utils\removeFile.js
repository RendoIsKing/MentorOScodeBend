"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteFile = DeleteFile;
const fs = require("fs");
const FileEnum_1 = require("../types/FileEnum");
// @ts-ignore
const path_1 = __importDefault(require("path"));
function DeleteFile(filePath) {
    try {
        if (fs.existsSync(path_1.default.join(`${process.cwd()}${FileEnum_1.FileEnum.PUBLICDIR}${filePath}`))) {
            fs.unlinkSync(path_1.default.join(`${process.cwd()}${FileEnum_1.FileEnum.PUBLICDIR}${filePath}`));
            return true;
        }
        else {
            return true;
        }
    }
    catch (err) {
        console.error(err, "Error while removing file");
        return false;
    }
}
//# sourceMappingURL=removeFile.js.map