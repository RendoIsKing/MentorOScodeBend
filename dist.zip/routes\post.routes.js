"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Posts_1 = require("../app/Controllers/Posts");
const Middlewares_1 = require("../app/Middlewares");
const rateLimiters_1 = require("../app/Middlewares/rateLimiters");
const ModerationReport_1 = __importDefault(require("../models/ModerationReport"));
const zod_1 = require("zod");
const PostRoutes = (0, express_1.Router)();
PostRoutes.get("/test", Posts_1.PostsController.getFirstPost);
// Read endpoints require auth to compute personalized fields
PostRoutes.get("/story", Middlewares_1.Auth, Posts_1.PostsController.getAllStoriesActions);
PostRoutes.get("/user-story", Middlewares_1.Auth, Posts_1.PostsController.getStoriesOfUserByUserName);
PostRoutes.get("/users", Middlewares_1.Auth, Posts_1.PostsController.getPostsOfUserByUserName);
// Canonical plural route to match FE env
PostRoutes.post("/posts", Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 12 }), Posts_1.PostsController.createPost);
// Deprecated singular route (temporary)
PostRoutes.post("/", Middlewares_1.Auth, (req, res, next) => { try {
    console.warn('[DEPRECATION] POST /api/backend/v1/post/ is deprecated; use /api/backend/v1/post/posts');
}
catch { } ; return Posts_1.PostsController.createPost(req, res); });
PostRoutes.post("/:id", Middlewares_1.Auth, Posts_1.PostsController.updatePost);
PostRoutes.delete("/:id", Middlewares_1.Auth, Posts_1.PostsController.deletePost);
PostRoutes.get("/", Middlewares_1.Auth, Posts_1.PostsController.getAllPosts);
PostRoutes.get("/:id", Middlewares_1.Auth, Posts_1.PostsController.getPostById);
PostRoutes.get("/tagged/:id", Middlewares_1.Auth, Posts_1.PostsController.getTaggedUsers);
// Basic moderation: report a post (idempotent per (post, reporter))
PostRoutes.post('/:id/report', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 12 }), async (req, res) => {
    var _a, _b;
    try {
        const { id } = req.params;
        const schema = zod_1.z.object({ reason: zod_1.z.string().trim().min(1).max(500) });
        const parsed = schema.safeParse({ reason: (_a = req.body) === null || _a === void 0 ? void 0 : _a.reason });
        if (!parsed.success)
            return res.status(422).json({ error: 'validation_failed', details: parsed.error.flatten() });
        const reason = parsed.data.reason;
        // @ts-ignore
        const reporter = (_b = req.user) === null || _b === void 0 ? void 0 : _b._id;
        await ModerationReport_1.default.updateOne({ post: id, reporter }, { $setOnInsert: { post: id, reporter }, $set: { reason, status: 'open' } }, { upsert: true });
        return res.json({ ok: true });
    }
    catch (e) {
        return res.status(500).json({ error: { message: 'report failed' } });
    }
});
// Minimal admin endpoints for moderation queue
PostRoutes.get('/moderation/reports', Middlewares_1.OnlyAdmins, async (req, res) => {
    try {
        const { status, cursor } = req.query;
        const filter = {};
        if (status && ['open', 'resolved'].includes(String(status)))
            filter.status = String(status);
        if (cursor)
            filter._id = { $lt: cursor };
        const items = await ModerationReport_1.default.find(filter).sort({ _id: -1 }).limit(50).lean();
        const nextCursor = items.length ? String(items[items.length - 1]._id) : null;
        return res.json({ items: items.map((it) => ({ id: String(it._id), post: String(it.post), reporter: String(it.reporter), reason: it.reason, status: it.status, createdAt: it.createdAt })), nextCursor });
    }
    catch {
        return res.status(500).json({ error: { message: 'list failed' } });
    }
});
PostRoutes.post('/moderation/reports/:id/resolve', Middlewares_1.OnlyAdmins, async (req, res) => {
    try {
        const { id } = req.params;
        // const { action, notes } = (req.body || {}) as any; // reserved for future moderation actions
        await ModerationReport_1.default.updateOne({ _id: id }, { $set: { status: 'resolved' } });
        // Optional: if action === 'remove', you could hide the post here.
        return res.json({ ok: true });
    }
    catch {
        return res.status(500).json({ error: { message: 'resolve failed' } });
    }
});
exports.default = PostRoutes;
//# sourceMappingURL=post.routes.js.map