"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Connections_1 = require("../app/Controllers/Connections");
const ConnectionRoutes = (0, express_1.Router)();
ConnectionRoutes.post("/follow", Middlewares_1.Auth, Connections_1.ConnectionController.toggleFollow);
exports.default = ConnectionRoutes;
//# sourceMappingURL=connection.routes.js.map