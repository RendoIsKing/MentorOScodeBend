"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const passport_local_1 = require("passport-local");
const bcryptjs_1 = require("bcryptjs");
const User_1 = require("../../app/Models/User");
const options = {
    usernameField: "email",
    passwordField: "password",
    session: false,
};
exports.default = new passport_local_1.Strategy(options, async (email, password, done) => {
    try {
        const user = await User_1.User.findOne({ email });
        if (!user) {
            return done(null, false, { message: "Login credentials error" });
        }
        if (!(0, bcryptjs_1.compareSync)(password, user.password)) {
            return done(null, false, { message: "Login credentials error" });
        }
        user.lastLogin = new Date(Date.now());
        await user.save();
        return done(null, user, { message: "User found" });
    }
    catch (e) {
        return done(null, false, { message: e });
    }
});
//# sourceMappingURL=local.js.map