"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserQueries = void 0;
const MoreAction_1 = require("../../../Models/MoreAction");
const userActionTypeEnum_1 = require("../../../../types/enums/userActionTypeEnum");
const getUserQueries = async (req, res) => {
    try {
        const queries = await MoreAction_1.MoreAction.find({
            actionType: {
                $in: [userActionTypeEnum_1.userActionType.USER_QUERY, userActionTypeEnum_1.userActionType.REPORT],
            },
        })
            .populate({
            path: "actionByUser",
            select: "userName",
        })
            .populate({
            path: "actionToUser",
            select: "userName",
        })
            .exec();
        const customQueries = queries.map((query) => ({
            ...query.toObject(),
            actionToUser: query.actionToUser || {},
        }));
        return res.status(200).json({
            data: customQueries,
            message: "User queries fetched successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while fetching user queries");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.getUserQueries = getUserQueries;
//# sourceMappingURL=getAllUserQuery.js.map