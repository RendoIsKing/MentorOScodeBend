"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeatureController = void 0;
// import { addFeatureToProduct } from "./Actions/associateFeatureToProduct";
const getFeaturesAction_1 = require("./Actions/getFeaturesAction");
const createFeatureAction_1 = require("./Actions/createFeatureAction");
class FeatureController {
    static createFeature(req, res) {
        (0, createFeatureAction_1.createFeature)(req, res);
    }
    //   static addFeatureToProduct(req:Request, res: Response) {
    //     addFeatureToProduct(req, res);
    //   }
    static getAllFeaturesActions(req, res) {
        (0, getFeaturesAction_1.getAllFeaturesActions)(req, res);
    }
}
exports.FeatureController = FeatureController;
//# sourceMappingURL=index.js.map