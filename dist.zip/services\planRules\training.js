"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.patchSetDaysPerWeek = patchSetDaysPerWeek;
exports.patchSwapExercise = patchSwapExercise;
exports.patchProgression = patchProgression;
exports.patchDeload = patchDeload;
exports.applyInjurySubstitutions = applyInjurySubstitutions;
const safety_1 = require("./safety");
const injurySwap = {
    knee: { "Back Squat": "Leg Press", "Lunge": "Step-ups" },
};
function nearestValidDay(requested, planDays) {
    var _a, _b, _c;
    const idx = planDays.findIndex(d => d.day === requested);
    if (idx >= 0)
        return requested;
    const cand = planDays.find(d => { var _a; return (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.length; });
    return (_c = (_a = cand === null || cand === void 0 ? void 0 : cand.day) !== null && _a !== void 0 ? _a : (_b = planDays[0]) === null || _b === void 0 ? void 0 : _b.day) !== null && _c !== void 0 ? _c : requested;
}
function patchSetDaysPerWeek(current, daysPerWeek) {
    const swaps = [];
    const reason = {
        summary: `Satt treningsfrekvens til ${daysPerWeek}/uke`,
        bullets: ["Beholdt eksisterende økter, ryddet øvrige dager til hvile/mobilitet"],
    };
    return { targetDaysPerWeek: daysPerWeek, swaps, reason };
}
function patchSwapExercise(current, day, from, to) {
    const targetDay = nearestValidDay(day, current);
    const reason = {
        summary: `Byttet ${from} → ${to} på ${targetDay}`,
        bullets: ["Skade-/preferansevennlig bytte", "Uten endring i totalvolum"],
    };
    return { swaps: [{ day: targetDay, from, to }], reason };
}
function patchProgression(current) {
    const volumeTweaks = current
        .filter(d => { var _a; return (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.length; })
        .map(d => {
        const main = d.exercises[0];
        const maxAdd = Math.max(1, Math.floor((main.sets || 3) * safety_1.MAX_SET_JUMP_PCT));
        return { day: d.day, name: main.name, deltaSets: Math.min(1, maxAdd) };
    });
    const reason = { summary: "Liten, kontrollert progresjon", bullets: ["≤20% volumøkning på hovedløft"] };
    return { volumeTweaks, reason };
}
function patchDeload(current) {
    const volumeTweaks = [];
    const intensityTweaks = [];
    current.forEach(d => {
        var _a;
        return (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.forEach(e => {
            const reduce = Math.max(1, Math.round((e.sets || 3) * 0.3));
            volumeTweaks.push({ day: d.day, name: e.name, deltaSets: -reduce });
            if (e.rpe) {
                const num = Number(String(e.rpe).replace(/[^\d]/g, "")) || 7;
                intensityTweaks.push({ day: d.day, name: e.name, newRpe: `RPE ${Math.max(5, num - 1)}` });
            }
        });
    });
    const reason = { summary: "Deload uke", bullets: ["~30% lavere volum", "RPE -1 for restitusjon"] };
    return { deload: true, volumeTweaks, intensityTweaks, reason };
}
function applyInjurySubstitutions(days, injuries) {
    const swaps = [];
    if (!(injuries === null || injuries === void 0 ? void 0 : injuries.length))
        return null;
    days.forEach(d => {
        var _a;
        return (_a = d.exercises) === null || _a === void 0 ? void 0 : _a.forEach(e => {
            injuries.forEach(inj => {
                const map = injurySwap[inj];
                const to = map === null || map === void 0 ? void 0 : map[e.name];
                if (to)
                    swaps.push({ day: d.day, from: e.name, to });
            });
        });
    });
    if (!swaps.length)
        return null;
    return { swaps, reason: { summary: "Skadejustering", bullets: ["Byttet øvelser til mer skånsomme alternativer"] } };
}
//# sourceMappingURL=training.js.map