"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangeLogSchema = void 0;
const mongoose_1 = require("mongoose");
exports.ChangeLogSchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    area: { type: String, enum: ['training', 'nutrition', 'goal'], required: true },
    summary: String,
    reason: String,
    fromVersion: Number,
    toVersion: Number,
}, { timestamps: { createdAt: true, updatedAt: false } });
exports.ChangeLogSchema.index({ userId: 1, createdAt: -1 });
//# sourceMappingURL=ChangeLogSchema.js.map