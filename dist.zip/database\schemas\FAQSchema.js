"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FAQSchema = void 0;
const mongoose_1 = require("mongoose");
const ContentSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: true,
    },
    subContent: {
        type: [String],
        required: true,
    },
});
const TopicSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: true,
    },
    content: {
        type: [ContentSchema],
        required: true,
    },
});
const FAQSchema = new mongoose_1.Schema({
    topics: {
        type: [TopicSchema],
        required: true,
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: {
        type: Date,
        default: null,
    },
}, { timestamps: true });
exports.FAQSchema = FAQSchema;
//# sourceMappingURL=FAQSchema.js.map