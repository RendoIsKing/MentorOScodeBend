"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentStatusEnum = void 0;
var DocumentStatusEnum;
(function (DocumentStatusEnum) {
    DocumentStatusEnum["Pending"] = "pending";
    DocumentStatusEnum["Approved"] = "approved";
    DocumentStatusEnum["Rejected"] = "rejected";
})(DocumentStatusEnum || (exports.DocumentStatusEnum = DocumentStatusEnum = {}));
//# sourceMappingURL=DocumentStatusEnum.js.map