"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSubscriptionPlan = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const subscriptionPlanInput_1 = require("../Inputs/subscriptionPlanInput");
const subscriptionPlanEnum_1 = require("../../../../types/enums/subscriptionPlanEnum");
const updateSubscriptionPlan = async (req, res) => {
    try {
        const user = req.user;
        const planId = req.params.id;
        const subscriptionPlanInput = (0, class_transformer_1.plainToClass)(subscriptionPlanInput_1.SubscriptionPlanInput, req.body);
        const validationErrors = await (0, class_validator_1.validate)(subscriptionPlanInput, {
            skipMissingProperties: true,
        });
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        const subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.findById(planId);
        if (!subscriptionPlan) {
            return res
                .status(404)
                .json({ error: { message: "Subscription plan not found." } });
        }
        if (subscriptionPlan.userId.toString() !== user.id) {
            return res
                .status(403)
                .json({
                error: {
                    message: "You do not have permission to update this subscription plan.",
                },
            });
        }
        //@ts-ignore
        let subscriptionPlanToUpdate;
        if (subscriptionPlanInput.planType === subscriptionPlanEnum_1.SubscriptionPlanType.FIXED) {
            subscriptionPlanToUpdate = await SubscriptionPlan_1.SubscriptionPlan.findOne({
                userId: user.id,
                planType: subscriptionPlanEnum_1.SubscriptionPlanType.FIXED,
                isDeleted: false,
            });
            if (subscriptionPlan) {
                subscriptionPlanToUpdate = await SubscriptionPlan_1.SubscriptionPlan.findByIdAndUpdate(subscriptionPlan._id, { ...subscriptionPlanInput }, { new: true });
            }
            else {
                subscriptionPlanToUpdate = await SubscriptionPlan_1.SubscriptionPlan.create({
                    ...subscriptionPlanInput,
                    userId: user.id,
                });
            }
            return res.json({
                data: subscriptionPlan,
                message: "Fixed Plan updated successfully.",
            });
        }
        Object.assign(subscriptionPlan, subscriptionPlanInput);
        await subscriptionPlan.save();
        return res.json({
            data: subscriptionPlan,
            message: "Plan updated successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error while updating plan");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.updateSubscriptionPlan = updateSubscriptionPlan;
//# sourceMappingURL=updateSubscriptionPlanAction.js.map