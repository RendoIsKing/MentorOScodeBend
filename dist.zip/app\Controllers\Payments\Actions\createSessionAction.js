"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSessionAction = void 0;
const createPaymentIntent_1 = __importDefault(require("./createPaymentIntent"));
const stripe_1 = __importDefault(require("../../../../utils/stripe"));
const Sentry = __importStar(require("@sentry/node"));
const User_1 = require("../../../Models/User");
const createSessionAction = async (req, res) => {
    var _a, _b, _c, _d;
    const tx = process.env.SENTRY_DSN ? (_a = Sentry === null || Sentry === void 0 ? void 0 : Sentry.startTransaction) === null || _a === void 0 ? void 0 : _a.call(Sentry, { name: 'payments.create-session' }) : undefined;
    try {
        const user = req.user;
        const idempotencyKey = req.headers['idempotency-key'] || undefined;
        let data = {
            amount: 0,
            userId: user.id,
            clientStripeId: user.stripeClientId,
            idempotencyKey,
        };
        if (!user.stripeClientId) {
            const customer = await stripe_1.default.customers.create({
                email: user.email,
                name: user.fullName,
            });
            user.stripeClientId = customer.id;
            await User_1.User.findByIdAndUpdate(user.id, {
                stripeClientId: customer.id,
                isStripeCustomer: true,
            });
            data.clientStripeId = customer.id;
        }
        const response = await (0, createPaymentIntent_1.default)(data);
        const sessionObject = {
            clientSecret: (_b = response === null || response === void 0 ? void 0 : response.client_secret) !== null && _b !== void 0 ? _b : null,
            status: (_c = response === null || response === void 0 ? void 0 : response.status) !== null && _c !== void 0 ? _c : null,
            sessionId: (_d = response === null || response === void 0 ? void 0 : response.id) !== null && _d !== void 0 ? _d : null,
            type: (response === null || response === void 0 ? void 0 : response.object) || 'setup_intent',
        };
        try {
            Sentry.addBreadcrumb({ category: 'stripe', message: 'create-session', level: 'info', data: { status: sessionObject.status } });
        }
        catch { }
        return res.json({ data: sessionObject });
    }
    catch (error) {
        return res.status(500).json({
            error: {
                message: "Something went wrong.",
            },
        });
    }
    finally {
        try {
            tx === null || tx === void 0 ? void 0 : tx.finish();
        }
        catch { }
    }
};
exports.createSessionAction = createSessionAction;
//# sourceMappingURL=createSessionAction.js.map