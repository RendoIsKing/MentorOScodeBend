"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.perUserIpLimiter = perUserIpLimiter;
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
function perUserIpLimiter(options) {
    var _a, _b, _c, _d;
    const windowMs = (_a = options === null || options === void 0 ? void 0 : options.windowMs) !== null && _a !== void 0 ? _a : 60000;
    const max = (_b = options === null || options === void 0 ? void 0 : options.max) !== null && _b !== void 0 ? _b : 60;
    return (0, express_rate_limit_1.default)({
        windowMs,
        max,
        standardHeaders: (_c = options === null || options === void 0 ? void 0 : options.standardHeaders) !== null && _c !== void 0 ? _c : true,
        legacyHeaders: (_d = options === null || options === void 0 ? void 0 : options.legacyHeaders) !== null && _d !== void 0 ? _d : false,
        keyGenerator: (req) => {
            var _a;
            // Use express-rate-limit's ipv6-safe helper when available
            let ipKey = '';
            try {
                // eslint-disable-next-line @typescript-eslint/no-var-requires
                const { ipKeyGenerator } = require('express-rate-limit');
                if (typeof ipKeyGenerator === 'function') {
                    ipKey = String(ipKeyGenerator(req));
                }
            }
            catch { }
            if (!ipKey) {
                // Fallback: rely on library's ipv6 validation by returning empty -> it will use internal ip extractor
                ipKey = '';
            }
            const uid = ((_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id) ? String(req.user._id) : '';
            return `${uid}::${ipKey}`;
        },
    });
}
//# sourceMappingURL=rateLimiters.js.map