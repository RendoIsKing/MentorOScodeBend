"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InteractionController = void 0;
const likePost_action_1 = require("./Actions/likePost.action");
const commentPost_action_1 = require("./Actions/commentPost.action");
const deleteCommentAction_1 = require("./Actions/deleteCommentAction");
const savePostAction_1 = require("./Actions/savePostAction");
const nestedCommentAction_1 = require("./Actions/nestedCommentAction");
const getAllCommentsAction_1 = require("./Actions/getAllCommentsAction");
const likeACommentAction_1 = require("./Actions/likeACommentAction");
const likeStoryAction_1 = require("./Actions/likeStoryAction");
const createImpressionAction_1 = require("./Actions/createImpressionAction");
const logViewAction_1 = require("./Actions/logViewAction");
class InteractionController {
    static toggleLike(req, res) {
        (0, likePost_action_1.toggleLikeAction)(req, res);
    }
    static postComment(req, res) {
        (0, commentPost_action_1.commentAction)(req, res);
    }
    static softDeleteComment(req, res) {
        (0, deleteCommentAction_1.softDeleteComment)(req, res);
    }
    static togglePost(req, res) {
        (0, savePostAction_1.savePostAction)(req, res);
    }
    static addNestedComment(req, res) {
        (0, nestedCommentAction_1.addNestedComment)(req, res);
    }
    static getCommentsByPostId(req, res) {
        (0, getAllCommentsAction_1.getCommentsByPostId)(req, res);
    }
    static likeAComment(req, res) {
        (0, likeACommentAction_1.likeAComment)(req, res);
    }
    static toggleLikeStoryAction(req, res) {
        (0, likeStoryAction_1.toggleLikeStoryAction)(req, res);
    }
    static createImpression(req, res) {
        (0, createImpressionAction_1.createImpression)(req, res);
    }
    static logView(req, res) {
        (0, logViewAction_1.logView)(req, res);
    }
}
exports.InteractionController = InteractionController;
//# sourceMappingURL=index.js.map