"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserProfile = void 0;
const mongoose_1 = require("mongoose");
const UserProfileSchema_1 = require("../../database/schemas/UserProfileSchema");
const UserProfile = (0, mongoose_1.model)('UserProfile', UserProfileSchema_1.UserProfileSchema);
exports.UserProfile = UserProfile;
//# sourceMappingURL=UserProfile.js.map