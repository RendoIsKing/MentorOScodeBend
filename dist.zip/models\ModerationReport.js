"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const ModerationReportSchema = new mongoose_1.Schema({
    post: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Post', index: true, required: true },
    reporter: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', index: true, required: true },
    reason: { type: String, default: '' },
    status: { type: String, enum: ['open', 'resolved'], default: 'open', index: true },
}, { timestamps: true });
ModerationReportSchema.index({ post: 1, reporter: 1, createdAt: -1 });
exports.default = mongoose_1.model.ModerationReport || (0, mongoose_1.model)('ModerationReport', ModerationReportSchema);
//# sourceMappingURL=ModerationReport.js.map