"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveNotification = void 0;
const Notification_1 = require("../../../Models/Notification"); // Adjust the path as needed
const saveNotification = async (input) => {
    const { title, description, sentTo, type, notificationOnPost, notificationFromUser, } = input;
    const notification = new Notification_1.Notification({
        title,
        description,
        sentTo,
        type,
        notificationOnPost,
        notificationFromUser,
    });
    await notification.save();
};
exports.saveNotification = saveNotification;
//# sourceMappingURL=saveNotification.js.map