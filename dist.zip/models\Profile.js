"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const ProfileSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", index: true, required: true, unique: true },
    goals: { type: String, enum: ["cut", "maintain", "gain"] },
    experienceLevel: { type: String, enum: ["beginner", "intermediate", "advanced"] },
    bodyWeightKg: Number,
    diet: { type: String, enum: ["regular", "vegan", "vegetarian", "keto", "none"] },
    schedule: {
        daysPerWeek: Number,
        preferredDays: [String],
    },
    equipment: [String],
    injuries: [String],
    preferences: {
        hates: [String],
        likes: [String],
    },
    consentFlags: {
        healthData: { type: Boolean, default: false },
        timestamp: Date,
    },
    collectedPercent: { type: Number, default: 0 },
}, { timestamps: true });
exports.default = (0, mongoose_1.model)("Profile", ProfileSchema);
//# sourceMappingURL=Profile.js.map