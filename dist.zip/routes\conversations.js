"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const mongoose_1 = require("mongoose");
const sseHub_1 = require("../lib/sseHub");
const chat_1 = require("../models/chat");
const chat_2 = require("../models/chat");
const r = (0, express_1.Router)();
function isParticipant(doc, userId) {
    try {
        return ((doc === null || doc === void 0 ? void 0 : doc.participants) || []).map(String).includes(String(userId));
    }
    catch {
        return false;
    }
}
r.post('/conversations', Middlewares_1.Auth, async (req, res) => {
    var _a, _b, _c, _d, _e, _f, _g;
    try {
        const me = String(req.user._id);
        const { partnerId } = req.body || {};
        if (!partnerId || partnerId === me)
            return res.status(400).json({ error: 'invalid partner' });
        const pair = [new mongoose_1.Types.ObjectId(me), new mongoose_1.Types.ObjectId(String(partnerId))].sort((a, b) => a.toString().localeCompare(b.toString()));
        let t = await chat_1.ChatThread.findOne({ participants: pair });
        if (!t) {
            t = await chat_1.ChatThread.create({ participants: pair, unread: new Map([[String(partnerId), 0], [me, 0]]) });
        }
        // Ensure unread map has keys for both participants
        try {
            const ids = ((t === null || t === void 0 ? void 0 : t.participants) || []).map(String);
            for (const p of ids) {
                if (((_b = (_a = t.unread) === null || _a === void 0 ? void 0 : _a.get) === null || _b === void 0 ? void 0 : _b.call(_a, p)) === undefined)
                    (_d = (_c = t.unread) === null || _c === void 0 ? void 0 : _c.set) === null || _d === void 0 ? void 0 : _d.call(_c, p, 0);
            }
            await t.save();
        }
        catch { }
        const payload = { id: String(t === null || t === void 0 ? void 0 : t._id), lastMessageText: (t === null || t === void 0 ? void 0 : t.lastMessageText) || '', lastMessageAt: (t === null || t === void 0 ? void 0 : t.lastMessageAt) || null, participants: ((t === null || t === void 0 ? void 0 : t.participants) || []).map(String), unread: (_g = (_f = (_e = t === null || t === void 0 ? void 0 : t.unread) === null || _e === void 0 ? void 0 : _e.get) === null || _f === void 0 ? void 0 : _f.call(_e, me)) !== null && _g !== void 0 ? _g : 0 };
        sseHub_1.sseHub.publishMany(payload.participants, { type: 'chat:thread', payload });
        return res.json({ conversationId: payload.id });
    }
    catch (e) {
        return res.status(500).json({ error: 'internal' });
    }
});
r.get('/conversations', Middlewares_1.Auth, async (req, res) => {
    try {
        const me = String(req.user._id);
        const list = await chat_1.ChatThread.find({ participants: me }).sort({ updatedAt: -1 }).limit(50).lean();
        return res.json({ conversations: list.map(t => { var _a, _b, _c; return ({ id: String(t._id), participants: (t.participants || []).map(String), lastMessageText: t.lastMessageText || '', lastMessageAt: t.lastMessageAt || null, unread: (_c = (_b = (_a = t === null || t === void 0 ? void 0 : t.unread) === null || _a === void 0 ? void 0 : _a.get) === null || _b === void 0 ? void 0 : _b.call(_a, me)) !== null && _c !== void 0 ? _c : 0 }); }) });
    }
    catch {
        return res.status(500).json({ error: 'internal' });
    }
});
r.get('/conversations/:id/messages', Middlewares_1.Auth, async (req, res) => {
    try {
        const me = String(req.user._id);
        const { id } = req.params;
        const t = await chat_1.ChatThread.findById(id);
        if (!t || !isParticipant(t, me))
            return res.status(403).json({ error: 'forbidden' });
        const { cursor } = req.query;
        const q = { thread: id };
        if (cursor)
            q._id = { $lt: new mongoose_1.Types.ObjectId(String(cursor)) };
        const msgs = await chat_2.ChatMessage.find(q).sort({ _id: -1 }).limit(30).lean();
        return res.json({ messages: msgs.reverse().map(m => ({ id: String(m._id), sender: String(m.sender), text: m.text, clientId: m.clientId || null, createdAt: m.createdAt })) });
    }
    catch {
        return res.status(500).json({ error: 'internal' });
    }
});
r.post('/conversations/:id/messages', Middlewares_1.Auth, async (req, res) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    try {
        const me = String(req.user._id);
        const { id } = req.params;
        const { text, clientId } = req.body || {};
        if (!text || !String(text).trim())
            return res.status(400).json({ error: 'text_required' });
        const t = await chat_1.ChatThread.findById(id);
        if (!t || !isParticipant(t, me))
            return res.status(403).json({ error: 'forbidden' });
        const m = await chat_2.ChatMessage.create({ thread: t._id, sender: me, text: String(text).trim(), clientId: clientId || null, readBy: [me] });
        t.lastMessageText = m.text;
        t.lastMessageAt = new Date();
        // Update per-user unread counts
        for (const p of (t.participants || []).map(String)) {
            if (((_b = (_a = t.unread) === null || _a === void 0 ? void 0 : _a.get) === null || _b === void 0 ? void 0 : _b.call(_a, p)) === undefined)
                (_d = (_c = t.unread) === null || _c === void 0 ? void 0 : _c.set) === null || _d === void 0 ? void 0 : _d.call(_c, p, 0);
            (_f = (_e = t.unread) === null || _e === void 0 ? void 0 : _e.set) === null || _f === void 0 ? void 0 : _f.call(_e, p, p === me ? 0 : (((_j = (_h = (_g = t.unread) === null || _g === void 0 ? void 0 : _g.get) === null || _h === void 0 ? void 0 : _h.call(_g, p)) !== null && _j !== void 0 ? _j : 0) + 1));
        }
        await t.save();
        const payload = { threadId: String(t._id), message: { id: String(m._id), sender: me, text: m.text, clientId: clientId || null, createdAt: m.createdAt, status: 'delivered' } };
        sseHub_1.sseHub.publishMany((t.participants || []).map(String), { type: 'chat:message', payload });
        // send per-user unread with chat:thread
        for (const p of (t.participants || []).map(String)) {
            sseHub_1.sseHub.publish(p, { type: 'chat:thread', payload: { id: String(t._id), lastMessageText: t.lastMessageText, lastMessageAt: t.lastMessageAt, participants: (t.participants || []).map(String), unread: (_m = (_l = (_k = t.unread) === null || _k === void 0 ? void 0 : _k.get) === null || _l === void 0 ? void 0 : _l.call(_k, p)) !== null && _m !== void 0 ? _m : 0 } });
        }
        return res.status(201).json({ ok: true, id: String(m._id) });
    }
    catch {
        return res.status(500).json({ error: 'internal' });
    }
});
r.post('/conversations/:id/read', Middlewares_1.Auth, async (req, res) => {
    var _a, _b;
    try {
        const me = String(req.user._id);
        const { id } = req.params;
        const t = await chat_1.ChatThread.findById(id);
        if (!t || !isParticipant(t, me))
            return res.status(403).json({ error: 'forbidden' });
        // Mark messages read and clear unread count
        try {
            await chat_2.ChatMessage.updateMany({ thread: id, sender: { $ne: me } }, { $addToSet: { readBy: new mongoose_1.Types.ObjectId(me) } });
        }
        catch { }
        try {
            (_b = (_a = t.unread) === null || _a === void 0 ? void 0 : _a.set) === null || _b === void 0 ? void 0 : _b.call(_a, me, 0);
            await t.save();
        }
        catch { }
        sseHub_1.sseHub.publishMany((t.participants || []).map(String), { type: 'chat:read', payload: { threadId: id, by: me } });
        // Push updated thread unread to reader
        sseHub_1.sseHub.publish(me, { type: 'chat:thread', payload: { id: String(t._id), lastMessageText: t.lastMessageText || '', lastMessageAt: t.lastMessageAt || null, participants: (t.participants || []).map(String), unread: 0 } });
        return res.json({ ok: true });
    }
    catch {
        return res.status(500).json({ error: 'internal' });
    }
});
exports.default = r;
//# sourceMappingURL=conversations.js.map