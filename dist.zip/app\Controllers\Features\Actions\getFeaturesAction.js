"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllFeaturesActions = void 0;
const Feature_1 = require("../../../Models/Feature");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const commonPagination_1 = require("../../../../utils/pipeline/commonPagination");
const getPost_input_1 = require("../../Posts/Inputs/getPost.input");
const getAllFeaturesActions = async (req, res) => {
    var _a, _b, _c, _d, _e;
    try {
        const postQuery = (0, class_transformer_1.plainToClass)(getPost_input_1.GetAllItemsInputs, req.query);
        const errors = await (0, class_validator_1.validate)(postQuery);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        const { perPage, page } = postQuery;
        let skip = (page > 0 ? page - 1 : 0) * perPage;
        const features = await Feature_1.Feature.aggregate([
            ...(0, commonPagination_1.commonPaginationPipeline)(page, perPage, skip),
        ]);
        let data = {
            data: (_b = (_a = features[0]) === null || _a === void 0 ? void 0 : _a.data) !== null && _b !== void 0 ? _b : [],
            meta: (_e = (_d = (_c = features[0]) === null || _c === void 0 ? void 0 : _c.metaData) === null || _d === void 0 ? void 0 : _d[0]) !== null && _e !== void 0 ? _e : {},
        };
        return res.json(data);
    }
    catch (err) {
        console.log("error in getting all features", err);
        return res
            .status(500)
            .json({ error: { message: "Something went wrong.", err } });
    }
};
exports.getAllFeaturesActions = getAllFeaturesActions;
//# sourceMappingURL=getFeaturesAction.js.map