"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAllPostsActions = void 0;
const class_transformer_1 = require("class-transformer");
const getPost_input_1 = require("../Inputs/getPost.input");
const class_validator_1 = require("class-validator");
const Post_1 = require("../../../Models/Post");
const commonPagination_1 = require("../../../../utils/pipeline/commonPagination");
const postTypeEnum_1 = require("../../../../types/enums/postTypeEnum");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const postsFilterEnum_1 = require("../../../../types/enums/postsFilterEnum");
const Connection_1 = require("../../../Models/Connection");
const mongoose_1 = require("mongoose");
const Subscription_1 = require("../../../Models/Subscription");
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const SubscriptionStatusEnum_1 = require("../../../../types/enums/SubscriptionStatusEnum");
const getAllPostsActions = async (req, res) => {
    var _a, _b, _c, _d, _e;
    try {
        const user = req.user;
        const postQuery = (0, class_transformer_1.plainToClass)(getPost_input_1.GetAllItemsInputs, req.query);
        const errors = await (0, class_validator_1.validate)(postQuery);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        const { perPage, page, filter, search } = postQuery;
        // Optional toggle to include the requesting user's own posts in the feed
        const includeSelfParam = (req.query.includeSelf || "").toString().toLowerCase();
        const includeSelfRequested = ["true", "1", "yes"].includes(includeSelfParam);
        // Default behavior: for FOR_YOU feed, always include self posts
        const includeSelf = filter === postsFilterEnum_1.PostFilterEnum.FOR_YOU ? true : includeSelfRequested;
        let skip = (page > 0 ? page - 1 : 0) * perPage;
        let matchStage = {
            _id: { $exists: true },
            type: postTypeEnum_1.PostType.POST,
            user: includeSelf
                ? { $exists: true }
                : {
                    $exists: true,
                    $ne: new mongoose_1.Types.ObjectId(user._id),
                },
            deletedAt: null,
            isDeleted: false,
        };
        if (filter === postsFilterEnum_1.PostFilterEnum.ALL) {
            // Public feed: only PUBLIC posts from anyone (optionally exclude own)
            matchStage.privacy = 'public';
        }
        if (filter === postsFilterEnum_1.PostFilterEnum.FOLLOWING) {
            const userConnections = await Connection_1.userConnection.find({ owner: user.id }, { followingTo: 1 });
            const followedUserIds = userConnections.map((conn) => conn.followingTo);
            matchStage.user = { $in: followedUserIds };
            // Followers feed: allow PUBLIC and FOLLOWERS visibility
            matchStage.privacy = { $in: ['public', 'followers'] };
        }
        if (filter === postsFilterEnum_1.PostFilterEnum.SUBSCRIBED) {
            const subscriptions = await Subscription_1.Subscription.find({ userId: user.id, status: SubscriptionStatusEnum_1.SubscriptionStatusEnum.ACTIVE }, { planId: 1 });
            const planIds = subscriptions.map((sub) => sub.planId);
            const subscriptionPlans = await SubscriptionPlan_1.SubscriptionPlan.find({ _id: { $in: planIds }, isDeleted: false, deletedAt: null }, { userId: 1 });
            const subscribedUserIds = subscriptionPlans.map((plan) => plan.userId);
            matchStage.user = { $in: subscribedUserIds };
            // Subscribed feed: allow PUBLIC and SUBSCRIBER visibility
            matchStage.privacy = { $in: ['public', 'subscriber'] };
        }
        // else if (filter === PostFilterEnum.FOR_YOU) {
        // }
        if (search) {
            matchStage = {
                ...matchStage,
                $or: [
                    { content: { $regex: search, $options: "i" } },
                    { tags: { $regex: search, $options: "i" } },
                ],
            };
        }
        const posts = await Post_1.Post.aggregate([
            { $match: matchStage },
            // ...(isFollowing
            //   ? [
            //       {
            //         $lookup: {
            //           from: "userconnections",
            //           let: { userId: "$user" },
            //           pipeline: [
            //             {
            //               $match: {
            //                 $expr: {
            //                   $and: [
            //                     { $eq: ["$owner", user._id] },
            //                     { $eq: ["$followingTo", "$$userId"] },
            //                   ],
            //                 },
            //               },
            //             },
            //           ],
            //           as: "connections",
            //         },
            //       },
            //       {
            //         $match: {
            //           "connections.0": { $exists: true },
            //         },
            //       },
            //     ]
            //   : []),
            {
                $lookup: {
                    from: "files",
                    localField: "media.mediaId",
                    foreignField: "_id",
                    as: "mediaFiles",
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "user",
                    foreignField: "_id",
                    as: "userInfo",
                },
            },
            {
                $lookup: {
                    from: "files",
                    localField: "userInfo.photoId",
                    foreignField: "_id",
                    as: "userPhoto",
                },
            },
            // {
            //   $addFields: {
            //     "userInfo.photo": { $arrayElemAt: ["$userPhoto", 0] },
            //   },
            // },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.LIKE_POST] },
                                    ],
                                },
                            },
                        },
                        {
                            $count: "likesCount",
                        },
                    ],
                    as: "likesCount",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id", userId: user === null || user === void 0 ? void 0 : user._id },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$interactedBy", "$$userId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.LIKE_POST] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "likeInteractions", //for isLiked key
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id", userId: user._id },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$interactedBy", "$$userId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "savedInteractions", //for isSaved Key
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED] },
                                    ],
                                },
                            },
                        },
                        {
                            $count: "savedCount",
                        },
                    ],
                    as: "savedCount",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.COMMENT] },
                                        { $eq: ["$isDeleted", false] },
                                    ],
                                },
                            },
                        },
                        {
                            $count: "commentsCount",
                        },
                    ],
                    as: "commentsCount",
                },
            },
            {
                $addFields: {
                    isLiked: { $gt: [{ $size: "$likeInteractions" }, 0] },
                    isSaved: { $gt: [{ $size: "$savedInteractions" }, 0] },
                    // Viewer ownership flag for easier UI logic
                    isOwner: { $eq: ["$user", new mongoose_1.Types.ObjectId(user._id)] },
                    commentsCount: {
                        $ifNull: [{ $arrayElemAt: ["$commentsCount.commentsCount", 0] }, 0],
                    },
                    savedCount: {
                        $ifNull: [{ $arrayElemAt: ["$savedCount.savedCount", 0] }, 0],
                    },
                    likesCount: {
                        $ifNull: [{ $arrayElemAt: ["$likesCount.likesCount", 0] }, 0],
                    },
                },
            },
            {
                $sort: { createdAt: -1 },
            },
            ...(0, commonPagination_1.commonPaginationPipeline)(page, perPage, skip),
        ]);
        let data = {
            data: (_b = (_a = posts[0]) === null || _a === void 0 ? void 0 : _a.data) !== null && _b !== void 0 ? _b : [],
            meta: (_e = (_d = (_c = posts[0]) === null || _c === void 0 ? void 0 : _c.metaData) === null || _d === void 0 ? void 0 : _d[0]) !== null && _e !== void 0 ? _e : {},
        };
        return res.json(data);
    }
    catch (err) {
        console.log("Error while retrieving posts", err);
        return res
            .status(500)
            .json({ error: { message: "Something went wrong.", err } });
    }
};
exports.getAllPostsActions = getAllPostsActions;
//# sourceMappingURL=getAllPosts.action.js.map