"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toggleLikeAction = void 0;
const Post_1 = require("../../../Models/Post");
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const User_1 = require("../../../Models/User");
const notificationService_1 = require("../../../../utils/Notifications/notificationService");
const FirebaseNotificationEnum_1 = require("../../../../types/enums/FirebaseNotificationEnum");
const saveNotification_1 = require("../../Notifications/Actions/saveNotification");
const toggleLikeAction = async (req, res) => {
    try {
        const user = req.user;
        const postId = req.params.id;
        const postExists = (await Post_1.Post.findById(postId));
        if (!postExists || (postExists === null || postExists === void 0 ? void 0 : postExists.isDeleted)) {
            return res.status(400).json({ error: { message: "Post not exist" } });
        }
        const intreactionExist = await Interaction_1.Interaction.findOne({
            user: postExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
            post: postId,
        });
        if (intreactionExist) {
            await Interaction_1.Interaction.deleteOne({ _id: intreactionExist.id });
            return res.json({
                data: {
                    message: "Post disliked",
                },
            });
        }
        const like = await Interaction_1.Interaction.create({
            user: postExists.user,
            interactedBy: user.id,
            type: InteractionTypeEnum_1.InteractionType.LIKE_POST,
            post: postId,
        });
        try {
            const userPostLiked = await User_1.User.findById(postExists.user);
            const interactedByUser = await User_1.User.findById(user.id);
            if (!interactedByUser) {
                return res
                    .status(404)
                    .json({ error: { message: "Username not found" } });
            }
            if (userPostLiked && userPostLiked.fcm_token) {
                const notificationToken = userPostLiked.fcm_token;
                if (notificationToken) {
                    const notificationTitle = "New Like on your post";
                    const notificationDescription = `${interactedByUser.userName} liked your post`;
                    await (0, notificationService_1.sendNotification)(notificationToken, notificationTitle, notificationDescription, FirebaseNotificationEnum_1.FirebaseNotificationEnum.LIKE_POST, postExists.id);
                    await (0, saveNotification_1.saveNotification)({
                        title: notificationTitle,
                        description: notificationDescription,
                        sentTo: [userPostLiked._id],
                        type: FirebaseNotificationEnum_1.FirebaseNotificationEnum.LIKE_POST,
                        notificationOnPost: postExists.id,
                        notificationFromUser: null
                    });
                }
                else {
                    console.error("FCM token for the user not found");
                }
            }
        }
        catch (error) {
            console.log("Error sending like notification", error);
        }
        return res.json({
            data: like,
            message: "Post liked",
        });
    }
    catch (error) {
        console.log(error, "Error in liking the post");
        if (error.code === 11000) {
            return res
                .status(500)
                .json({ error: { message: "User already liked the post", error } });
        }
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.toggleLikeAction = toggleLikeAction;
//# sourceMappingURL=likePost.action.js.map