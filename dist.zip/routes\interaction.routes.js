"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
// zod not used directly in this file (schemas are imported from Validation)
const schemas_1 = require("../app/Validation/schemas");
const Middlewares_1 = require("../app/Middlewares");
const rateLimiters_1 = require("../app/Middlewares/rateLimiters");
const Interaction_1 = require("../app/Controllers/Interaction");
const chat_controller_1 = require("../app/Controllers/Interaction/chat.controller");
const generateFirstPlans_1 = require("../app/Controllers/Interaction/generateFirstPlans");
const decisionEngine_1 = require("../app/Controllers/Interaction/decisionEngine");
const PlanModels_1 = require("../app/Models/PlanModels");
const TrainingPlanVersion_1 = __importDefault(require("../models/TrainingPlanVersion"));
const NutritionPlanVersion_1 = __importDefault(require("../models/NutritionPlanVersion"));
const StudentState_1 = __importDefault(require("../models/StudentState"));
const ChangeEvent_1 = __importDefault(require("../models/ChangeEvent"));
const nextVersion_1 = require("../services/versioning/nextVersion");
const publish_1 = require("../services/events/publish");
const training_1 = require("../services/planRules/training");
const materialize_1 = require("../services/planRules/materialize");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const UserProfile_1 = require("../app/Models/UserProfile");
const fileUpload_1 = require("../app/Middlewares/fileUpload");
const FileEnum_1 = require("../types/FileEnum");
const CoachKnowledge_1 = require("../app/Models/CoachKnowledge");
const path_1 = __importDefault(require("path"));
const thread_controller_1 = require("../app/Controllers/Interaction/thread.controller");
const uploadRoot = (process.env.UPLOAD_ROOT
    ? require('path').isAbsolute(process.env.UPLOAD_ROOT)
        ? process.env.UPLOAD_ROOT
        : `${process.cwd()}${process.env.UPLOAD_ROOT}`
    : `${process.cwd()}${FileEnum_1.FileEnum.PUBLICDIR}`);
const knowledgeUpload = (0, fileUpload_1.createMulterInstance)(`${uploadRoot}/coach-knowledge`);
const Middlewares_2 = require("../app/Middlewares");
const InteractionRoutes = (0, express_1.Router)();
InteractionRoutes.post("/toggle-like/:id", Middlewares_2.Auth, Interaction_1.InteractionController.toggleLike);
InteractionRoutes.post("/comment/:id", Middlewares_2.Auth, Interaction_1.InteractionController.postComment);
InteractionRoutes.delete("/comment/:id", Middlewares_2.Auth, Interaction_1.InteractionController.softDeleteComment);
InteractionRoutes.post("/toggle-saved/:id", Middlewares_2.Auth, Interaction_1.InteractionController.togglePost);
InteractionRoutes.post("/reply-comment/:id", Middlewares_2.Auth, Interaction_1.InteractionController.addNestedComment);
InteractionRoutes.get("/comments/:id", Middlewares_2.Auth, Interaction_1.InteractionController.getCommentsByPostId);
InteractionRoutes.post("/like-comment/:id", Middlewares_2.Auth, Interaction_1.InteractionController.likeAComment);
InteractionRoutes.post("/like-story/:id", Middlewares_2.Auth, Interaction_1.InteractionController.toggleLikeStoryAction);
InteractionRoutes.post("/impressions", Middlewares_2.Auth, Interaction_1.InteractionController.createImpression);
InteractionRoutes.post("/log-view", Middlewares_2.Auth, Interaction_1.InteractionController.logView);
// New route for Coach Engh chat
InteractionRoutes.post("/chat/engh", Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), chat_controller_1.chatWithCoachEngh);
// Coach Majen avatar chat (mirror of Engh path shape)
InteractionRoutes.post("/chat/majen", Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), chat_controller_1.chatWithCoachMajen);
// Expose Majen coach user for FE convenience (dev only if seeded)
InteractionRoutes.get('/chat/majen/coach', Middlewares_1.Auth, async (req, res) => {
    try {
        const { User } = await Promise.resolve().then(() => __importStar(require('../app/Models/User')));
        const u = await User.findOne({ userName: 'coach-majen' }).lean();
        if (!(u === null || u === void 0 ? void 0 : u._id))
            return res.status(404).json({ message: 'not found' });
        return res.json({ id: String(u._id), userName: u.userName, fullName: u.fullName });
    }
    catch {
        return res.status(500).json({ message: 'lookup failed' });
    }
});
InteractionRoutes.post('/chat/engh/plans/generate-first', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 20 }), generateFirstPlans_1.generateFirstPlans);
// Open endpoint publicly (no Auth) to make it easy to call from chat UI
InteractionRoutes.post('/chat/engh/action', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 30 }), decisionEngine_1.decideAndApplyAction);
// Unified actions endpoint (rules engine)
function validateActionBody(body, userId) {
    const parsed = schemas_1.ActionSchema.safeParse(body);
    if (!parsed.success)
        return { ok: false, error: parsed.error.flatten() };
    return { ok: true, data: { ...parsed.data, userId } };
}
InteractionRoutes.post('/interaction/actions/apply', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c, _d, _e, _f, _g;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId || ((_c = (_b = req.session) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.id);
        if (!userId) {
            const cookie = (_d = req.headers) === null || _d === void 0 ? void 0 : _d.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = (await Promise.resolve().then(() => __importStar(require('jsonwebtoken')))).default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId) {
            // Dev fallback: if running with dev routes enabled and no session cookie was forwarded
            try {
                const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
                if (enabled === 'true' || (process.env.NODE_ENV !== 'production')) {
                    const { User } = await Promise.resolve().then(() => __importStar(require('../app/Models/User')));
                    const demo = await User.findOne({ email: 'demo@mentoros.app' }).lean();
                    if (demo === null || demo === void 0 ? void 0 : demo._id)
                        userId = String(demo._id);
                }
            }
            catch { }
        }
        if (!userId)
            return res.status(400).json({ error: 'userId required' });
        const validated = validateActionBody(req.body, typeof userId === 'string' ? userId : String(userId || ''));
        if (!validated.ok)
            return res.status(422).json({ error: 'validation_failed', details: validated.error });
        const { type, payload } = validated.data;
        // Safety rails
        const MIN_KCAL = 1200;
        const MAX_KCAL = 5000;
        const MAX_VOL_JUMP = 0.20; // 20%
        if (type === 'NUTRITION_SET_CALORIES') {
            const parsed = schemas_1.NutritionCaloriesSchema.safeParse(payload);
            if (!parsed.success)
                return res.status(422).json({ error: 'validation_failed', details: parsed.error.flatten() });
            const kcal = Number(parsed.data.kcal);
            if (kcal < MIN_KCAL || kcal > MAX_KCAL)
                return res.status(422).json({ error: `kcal must be between ${MIN_KCAL} and ${MAX_KCAL}` });
        }
        // Read current versions via StudentState pointers
        const StudentState = (await Promise.resolve().then(() => __importStar(require('../models/StudentState')))).default;
        const TrainingPlanVersion = (await Promise.resolve().then(() => __importStar(require('../models/TrainingPlanVersion')))).default;
        const state = await StudentState.findOne({ user: userId });
        const currentTraining = (state === null || state === void 0 ? void 0 : state.currentTrainingPlanVersion) ? await TrainingPlanVersion.findById(state.currentTrainingPlanVersion) : null;
        if (type === 'PLAN_SWAP_EXERCISE') {
            const vr = schemas_1.SwapExerciseSchema.safeParse(payload);
            if (!vr.success)
                return res.status(422).json({ error: 'validation_failed', details: vr.error.flatten() });
            if (!currentTraining)
                return res.status(404).json({ error: 'No current training plan' });
            const patch = (0, training_1.patchSwapExercise)(currentTraining.days, vr.data.day || 'Mon', vr.data.from, vr.data.to);
            const ret = await (0, materialize_1.applyTrainingPatch)(userId, currentTraining, patch);
            return res.json({ ok: true, summary: patch.reason.summary, ...ret });
        }
        if (type === 'PLAN_SET_DAYS_PER_WEEK') {
            const vr = schemas_1.DaysPerWeekSchema.safeParse(payload);
            if (!vr.success)
                return res.status(422).json({ error: 'validation_failed', details: vr.error.flatten() });
            if (!currentTraining)
                return res.status(404).json({ error: 'No current training plan' });
            const nextDays = Number(vr.data.daysPerWeek || 3);
            if (!Number.isFinite(nextDays) || nextDays < 1 || nextDays > 7)
                return res.status(422).json({ error: 'daysPerWeek must be 1–7' });
            try {
                const currentDays = Array.isArray(currentTraining.days)
                    ? (currentTraining.days.filter((d) => (d.exercises || []).length > 0).length || currentTraining.days.length || 0)
                    : 0;
                if (currentDays && nextDays > Math.ceil(currentDays * (1 + MAX_VOL_JUMP))) {
                    return res.status(422).json({ error: 'volume jump >20% blocked. Increase gradually.' });
                }
            }
            catch { }
            const patch = (0, training_1.patchSetDaysPerWeek)(currentTraining.days, nextDays);
            const ret = await (0, materialize_1.applyTrainingPatch)(userId, currentTraining, patch);
            return res.json({ ok: true, summary: patch.reason.summary, ...ret });
        }
        if (type === 'NUTRITION_SET_CALORIES') {
            const kcal = Number(payload === null || payload === void 0 ? void 0 : payload.kcal);
            const ret = await (0, materialize_1.applyNutritionPatch)(userId, { kcal, reason: { summary: `Kalorier satt til ${kcal}` } });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'NUTRITION_EDIT', summary: `Satte kalorier: ${kcal} kcal`, actor: (_e = req === null || req === void 0 ? void 0 : req.user) === null || _e === void 0 ? void 0 : _e._id, before: { current: state === null || state === void 0 ? void 0 : state.currentNutritionPlanVersion }, after: { kcal } });
            }
            catch { }
            return res.json({ ok: true, summary: `Kalorier satt til ${kcal}`, ...ret });
        }
        if (type === 'WEIGHT_LOG') {
            const vr = schemas_1.WeightLogSchema.safeParse(payload);
            if (!vr.success)
                return res.status(422).json({ error: 'validation_failed', details: vr.error.flatten() });
            const { date, kg } = vr.data;
            const { WeightEntry } = await Promise.resolve().then(() => __importStar(require('../app/Models/WeightEntry')));
            await WeightEntry.updateOne({ userId, date }, { $set: { kg } }, { upsert: true });
            try {
                const ChangeEvent = (await Promise.resolve().then(() => __importStar(require('../models/ChangeEvent')))).default;
                await ChangeEvent.create({ user: userId, type: 'WEIGHT_LOG', summary: `Logget vekt: ${kg} kg (${date})`, actor: (_f = req === null || req === void 0 ? void 0 : req.user) === null || _f === void 0 ? void 0 : _f._id, after: { date, kg } });
            }
            catch { }
            await (0, publish_1.publish)({ type: 'WEIGHT_LOGGED', user: userId, date, kg });
            return res.json({ ok: true, summary: `Vekt ${kg}kg lagret` });
        }
        if (type === 'WEIGHT_DELETE') {
            const vr = schemas_1.WeightDeleteSchema.safeParse(payload);
            if (!vr.success)
                return res.status(422).json({ error: 'validation_failed', details: vr.error.flatten() });
            const { date } = vr.data;
            const { WeightEntry } = await Promise.resolve().then(() => __importStar(require('../app/Models/WeightEntry')));
            await WeightEntry.deleteOne({ userId, date });
            try {
                const ChangeEvent = (await Promise.resolve().then(() => __importStar(require('../models/ChangeEvent')))).default;
                await ChangeEvent.create({ user: userId, type: 'WEIGHT_LOG', summary: `Weight entry deleted for ${date}`, actor: (_g = req === null || req === void 0 ? void 0 : req.user) === null || _g === void 0 ? void 0 : _g._id, before: { date } });
            }
            catch { }
            await (0, publish_1.publish)({ type: 'WEIGHT_DELETED', user: userId, date });
            return res.json({ ok: true, summary: `Vekt slettet (${date})` });
        }
        return res.status(400).json({ error: 'Unknown action type' });
    }
    catch (e) {
        return res.status(500).json({ error: 'Action apply failed' });
    }
});
// Alias without the extra "/interaction" segment so final path is
// /api/backend/v1/interaction/actions/apply (expected by FE/tests)
InteractionRoutes.post('/actions/apply', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c, _d, _e;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = (await Promise.resolve().then(() => __importStar(require('jsonwebtoken')))).default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId) {
            // Dev fallback: if running with dev routes enabled and no session cookie was forwarded
            try {
                const enabled = String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase();
                if (enabled === 'true' || (process.env.NODE_ENV !== 'production')) {
                    const { User } = await Promise.resolve().then(() => __importStar(require('../app/Models/User')));
                    const demo = await User.findOne({ email: 'demo@mentoros.app' }).lean();
                    if (demo === null || demo === void 0 ? void 0 : demo._id)
                        userId = String(demo._id);
                }
            }
            catch { }
        }
        if (!userId)
            return res.status(400).json({ error: 'userId required' });
        const validated = validateActionBody(req.body, typeof userId === 'string' ? userId : String(userId || ''));
        if (!validated.ok)
            return res.status(422).json({ error: 'validation_failed', details: validated.error });
        const { type, payload } = validated.data;
        const MIN_KCAL = 1200;
        const MAX_KCAL = 5000;
        const MAX_VOL_JUMP = 0.20;
        if (type === 'NUTRITION_SET_CALORIES') {
            const kcal = Number(payload === null || payload === void 0 ? void 0 : payload.kcal);
            if (!Number.isFinite(kcal))
                return res.status(400).json({ error: 'kcal required' });
            if (kcal < MIN_KCAL || kcal > MAX_KCAL)
                return res.status(422).json({ error: `kcal must be between ${MIN_KCAL} and ${MAX_KCAL}` });
        }
        const StudentState = (await Promise.resolve().then(() => __importStar(require('../models/StudentState')))).default;
        const TrainingPlanVersion = (await Promise.resolve().then(() => __importStar(require('../models/TrainingPlanVersion')))).default;
        const state = await StudentState.findOne({ user: userId });
        const currentTraining = (state === null || state === void 0 ? void 0 : state.currentTrainingPlanVersion) ? await TrainingPlanVersion.findById(state.currentTrainingPlanVersion) : null;
        if (type === 'PLAN_SWAP_EXERCISE') {
            if (!currentTraining)
                return res.status(404).json({ error: 'No current training plan' });
            const patch = (0, training_1.patchSwapExercise)(currentTraining.days, (payload === null || payload === void 0 ? void 0 : payload.day) || 'Mon', payload === null || payload === void 0 ? void 0 : payload.from, payload === null || payload === void 0 ? void 0 : payload.to);
            const ret = await (0, materialize_1.applyTrainingPatch)(userId, currentTraining, patch);
            return res.json({ ok: true, summary: patch.reason.summary, ...ret });
        }
        if (type === 'PLAN_SET_DAYS_PER_WEEK') {
            if (!currentTraining)
                return res.status(404).json({ error: 'No current training plan' });
            const nextDays = Number((payload === null || payload === void 0 ? void 0 : payload.daysPerWeek) || 3);
            if (!Number.isFinite(nextDays) || nextDays < 1 || nextDays > 7)
                return res.status(422).json({ error: 'daysPerWeek must be 1–7' });
            try {
                const currentDays = Array.isArray(currentTraining.days)
                    ? (currentTraining.days.filter((d) => (d.exercises || []).length > 0).length || currentTraining.days.length || 0)
                    : 0;
                if (currentDays && nextDays > Math.ceil(currentDays * (1 + MAX_VOL_JUMP))) {
                    return res.status(422).json({ error: 'volume jump >20% blocked. Increase gradually.' });
                }
            }
            catch { }
            const patch = (0, training_1.patchSetDaysPerWeek)(currentTraining.days, nextDays);
            const ret = await (0, materialize_1.applyTrainingPatch)(userId, currentTraining, patch);
            return res.json({ ok: true, summary: patch.reason.summary, ...ret });
        }
        if (type === 'NUTRITION_SET_CALORIES') {
            const kcal = Number(payload === null || payload === void 0 ? void 0 : payload.kcal);
            const ret = await (0, materialize_1.applyNutritionPatch)(userId, { kcal, reason: { summary: `Kalorier satt til ${kcal}` } });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'NUTRITION_EDIT', summary: `Satte kalorier: ${kcal} kcal`, actor: (_c = req === null || req === void 0 ? void 0 : req.user) === null || _c === void 0 ? void 0 : _c._id, before: { current: state === null || state === void 0 ? void 0 : state.currentNutritionPlanVersion }, after: { kcal } });
            }
            catch { }
            return res.json({ ok: true, summary: `Kalorier satt til ${kcal}`, ...ret });
        }
        if (type === 'WEIGHT_LOG') {
            const { date, kg } = payload || {};
            const { WeightEntry } = await Promise.resolve().then(() => __importStar(require('../app/Models/WeightEntry')));
            await WeightEntry.updateOne({ userId, date }, { $set: { kg } }, { upsert: true });
            try {
                const ChangeEvent = (await Promise.resolve().then(() => __importStar(require('../models/ChangeEvent')))).default;
                await ChangeEvent.create({ user: userId, type: 'WEIGHT_LOG', summary: `Logget vekt: ${kg} kg (${date})`, actor: (_d = req === null || req === void 0 ? void 0 : req.user) === null || _d === void 0 ? void 0 : _d._id, after: { date, kg } });
            }
            catch { }
            await (0, publish_1.publish)({ type: 'WEIGHT_LOGGED', user: userId, date, kg });
            return res.json({ ok: true, summary: `Vekt ${kg}kg lagret` });
        }
        if (type === 'WEIGHT_DELETE') {
            const { date } = payload || {};
            const { WeightEntry } = await Promise.resolve().then(() => __importStar(require('../app/Models/WeightEntry')));
            await WeightEntry.deleteOne({ userId, date });
            try {
                const ChangeEvent = (await Promise.resolve().then(() => __importStar(require('../models/ChangeEvent')))).default;
                await ChangeEvent.create({ user: userId, type: 'WEIGHT_LOG', summary: `Weight entry deleted for ${date}`, actor: (_e = req === null || req === void 0 ? void 0 : req.user) === null || _e === void 0 ? void 0 : _e._id, before: { date } });
            }
            catch { }
            await (0, publish_1.publish)({ type: 'WEIGHT_DELETED', user: userId, date });
            return res.json({ ok: true, summary: `Vekt slettet (${date})` });
        }
        return res.status(400).json({ error: 'Unknown action type' });
    }
    catch (e) {
        return res.status(500).json({ error: 'Action apply failed' });
    }
});
// Apply a plan change proposed by AI (text plan with strict header)
// Body: { text: string, userId?: string }
InteractionRoutes.post('/actions/applyPlanChange', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 20 }), async (req, res) => {
    var _a, _b, _c, _d, _e;
    try {
        const text = String((req.body || {}).text || '').trim();
        if (!text)
            return res.status(400).json({ ok: false, error: 'text_required' });
        // Basic validation per spec
        // Header lines: ^(Ny|Endring på) ...\n##Type: (Treningsplan|Kostholdsplan|Mål)\nPlan: ...
        const headerRe = /^(Ny|Endring på)\s.+\n\s*##Type:\s*(Treningsplan|Kostholdsplan|Mål)\s*\n\s*Plan:\s*(.+)$/im;
        const m = text.match(headerRe);
        if (!m)
            return res.status(422).json({ ok: false, error: 'invalid_header' });
        const type = (m[2] || '').trim();
        // Require all weekdays listed at least once (Norwegian names) - now properly supports the new format
        const days = ['Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag', 'Søndag'];
        const missing = days.filter(d => !new RegExp(`^\s*${d}\s*:`, 'im').test(text));
        if (missing.length)
            return res.status(422).json({ ok: false, error: 'missing_days', missing });
        // Decide underlying importer based on type
        const api = type.toLowerCase();
        const userId = ((_a = req === null || req === void 0 ? void 0 : req.user) === null || _a === void 0 ? void 0 : _a._id) || ((_b = req.body) === null || _b === void 0 ? void 0 : _b.userId) || undefined;
        // Reuse existing from-text endpoints for materialization
        if (api.includes('trenings')) {
            try {
                const { default: fetch } = await Promise.resolve().then(() => __importStar(require('node-fetch')));
                const base = process.env.API_BASE_INTERNAL || `http://localhost:${process.env.PORT || 3006}`;
                const r = await fetch(`${base}/api/backend/v1/interaction/chat/engh/training/from-text`, { method: 'POST', headers: { 'Content-Type': 'application/json', cookie: req.headers.cookie || '' }, body: JSON.stringify({ text, userId }) });
                const j = await r.json().catch(() => ({}));
                if (!((_c = j === null || j === void 0 ? void 0 : j.actions) === null || _c === void 0 ? void 0 : _c.length))
                    return res.status(500).json({ ok: false, error: 'apply_failed' });
                return res.json({ ok: true, type: 'Treningsplan', summary: (j === null || j === void 0 ? void 0 : j.summary) || 'Training plan applied' });
            }
            catch {
                return res.status(500).json({ ok: false, error: 'apply_failed' });
            }
        }
        if (api.includes('kostholds')) {
            try {
                const { default: fetch } = await Promise.resolve().then(() => __importStar(require('node-fetch')));
                const base = process.env.API_BASE_INTERNAL || `http://localhost:${process.env.PORT || 3006}`;
                const r = await fetch(`${base}/api/backend/v1/interaction/chat/engh/nutrition/from-text`, { method: 'POST', headers: { 'Content-Type': 'application/json', cookie: req.headers.cookie || '' }, body: JSON.stringify({ text, userId }) });
                const j = await r.json().catch(() => ({}));
                if (!((_d = j === null || j === void 0 ? void 0 : j.actions) === null || _d === void 0 ? void 0 : _d.length))
                    return res.status(500).json({ ok: false, error: 'apply_failed' });
                return res.json({ ok: true, type: 'Kostholdsplan', summary: (j === null || j === void 0 ? void 0 : j.summary) || 'Nutrition plan applied' });
            }
            catch {
                return res.status(500).json({ ok: false, error: 'apply_failed' });
            }
        }
        if (api.includes('mål') || api.includes('mal')) {
            try {
                const { default: fetch } = await Promise.resolve().then(() => __importStar(require('node-fetch')));
                const base = process.env.API_BASE_INTERNAL || `http://localhost:${process.env.PORT || 3006}`;
                const r = await fetch(`${base}/api/backend/v1/interaction/chat/engh/goals/from-text`, { method: 'POST', headers: { 'Content-Type': 'application/json', cookie: req.headers.cookie || '' }, body: JSON.stringify({ text, userId }) });
                const j = await r.json().catch(() => ({}));
                if (!((_e = j === null || j === void 0 ? void 0 : j.actions) === null || _e === void 0 ? void 0 : _e.length))
                    return res.status(500).json({ ok: false, error: 'apply_failed' });
                return res.json({ ok: true, type: 'Mål', summary: (j === null || j === void 0 ? void 0 : j.summary) || 'Goals applied' });
            }
            catch {
                return res.status(500).json({ ok: false, error: 'apply_failed' });
            }
        }
        return res.status(422).json({ ok: false, error: 'unknown_type', type });
    }
    catch {
        return res.status(500).json({ ok: false, error: 'server_error' });
    }
});
// Thread persistence (parameterized partner)
InteractionRoutes.get('/chat/:partner/thread', Middlewares_2.Auth, thread_controller_1.getThread);
// Make thread persistence usable from public avatar chat pages
InteractionRoutes.get('/chat/:partner/messages', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), thread_controller_1.getThread);
InteractionRoutes.post('/chat/:partner/message', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 60 }), thread_controller_1.appendMessage);
InteractionRoutes.post('/chat/:partner/clear', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 20 }), thread_controller_1.clearThread);
// Get current goal for user
InteractionRoutes.get('/chat/engh/goals/current', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    var _a;
    try {
        const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.query.userId || (() => {
            var _a;
            const cookie = (_a = req.headers) === null || _a === void 0 ? void 0 : _a.cookie;
            if (!cookie)
                return undefined;
            const match = cookie.match(/auth_token=([^;]+)/);
            if (!match)
                return undefined;
            try {
                const token = decodeURIComponent(match[1]);
                const secret = process.env.JWT_SECRET || 'secret_secret';
                const decoded = jsonwebtoken_1.default.verify(token, secret);
                return (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
            }
            catch {
                return undefined;
            }
        })();
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const goal = await PlanModels_1.Goal.findOne({ userId, isCurrent: true }).sort({ version: -1 }).lean();
        if (!goal)
            return res.status(404).json({ message: 'not found' });
        return res.json({ data: goal });
    }
    catch (e) {
        return res.status(500).json({ message: 'goal fetch failed' });
    }
});
// Get current training plan for user (mirrors goals/current behavior)
InteractionRoutes.get('/chat/engh/training/current', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    var _a;
    try {
        const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.query.userId || (() => {
            var _a;
            const cookie = (_a = req.headers) === null || _a === void 0 ? void 0 : _a.cookie;
            if (!cookie)
                return undefined;
            const match = cookie.match(/auth_token=([^;]+)/);
            if (!match)
                return undefined;
            try {
                const token = decodeURIComponent(match[1]);
                const secret = process.env.JWT_SECRET || 'secret_secret';
                const decoded = jsonwebtoken_1.default.verify(token, secret);
                return (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
            }
            catch {
                return undefined;
            }
        })();
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const plan = await PlanModels_1.TrainingPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 }).lean();
        if (!plan)
            return res.status(404).json({ message: 'not found' });
        return res.json({ data: plan });
    }
    catch (e) {
        return res.status(500).json({ message: 'training fetch failed' });
    }
});
// Get current nutrition plan for user
InteractionRoutes.get('/chat/engh/nutrition/current', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    var _a;
    try {
        const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.query.userId || (() => {
            var _a;
            const cookie = (_a = req.headers) === null || _a === void 0 ? void 0 : _a.cookie;
            if (!cookie)
                return undefined;
            const match = cookie.match(/auth_token=([^;]+)/);
            if (!match)
                return undefined;
            try {
                const token = decodeURIComponent(match[1]);
                const secret = process.env.JWT_SECRET || 'secret_secret';
                const decoded = jsonwebtoken_1.default.verify(token, secret);
                return (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
            }
            catch {
                return undefined;
            }
        })();
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const plan = await PlanModels_1.NutritionPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 }).lean();
        if (!plan)
            return res.status(404).json({ message: 'not found' });
        return res.json({ data: plan });
    }
    catch (e) {
        return res.status(500).json({ message: 'nutrition fetch failed' });
    }
});
// Upload coach knowledge files (for now, tied to Coach Engh; later use coachId param)
InteractionRoutes.post('/chat/engh/knowledge/upload', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 10 }), knowledgeUpload.single('file'), async (req, res) => {
    var _a;
    try {
        const file = req.file;
        if (!file)
            return res.status(400).json({ message: 'file is required' });
        const doc = await CoachKnowledge_1.CoachKnowledge.create({
            coachId: ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || undefined,
            title: file.originalname,
            filePath: path_1.default.join('coach-knowledge', file.filename),
            mimeType: file.mimetype,
            sizeBytes: file.size,
        });
        return res.json({ data: doc });
    }
    catch (e) {
        return res.status(500).json({ message: 'upload failed' });
    }
});
// Save free-form text knowledge
InteractionRoutes.post('/chat/engh/knowledge/text', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 30 }), async (req, res) => {
    var _a;
    try {
        const { text, title } = req.body || {};
        if (!text)
            return res.status(400).json({ message: 'text is required' });
        const doc = await CoachKnowledge_1.CoachKnowledge.create({ coachId: ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || undefined, title, text });
        return res.json({ data: doc });
    }
    catch (e) {
        return res.status(500).json({ message: 'save failed' });
    }
});
// First-time profile save/update
InteractionRoutes.post('/chat/engh/profile', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 30 }), async (req, res) => {
    var _a, _b;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const payload = (({ goals, currentWeightKg, strengths, weaknesses, injuryHistory, nutritionPreferences, trainingDaysPerWeek }) => ({ goals, currentWeightKg, strengths, weaknesses, injuryHistory, nutritionPreferences, trainingDaysPerWeek }))(req.body || {});
        const doc = await UserProfile_1.UserProfile.findOneAndUpdate({ userId }, { $set: payload, $setOnInsert: { userId } }, { new: true, upsert: true });
        return res.json({ data: doc });
    }
    catch (e) {
        return res.status(500).json({ message: 'profile save failed' });
    }
});
// Get profile (for onboarding check)
InteractionRoutes.get('/chat/engh/profile', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: 120 }), async (req, res) => {
    var _a, _b;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.query.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const doc = await UserProfile_1.UserProfile.findOne({ userId });
        if (!doc)
            return res.status(404).json({ message: 'not found' });
        return res.json({ data: doc });
    }
    catch (e) {
        return res.status(500).json({ message: 'profile fetch failed' });
    }
});
exports.default = InteractionRoutes;
// DEV: quick diagnostics to confirm plans exist for current user (no Auth)
InteractionRoutes.get('/debug/plans', async (req, res) => {
    var _a;
    try {
        const cookie = (_a = req.headers) === null || _a === void 0 ? void 0 : _a.cookie;
        const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
        let userId;
        if (match) {
            try {
                const token = decodeURIComponent(match[1]);
                const secret = process.env.JWT_SECRET || 'secret_secret';
                const decoded = jsonwebtoken_1.default.verify(token, secret);
                userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
            }
            catch { }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId not resolved from cookie' });
        const Models = await Promise.resolve().then(() => __importStar(require('../app/Models/PlanModels')));
        const [tp, np, g] = await Promise.all([
            Models.TrainingPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 }).lean(),
            Models.NutritionPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 }).lean(),
            Models.Goal.findOne({ userId, isCurrent: true }).sort({ version: -1 }).lean(),
        ]);
        return res.json({ userId, training: tp, nutrition: np, goal: g });
    }
    catch (e) {
        return res.status(500).json({ message: 'debug failed' });
    }
});
// Create training plan from free-form text sent by the assistant (quick import)
InteractionRoutes.post('/chat/engh/training/from-text', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const rawText = (((_c = req.body) === null || _c === void 0 ? void 0 : _c.text) || '').replace(/\r/g, '');
        // Strip any preamble before the first "Dag X:" so we don't create a bogus first session
        const textFromFirstDay = /Dag\s*\d+\s*:/i.test(rawText)
            ? rawText.replace(/[\s\S]*?(?=Dag\s*\d+\s*:)/i, '')
            : rawText;
        const blocks = textFromFirstDay.split(/Dag\s*\d+\s*:/i).filter(Boolean);
        const pickFocus = ['Push', 'Pull', 'Legs', 'Overkropp', 'Underkropp', 'Fullkropp'];
        function extractExercises(src) {
            const text = String(src)
                .replace(/<br\s*\/?>(?=\S)/gi, '\n')
                .replace(/<[^>]+>/g, '')
                .replace(/\r/g, '')
                .trim();
            const rawLines = text.split(/\n/).map(l => l.trim()).filter(Boolean);
            // Merge two-line patterns: name on one line, scheme on the next
            const lines = [];
            for (let i = 0; i < rawLines.length; i++) {
                const cur = rawLines[i];
                const next = rawLines[i + 1] || '';
                const hasNumbers = /(\d{1,2})\s*(?:sett|set|x|×)/i.test(cur) || /(\d{1,2})\s*(?:reps|repetisjoner)/i.test(cur);
                const nextHasNumbers = /(\d{1,2})\s*(?:sett|set|x|×)/i.test(next) || /(\d{1,2})\s*(?:reps|repetisjoner)/i.test(next);
                const curLooksLikeName = /(^\d+\.|^[-•])?\s*[A-Za-zÆØÅæøå0-9/(),\.\-\s]+$/.test(cur) && !hasNumbers;
                const nextIsEnumeratedOrBullet = /^\s*\d+\./.test(next) || /^\s*[-•]/.test(next);
                if (curLooksLikeName && nextHasNumbers && !nextIsEnumeratedOrBullet) {
                    lines.push(`${cur} — ${next}`);
                    i++; // skip next
                }
                else {
                    lines.push(cur);
                }
            }
            const results = [];
            const banned = /(plan|treningsplan|muskelvekst|styrke:|generelle|tips|oppvarming|nedtrapping|progresjon|restituer|kalor|måltid|kosthold|notater|varighet|frekvens)/i;
            const nameGroup = "[A-Za-zÆØÅæøå0-9/()\\.,\-\s]+?";
            // Pass A: Enumerated items like "1. Benkpress (…)", with scheme possibly on following lines
            for (let i = 0; i < lines.length; i++) {
                const l = lines[i];
                if (banned.test(l))
                    continue;
                const numMatch = l.match(/^\s*(\d+)\.\s*(.+)$/);
                if (!numMatch)
                    continue;
                const nameCandidate = numMatch[2].replace(/\s*#.*$/, '').trim();
                if (!nameCandidate || /Dag\s*\d+:/i.test(nameCandidate))
                    continue;
                let sets;
                let reps;
                // try same merged line first (supports formats like "3x8" or "3 sett x 8 reps")
                const mSame = l.match(/(\d{1,2})\s*(?:sett|set)[^\d]*(\d{1,2})/i) || l.match(/(\d{1,2})\s*[x×]\s*(\d{1,2})/i);
                if (mSame) {
                    sets = Number(mSame[1]);
                    reps = Number(mSame[2]);
                }
                // search forward within a small lookahead window until next enumerated item
                for (let j = i + 1; (!sets || !reps) && j < lines.length && !/^\s*\d+\./.test(lines[j]); j++) {
                    const t = lines[j];
                    if (banned.test(t))
                        continue;
                    const m = t.match(/(\d{1,2})\s*(?:sett|set)[^\d]*(\d{1,2})/i) || t.match(/(\d{1,2})\s*[x×]\s*(\d{1,2})/i);
                    if (m) {
                        sets = Number(m[1]);
                        reps = Number(m[2]);
                        break;
                    }
                    const hold = t.match(/(\d{1,2})\s*(?:sett|set)[^\d]*hold/i);
                    if (hold) {
                        sets = Number(hold[1]);
                        reps = 10;
                        break;
                    }
                }
                results.push({ name: nameCandidate, sets: sets || 3, reps: reps || 8 });
                if (results.length >= 8)
                    break; // cap hard at 8 to avoid overfilling
            }
            if (results.length)
                return results.slice(0, 8);
            for (const l of lines) {
                // Supported patterns:
                // "1. Benkpress – 3x8", "- Knebøy 4 x 6", "Roing: 3 sett x 10 reps"
                // Norwegian: "3 sett med 8–10 repetisjoner"
                const p1 = l.match(new RegExp(`\\d+\\.?\\s*(${nameGroup})\\s*[–-]\\s*(\\d{1,2})\\s*[x×]\\s*(\\d{1,2})`, 'i'));
                const p2 = l.match(new RegExp(`[-•]\\s*(${nameGroup})\\s*(\\d{1,2})\\s*[x×]\\s*(\\d{1,2})`, 'i'));
                const p3 = l.match(new RegExp(`(${nameGroup}):?\\s*(\\d{1,2})\\s*(?:sett|set)\\s*[x×]\\s*(\\d{1,2})\\s*(?:reps|repetisjoner)?`, 'i'));
                const p4 = l.match(new RegExp(`(${nameGroup})\\s*[:\u2013\u2014-]?\\s*(?:[-•]\\s*)?(\\d{1,2})\\s*(?:sett|set)\\s*(?:med\\s*)?(\\d{1,2})(?:[–-]\\d{1,2})?\\s*(?:reps|repetisjoner)?`, 'i'));
                const m = p1 || p2 || p3 || p4;
                if (m) {
                    const name = m[1].trim();
                    const sets = Number(m[2]) || 3;
                    const reps = Number(m[3]) || 8;
                    if (!banned.test(name))
                        results.push({ name, sets, reps });
                    continue;
                }
                // Fallback: detect simple exercise name with leading bullet/number
                const nameOnly = l.match(new RegExp(`(?:\\d+\.|[-•])\\s*(${nameGroup})`));
                if (nameOnly) {
                    const nm = nameOnly[1].trim();
                    if (!banned.test(nm) && nm.length > 2)
                        results.push({ name: nm, sets: 3, reps: 8 });
                }
            }
            // If no structured strength exercises were parsed, return empty list
            // (e.g., cardio or mobility days should not be populated with defaults)
            return results.slice(0, 8);
        }
        // Prefer splitting by explicit Norwegian weekday headers if present
        const normalized = rawText.replace(/\r/g, '');
        const lineSplit = normalized.split(/\n/);
        const dayBlocks = [];
        let current = null;
        function normalizeAscii(s) {
            return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        }
        function detectHeader(line) {
            const trimmed = (line || '').trim().replace(/^[#*>-]\s*/, '');
            if (!trimmed)
                return null;
            const parts = trimmed.split(':');
            const head = parts[0].trim();
            const headAscii = normalizeAscii(head.toLowerCase());
            const map = {
                mandag: 'Mandag', tirsdag: 'Tirsdag', onsdag: 'Onsdag', torsdag: 'Torsdag', fredag: 'Fredag', lordag: 'Lørdag', sondag: 'Søndag',
                monday: 'Monday', tuesday: 'Tuesday', wednesday: 'Wednesday', thursday: 'Thursday', friday: 'Friday', saturday: 'Saturday', sunday: 'Sunday',
            };
            for (const key of Object.keys(map)) {
                if (headAscii.startsWith(key)) {
                    return { dayName: map[key], header: trimmed };
                }
            }
            return null;
        }
        for (const rawLine of lineSplit) {
            const h = detectHeader(rawLine);
            if (h) {
                if (current)
                    dayBlocks.push(current);
                current = { dayName: h.dayName, header: h.header, lines: [] };
            }
            else if (current) {
                current.lines.push(rawLine);
            }
        }
        if (current)
            dayBlocks.push(current);
        // Fallback: block-based regex capture across the whole text
        if (dayBlocks.length < 2) {
            const re = new RegExp(String.raw `(^\s*(?:[#*>-]\s*)?(Mandag|Tirsdag|Onsdag|Torsdag|Fredag|L(?:ø|o)rdag|S(?:ø|o)ndag|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s*:?.*$)([\s\S]*?)(?=^\s*(?:[#*>-]\s*)?(?:Mandag|Tirsdag|Onsdag|Torsdag|Fredag|L(?:ø|o)rdag|S(?:ø|o)ndag|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s*:?.*$|$)`, 'gmi');
            const blocksRx = [];
            let mm;
            while ((mm = re.exec(normalized)) != null) {
                const dayName = mm[2];
                const header = mm[1].trim();
                const body = (mm[3] || '').split(/\n/);
                blocksRx.push({ dayName, header, lines: body });
            }
            if (blocksRx.length >= 2) {
                dayBlocks.length = 0;
                dayBlocks.push(...blocksRx);
            }
        }
        // Last-resort fallback: direct index scanning for weekday words (Nor/Eng)
        if (dayBlocks.length < 2) {
            const candidates = [
                'Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag', 'Søndag',
                'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday',
            ];
            const found = [];
            const lower = normalized.toLowerCase();
            for (const label of candidates) {
                const key = label.toLowerCase().replace('ø', 'o');
                // search for both exact and ascii-folded
                let i = 0;
                let last = -1;
                while ((i = lower.indexOf(key, last + 1)) !== -1) {
                    // ensure word boundary
                    const before = i > 0 ? lower[i - 1] : '\n';
                    const okBoundary = /[^a-zæøå]/i.test(before);
                    if (okBoundary)
                        found.push({ idx: i, label });
                    last = i;
                }
            }
            found.sort((a, b) => a.idx - b.idx);
            // merge consecutive duplicates and build blocks
            const unique = [];
            for (const p of found) {
                if (!unique.length || p.idx - unique[unique.length - 1].idx > 3)
                    unique.push(p);
            }
            if (unique.length >= 2) {
                dayBlocks.length = 0;
                for (let i = 0; i < unique.length; i++) {
                    const start = unique[i].idx;
                    const end = i + 1 < unique.length ? unique[i + 1].idx : normalized.length;
                    const slice = normalized.slice(start, end).split(/\n/);
                    dayBlocks.push({ dayName: unique[i].label, header: slice[0] || unique[i].label, lines: slice.slice(1) });
                }
            }
        }
        function mapDayNameToCode(name) {
            const n = name.toLowerCase();
            if (n.startsWith('man') || n.startsWith('mon'))
                return 'Mon';
            if (n.startsWith('tir') || n.startsWith('tue'))
                return 'Tue';
            if (n.startsWith('ons') || n.startsWith('wed'))
                return 'Wed';
            if (n.startsWith('tor') || n.startsWith('thu'))
                return 'Thu';
            if (n.startsWith('fre') || n.startsWith('fri'))
                return 'Fri';
            if (n.startsWith('lør') || n.startsWith('lor') || n.startsWith('sat'))
                return 'Sat';
            if (n.startsWith('søn') || n.startsWith('son') || n.startsWith('sun'))
                return 'Sun';
            return 'Mon';
        }
        // Build sessions from weekday splits; otherwise fall back to Dag-splits or single block
        let sessions = (dayBlocks.length ? dayBlocks : [])
            .map((db) => {
            // Extract simple focus from header after ':' if present
            const afterColon = db.header.split(':').slice(1).join(':').trim();
            const focus = afterColon || pickFocus[0];
            const bodyWithoutHeader = db.lines.join('\n');
            // Collect per-day notes (non-strength lines)
            const notes = db.lines
                .map(l => String(l || '').trim())
                .filter(Boolean)
                .filter(l => !/(\d{1,2})\s*(?:sett|set|x|×)/i.test(l))
                .filter(l => !/^\d+\./.test(l));
            return {
                day: mapDayNameToCode(db.dayName),
                focus,
                exercises: extractExercises(bodyWithoutHeader),
                notes,
            };
        });
        if (!sessions.length) {
            const sourceBlocks = (blocks.length ? blocks : [rawText]).slice(0, 7);
            sessions = sourceBlocks
                .map((block, i) => ({
                day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i % 7],
                focus: pickFocus[i % pickFocus.length],
                exercises: extractExercises(block),
                notes: [],
            }));
        }
        if (sessions.length === 0) {
            sessions.push({
                day: 'Mon',
                focus: pickFocus[0],
                exercises: extractExercises(rawText),
                notes: [],
            });
        }
        // Extract high-level guidelines from the text
        const guidelineLines = rawText.split(/\n/)
            .map(l => l.trim())
            .filter(l => /^[-•]\s/.test(l) && /(oppvarming|nedtrapping|restitusjon|lytt til kroppen|tips|notater)/i.test(l))
            .map(l => l.replace(/^[-•]\s*/, ''))
            .slice(0, 10);
        const latest = await PlanModels_1.TrainingPlan.findOne({ userId }).sort({ version: -1 });
        const nextVersion = ((latest === null || latest === void 0 ? void 0 : latest.version) || 0) + 1;
        await PlanModels_1.TrainingPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
        const created = await PlanModels_1.TrainingPlan.create({ userId, version: nextVersion, isCurrent: true, sessions, sourceText: rawText, guidelines: guidelineLines });
        return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'training', planId: String(created._id) }], message: 'Training plan imported to Assets' });
    }
    catch (e) {
        console.error('[nutrition/from-text] failed', e);
        const msg = typeof (e === null || e === void 0 ? void 0 : e.message) === 'string' ? e.message : 'unknown';
        return res.status(500).json({ message: 'import failed', error: msg });
    }
});
// Save training plan (create new version)
InteractionRoutes.post('/chat/engh/training/save', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c, _d;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const sessions = Array.isArray((_c = req.body) === null || _c === void 0 ? void 0 : _c.sessions) ? req.body.sessions : [];
        if (!sessions.length)
            return res.status(400).json({ message: 'sessions required' });
        // Map sessions to versioning model shape
        const days = sessions.map((s) => ({ day: s.day, focus: s.focus, exercises: (s.exercises || []).map((e) => ({ name: e.name || e.exercise, sets: e.sets, reps: String(e.reps), rpe: e.rpe })) }));
        const version = await (0, nextVersion_1.nextTrainingVersion)(userId);
        const doc = await TrainingPlanVersion_1.default.create({ user: userId, version, source: 'action', reason: 'Saved via chat', days });
        await StudentState_1.default.findOneAndUpdate({ user: userId }, { $set: { currentTrainingPlanVersion: doc._id } }, { upsert: true });
        try {
            await ChangeEvent_1.default.create({ user: userId, type: 'PLAN_EDIT', summary: `Training v${version} saved`, refId: doc._id, actor: (_d = req === null || req === void 0 ? void 0 : req.user) === null || _d === void 0 ? void 0 : _d._id, after: { version } });
        }
        catch { }
        try {
            await (0, publish_1.publish)({ type: 'PLAN_UPDATED', user: userId });
        }
        catch { }
        return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'training', planId: String(doc._id) }], message: 'Training plan saved' });
    }
    catch (e) {
        return res.status(500).json({ message: 'save failed' });
    }
});
// Save nutrition plan (create new version)
InteractionRoutes.post('/chat/engh/nutrition/save', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const { dailyTargets } = req.body || {};
        if (!dailyTargets)
            return res.status(400).json({ message: 'dailyTargets required' });
        const version = await (0, nextVersion_1.nextNutritionVersion)(userId);
        const doc = await NutritionPlanVersion_1.default.create({ user: userId, version, source: 'action', reason: 'Saved via chat', kcal: dailyTargets.kcal, proteinGrams: dailyTargets.protein, carbsGrams: dailyTargets.carbs, fatGrams: dailyTargets.fat });
        await StudentState_1.default.findOneAndUpdate({ user: userId }, { $set: { currentNutritionPlanVersion: doc._id } }, { upsert: true });
        try {
            await ChangeEvent_1.default.create({ user: userId, type: 'NUTRITION_EDIT', summary: `Nutrition v${version} saved`, refId: doc._id, actor: (_c = req === null || req === void 0 ? void 0 : req.user) === null || _c === void 0 ? void 0 : _c._id, after: { version } });
        }
        catch { }
        try {
            await (0, publish_1.publish)({ type: 'NUTRITION_UPDATED', user: userId });
        }
        catch { }
        return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'nutrition', planId: String(doc._id) }], message: 'Meal plan saved' });
    }
    catch (e) {
        return res.status(500).json({ message: 'save failed' });
    }
});
// Public share endpoints (JSON)
InteractionRoutes.get('/plans/share/training/:id', async (req, res) => {
    try {
        const plan = await PlanModels_1.TrainingPlan.findById(req.params.id).lean();
        if (!plan)
            return res.status(404).json({ message: 'not found' });
        return res.json({ plan });
    }
    catch {
        return res.status(500).json({ message: 'share failed' });
    }
});
InteractionRoutes.get('/plans/share/nutrition/:id', async (req, res) => {
    try {
        const plan = await PlanModels_1.NutritionPlan.findById(req.params.id).lean();
        if (!plan)
            return res.status(404).json({ message: 'not found' });
        return res.json({ plan });
    }
    catch {
        return res.status(500).json({ message: 'share failed' });
    }
});
// Create nutrition plan from free-form text
InteractionRoutes.post('/chat/engh/nutrition/from-text', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c, _d;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const text = (((_c = req.body) === null || _c === void 0 ? void 0 : _c.text) || '')
            .replace(/<br\s*\/?>(?=\S)/gi, '\n')
            .replace(/\r/g, '');
        // Robust: try common patterns first; then derive macros if absent
        const kcal = Number((text.match(/(\d{3,4})\s*(?:kcal|kalorier)/i) || [])[1]) || 2400;
        const pMatch = text.match(/protein[^\d]*(\d{2,4})\s*(?:g|gram)?/i);
        const cMatch = text.match(/(?:carb|karb|karbo)[^\d]*(\d{2,4})\s*(?:g|gram)?/i);
        const fMatch = text.match(/(?:fett|fat)[^\d]*(\d{2,4})\s*(?:g|gram)?/i);
        let protein = pMatch ? Number(pMatch[1]) : undefined;
        let carbs = cMatch ? Number(cMatch[1]) : undefined;
        let fat = fMatch ? Number(fMatch[1]) : undefined;
        if (protein == null || carbs == null || fat == null) {
            // derive using 30/50/20 split
            protein = protein !== null && protein !== void 0 ? protein : Math.round((kcal * 0.3) / 4);
            carbs = carbs !== null && carbs !== void 0 ? carbs : Math.round((kcal * 0.5) / 4);
            fat = fat !== null && fat !== void 0 ? fat : Math.round((kcal * 0.2) / 9);
        }
        // Parse simple meals per day and extract guidelines
        // Support Norwegian (Dag) and English (Day)
        // Normalize section markers separating days (--- lines) to ensure splits don't swallow content
        const normalized = text
            .replace(/\r/g, '')
            .replace(/\n\s*---+\s*\n/g, '\n')
            .replace(/^\s*#\s*$/gm, '')
            .replace(/\*\*/g, ''); // strip bold markers so labels match
        // First pass: simple day + "- Meal: item" parser (matches your sample exactly)
        const weekdayLabels = ['Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag', 'Søndag', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        const weekdayRe = new RegExp(`^\s*(?:#{0,6}\s*)?(?:${weekdayLabels.join('|')})\s*$`, 'i');
        const mealLineRe = /^\s*-\s*(Frokost|Lunsj|Middag|Snack|Breakfast|Lunch|Dinner)\s*:\s*(.+)\s*$/i;
        const canon = (n) => (/^Breakfast$/i.test(n) ? 'Frokost' : /^Lunch$/i.test(n) ? 'Lunsj' : /^Dinner$/i.test(n) ? 'Middag' : n);
        const daysParsed = [];
        (function trySimpleScan() {
            const lines = normalized.split(/\n/);
            let currentDay = null;
            const map = {};
            for (const raw of lines) {
                const line = String(raw || '').trim();
                if (!line)
                    continue;
                if (weekdayRe.test(line)) {
                    currentDay = line.replace(/^#+\s*/, '');
                    if (!map[currentDay])
                        map[currentDay] = [];
                    continue;
                }
                const mm = line.match(mealLineRe);
                if (mm && currentDay) {
                    const label = canon(mm[1]);
                    const content = mm[2].trim();
                    if (content) {
                        let entry = map[currentDay].find(m => m.name.toLowerCase() === label.toLowerCase());
                        if (!entry) {
                            entry = { name: label, items: [] };
                            map[currentDay].push(entry);
                        }
                        entry.items.push(content);
                    }
                }
            }
            const keys = Object.keys(map);
            // Only adopt this pass if at least one meal was actually captured
            const hasAnyMeals = keys.some(k => (map[k] || []).length > 0);
            if (keys.length && hasAnyMeals) {
                daysParsed.length = 0;
                for (const k of keys)
                    daysParsed.push({ label: k, meals: map[k] });
            }
        })();
        // Support markdown headings like "#### Day 1" or plain "Day 1"
        const daySplits = normalized.split(/\n\s*#{0,6}\s*(?:Dag|Day)\s*(\d+)\b[^\n]*\n/i);
        // Meal parsing helpers
        const mealHeaderOnlyRe = /^(?:\s*#{0,6}\s*)?\s*(?:[-•]\s*)?(?:\*\*\s*)?(Frokost|Lunsj|Middag|Snack|Breakfast|Lunch|Dinner)(?:\s*\*\*)?\s*:?\s*$/i;
        const mealHeaderWithContentRe = /^(?:\s*#{0,6}\s*)?\s*(?:[-•]\s*)?(?:\*\*\s*)?(Frokost|Lunsj|Middag|Snack|Breakfast|Lunch|Dinner)(?:\s*\*\*)?\s*:?\s*(.+)$/i;
        const dayHeaderRe = /^\s*#{0,6}\s*(?:Dag\s*\d+|Day\s*\d+|Mandag|Tirsdag|Onsdag|Torsdag|Fredag|L(?:ø|o)rdag|S(?:ø|o)ndag)\b.*$/i;
        function parseMealsFromBlock(block) {
            const lines = String(block).split(/\n/);
            const result = [];
            let current = null;
            let buf = [];
            let preHeaderBuf = [];
            let seenHeader = false;
            const commit = () => { if (current && buf.length) {
                result.push({ name: current, items: [...buf] });
            } buf = []; };
            for (let raw of lines) {
                const rawStr = String(raw || '');
                const line = rawStr.replace(/^\s*[-•]\s*/, '').trim();
                if (!line)
                    continue;
                if (/^\s*#{1,6}\s/.test(rawStr)) { // generic markdown heading like ### Matplan
                    // Treat as a separator within the day: end any current meal and continue
                    commit();
                    current = null;
                    continue;
                }
                if (dayHeaderRe.test(line)) {
                    commit();
                    current = null;
                    continue;
                }
                const hc = line.match(mealHeaderWithContentRe);
                if (hc) { // header and content on same line
                    if (!seenHeader && preHeaderBuf.length && !result.some(m => /^Frokost$/i.test(m.name))) {
                        result.push({ name: 'Frokost', items: [...preHeaderBuf] });
                        preHeaderBuf = [];
                    }
                    seenHeader = true;
                    commit();
                    current = canon(hc[1]);
                    const firstItem = hc[2].replace(/^\*\*\s*|\s*\*\*$/g, '').trim();
                    if (firstItem)
                        buf.push(firstItem);
                    continue;
                }
                const ho = line.match(mealHeaderOnlyRe);
                if (ho) {
                    if (!seenHeader && preHeaderBuf.length && !result.some(m => /^Frokost$/i.test(m.name))) {
                        result.push({ name: 'Frokost', items: [...preHeaderBuf] });
                        preHeaderBuf = [];
                    }
                    seenHeader = true;
                    commit();
                    current = canon(ho[1]);
                    continue;
                }
                if (!current) {
                    // Only treat pre-header content as Frokost if it looks like likely food items
                    const isBullet = /^\s*(?:[-•*–]\s*|\d+\.\s*)/.test(rawStr);
                    if (!isBullet)
                        continue; // skip non-bullets until a meal header
                    if (!seenHeader) {
                        const looksFood = /(,|\d)|\b(havre|havregryn|grøt|grot|egg|yoghurt|brød|brod|knekkebrød|knekkebrod|ost|skyr|smoothie|bær|baer|frukt|banan|korn|gryn)\b/i.test(line);
                        if (looksFood)
                            preHeaderBuf.push(line);
                    }
                    continue;
                }
                // Strip leftover bold markers
                const cleaned = line.replace(/^\*\*\s*|\s*\*\*$/g, '');
                if (cleaned)
                    buf.push(cleaned);
            }
            commit();
            if (!seenHeader && preHeaderBuf.length && !result.some(m => /^Frokost$/i.test(m.name))) {
                result.push({ name: 'Frokost', items: [...preHeaderBuf] });
            }
            // Ensure unique meal names preserve first occurrence order
            const seen = new Set();
            let out = result.filter(m => (seen.has(m.name) ? false : (seen.add(m.name), true)));
            // Final fallback: if no explicit Frokost was captured, scan lines to collect it
            if (!out.some(m => /^Frokost$/i.test(m.name))) {
                const reHeader = /^(?:\s*#{0,6}\s*)?\s*(?:[-•]\s*)?(?:\*\*\s*)?(Frokost)(?:\s*\*\*)?\s*:?\s*(.*)$/i;
                let foundIdx = -1;
                let first = '';
                for (let i = 0; i < lines.length; i++) {
                    const rawStr = String(lines[i] || '');
                    const line = rawStr.replace(/^\s*[-•]\s*/, '').trim();
                    const m = line.match(reHeader);
                    if (m) {
                        foundIdx = i;
                        first = (m[2] || '').trim();
                        break;
                    }
                }
                if (foundIdx >= 0) {
                    const items = [];
                    if (first)
                        items.push(first);
                    for (let j = foundIdx + 1; j < lines.length; j++) {
                        const rawStr = String(lines[j] || '');
                        const asLine = rawStr.replace(/^\s*[-•]\s*/, '').trim();
                        if (!asLine)
                            continue;
                        if (dayHeaderRe.test(asLine))
                            break;
                        if (mealHeaderOnlyRe.test(asLine) || mealHeaderWithContentRe.test(asLine))
                            break;
                        const cleaned = asLine.replace(/^\*\*\s*|\s*\*\*$/g, '');
                        items.push(cleaned);
                    }
                    if (items.length)
                        out = [{ name: 'Frokost', items }, ...out];
                }
            }
            return out;
        }
        const meals = [];
        if (daySplits.length > 1) {
            const parsedByIndex = [];
            for (let i = 1; i < daySplits.length; i += 2) {
                const label = `Dag ${daySplits[i]}`;
                const block = (daySplits[i + 1] || '').split(/\n\s*#?\s*(?:Dag|Day)\s*\d+[^\n]*\n/i)[0];
                const dayMeals = parseMealsFromBlock(block);
                if (dayMeals.length)
                    parsedByIndex.push({ label, meals: dayMeals });
            }
            if (parsedByIndex.length) {
                daysParsed.length = 0;
                daysParsed.push(...parsedByIndex);
            }
        }
        else {
            // Try splitting by Norwegian weekday headings (Mandag, Tirsdag, ...)
            const weekRe = /^\s*#{0,6}\s*(Mandag|Tirsdag|Onsdag|Torsdag|Fredag|L(?:ø|o)rdag|S(?:ø|o)ndag)\s*:?.*$/gmi;
            const positions = [];
            let mm;
            while ((mm = weekRe.exec(normalized)) !== null) {
                positions.push({ idx: (_d = mm.index) !== null && _d !== void 0 ? _d : 0, label: mm[1], header: mm[0] });
            }
            if (positions.length) {
                const parsedByWeek = [];
                for (let i = 0; i < positions.length; i++) {
                    const start = positions[i].idx + positions[i].header.length;
                    const end = i + 1 < positions.length ? positions[i + 1].idx : normalized.length;
                    const body = normalized.slice(start, end);
                    const dayMeals = parseMealsFromBlock(body);
                    if (dayMeals.length)
                        parsedByWeek.push({ label: positions[i].label, meals: dayMeals });
                }
                if (parsedByWeek.length) {
                    if (!daysParsed.length || daysParsed.every(d => (d.meals || []).length === 0)) {
                        daysParsed.length = 0;
                        daysParsed.push(...parsedByWeek);
                    }
                }
            }
            // single generic block → collect meals without day labels
            meals.push(...parseMealsFromBlock(text));
        }
        // Extract global guidelines (outside day sections) so they don't get merged into any day's Snack
        const guidelines = normalized.split(/\n/)
            .map(l => l.trim())
            .filter(l => /^[-•]\s/.test(l) && /(Hydrering|Husk|Juster|Justering|Variasjon|Varier|Forberedelse|General\s*Tips|Generelle\s*Tips|Hvis du har)/i.test(l))
            .map(l => l.replace(/^[-•]\s*/, ''));
        // If no explicit day sections were found but a single-day meal list exists,
        // duplicate that template across all 7 days so the UI shows a full week.
        if (!daysParsed.length && meals.length) {
            const cloneMeals = (arr) => arr.map(m => ({ name: m.name, items: [...m.items] }));
            const labels = ['Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag', 'Søndag'];
            for (const label of labels) {
                daysParsed.push({ label, meals: cloneMeals(meals) });
            }
        }
        const latest = await PlanModels_1.NutritionPlan.findOne({ userId }).sort({ version: -1 });
        const nextVersion = ((latest === null || latest === void 0 ? void 0 : latest.version) || 0) + 1;
        await PlanModels_1.NutritionPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
        const created = await PlanModels_1.NutritionPlan.create({ userId, version: nextVersion, isCurrent: true, dailyTargets: { kcal, protein, carbs, fat }, notes: '', sourceText: text, meals: meals.length ? meals : undefined, guidelines, days: daysParsed.length ? daysParsed : undefined });
        return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'nutrition', planId: String(created._id) }], message: 'Meal plan imported to Assets' });
    }
    catch (e) {
        console.error('[nutrition/from-text] failed', e);
        return res.status(500).json({ message: 'import failed' });
    }
});
// Create simple goal from free-form text
InteractionRoutes.post('/chat/engh/goals/from-text', Middlewares_1.Auth, (0, rateLimiters_1.perUserIpLimiter)({ windowMs: 60000, max: Number(process.env.RATE_LIMIT_ACTIONS_PER_MIN || 30) }), async (req, res) => {
    var _a, _b, _c, _d;
    try {
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        if (!userId)
            return res.status(400).json({ message: 'userId required' });
        const text = (((_c = req.body) === null || _c === void 0 ? void 0 : _c.text) || '').replace(/\r/g, '');
        const targetWeight = Number((text.match(/(\d{2,3})\s*kg/i) || [])[1]) || undefined;
        const strength = (text.match(/(benk|knebøy|kneboy|mark|markløft|styrke)[^\n]*/i) || [])[0] || '';
        const horizon = Number((text.match(/(\d{1,2})\s*(?:uker|weeks|mnd|måneder|months)/i) || [])[1]) || 8;
        const deficit = Number((text.match(/(\d{3,4})\s*kcal[^\n]*(?:defisit|underskudd)/i) || [])[1]) || undefined;
        const weeklyLoss = Number((text.match(/(0?\.\d|\d)\s*kg\s*(?:per\s*uke|\/?week)/i) || [])[1]) || undefined;
        const weeklyMinutes = Number((text.match(/(\d{2,3})\s*min(?:utter)?\s*(?:per\s*uke|\/?week)/i) || [])[1]) || undefined;
        const hydration = Number((text.match(/(\d(?:\.\d)?)\s*l(?:iter)?/i) || [])[1]) || undefined;
        function collectSection(labels) {
            var _a, _b, _c;
            // Build a combined heading regex that tolerates optional colon and parentheses
            const heading = new RegExp(`^(?:${labels.map(l => l.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join('|')})\b[^\n]*$`, 'i+m');
            const match = text.match(heading);
            if (!match)
                return [];
            const startIdx = (_a = match.index) !== null && _a !== void 0 ? _a : 0;
            // Slice from the end of the matched heading line
            const after = text.slice(startIdx + match[0].length);
            // Stop at next heading of any known type
            const stopper = new RegExp(`\n\s*(?=^(?:Kortsiktige mål|Kort sikt|Mellomlangsiktige mål|Mellomlang sikt|Langsiktige mål|Lang sikt|Short\s*-?\s*Term|Medium\s*-?\s*Term|Long\s*-?\s*Term|Tips(?:\s*for\s*å\s*oppnå\s*målene)?|Generelle mål)\b)`, 'i+m');
            const body = (after.split(stopper)[0] || '').trim();
            // Extract list items (bullets or enumerated)
            const lines = body.split(/\n/).map(l => l.trim()).filter(Boolean);
            const items = [];
            for (const l of lines) {
                const bullet = l.replace(/^[-•]\s*/, '').trim();
                const enumerated = (_c = (_b = l.match(/^\d+\.?\s+(.*)$/)) === null || _b === void 0 ? void 0 : _b[1]) === null || _c === void 0 ? void 0 : _c.trim();
                const candidate = (enumerated || bullet).replace(/^\*+|\*+$/g, '').trim();
                if (candidate)
                    items.push(candidate);
            }
            return items.slice(0, 12);
        }
        const shortTerm = collectSection(['Kortsiktige mål', 'Kort sikt', 'Short Term', 'Short-Term']);
        const mediumTerm = collectSection(['Mellomlangsiktige mål', 'Mellomlang sikt', 'Medium Term', 'Medium-Term']);
        const longTerm = collectSection(['Langsiktige mål', 'Lang sikt', 'Long Term', 'Long-Term']);
        const tipsA = collectSection(['Tips for å oppnå målene', 'Tips', 'Additional Tips']);
        const tipsB = collectSection(['Generelle mål']);
        const unique = (arr) => Array.from(new Set(arr.map(s => s.trim()))).filter(Boolean);
        const plan = {
            shortTerm,
            mediumTerm,
            longTerm,
            tips: unique([...(tipsA || []), ...(tipsB || [])]),
        };
        const latest = await PlanModels_1.Goal.findOne({ userId }).sort({ version: -1 });
        const nextVersion = ((latest === null || latest === void 0 ? void 0 : latest.version) || 0) + 1;
        await PlanModels_1.Goal.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
        const created = await PlanModels_1.Goal.create({ userId, version: nextVersion, isCurrent: true, targetWeightKg: targetWeight, strengthTargets: strength, horizonWeeks: horizon, sourceText: text, caloriesDailyDeficit: deficit, weeklyWeightLossKg: weeklyLoss, weeklyExerciseMinutes: weeklyMinutes, hydrationLiters: hydration, plan });
        try {
            await ChangeEvent_1.default.create({ user: userId, type: 'GOAL_EDIT', summary: 'Goal imported from text', actor: (_d = req === null || req === void 0 ? void 0 : req.user) === null || _d === void 0 ? void 0 : _d._id, after: { goalId: created._id, version: nextVersion } });
            await (0, publish_1.publish)({ type: 'GOAL_UPDATED', user: userId });
        }
        catch { }
        return res.json({ actions: [{ type: 'GOAL_SET', goalId: String(created._id) }], message: 'Goal imported to Assets' });
    }
    catch (e) {
        return res.status(500).json({ message: 'import failed' });
    }
});
//# sourceMappingURL=interaction.routes.js.map