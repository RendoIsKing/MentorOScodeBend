"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserProfileSchema = void 0;
const mongoose_1 = require("mongoose");
exports.UserProfileSchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true, unique: true },
    goals: String,
    currentWeightKg: Number,
    strengths: String,
    weaknesses: String,
    injuryHistory: String,
    nutritionPreferences: String,
    trainingDaysPerWeek: Number,
}, { timestamps: true });
//# sourceMappingURL=UserProfileSchema.js.map