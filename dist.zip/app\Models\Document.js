"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Document = void 0;
const mongoose_1 = require("mongoose");
const DocumentSchema_1 = require("../../database/schemas/DocumentSchema");
const Document = (0, mongoose_1.model)('Document', DocumentSchema_1.DocumentSchema);
exports.Document = Document;
//# sourceMappingURL=Document.js.map