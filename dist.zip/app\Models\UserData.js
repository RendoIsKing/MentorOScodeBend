"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserData = void 0;
const mongoose_1 = require("mongoose");
const userDataSchema_1 = require("../../database/schemas/userDataSchema");
const UserData = (0, mongoose_1.model)("UserData", userDataSchema_1.UserDataSchema);
exports.UserData = UserData;
//# sourceMappingURL=UserData.js.map