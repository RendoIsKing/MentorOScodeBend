"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidDateFormat = void 0;
const isValidDateFormat = (dateString) => {
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(dateString);
};
exports.isValidDateFormat = isValidDateFormat;
//# sourceMappingURL=isValidDate.js.map