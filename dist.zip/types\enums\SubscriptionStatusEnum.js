"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionStatusEnum = void 0;
var SubscriptionStatusEnum;
(function (SubscriptionStatusEnum) {
    SubscriptionStatusEnum["INACTIVE"] = "inactive";
    SubscriptionStatusEnum["ACTIVE"] = "active";
    SubscriptionStatusEnum["PAUSED"] = "paused";
    SubscriptionStatusEnum["CANCEL"] = "cancelled";
})(SubscriptionStatusEnum || (exports.SubscriptionStatusEnum = SubscriptionStatusEnum = {}));
//# sourceMappingURL=SubscriptionStatusEnum.js.map