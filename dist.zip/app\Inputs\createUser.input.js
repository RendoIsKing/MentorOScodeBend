"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserInput = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class Location {
}
__decorate([
    (0, class_validator_1.IsNumber)({}, { message: "Latitude must be a number." }),
    (0, class_validator_1.IsNotEmpty)({ message: "Latitude is required." }),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], Location.prototype, "lat", void 0);
__decorate([
    (0, class_validator_1.IsNumber)({}, { message: "Longitude must be a number." }),
    (0, class_validator_1.IsNotEmpty)({ message: "Longitude is required." }),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], Location.prototype, "long", void 0);
class UserInput {
}
exports.UserInput = UserInput;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Full name should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "fullName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Username should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "userName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Instagram link should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "instagramLink", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Facebook link should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "facebookLink", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "TikTok link should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "tiktokLink", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "password should be string" }),
    __metadata("design:type", String)
], UserInput.prototype, "password", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "YouTube link should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "youtubeLink", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Bio should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "bio", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Gender should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "gender", void 0);
__decorate([
    (0, class_validator_1.IsOptional)()
    // @IsDate()
    // @IsDateString({ message: "Date of birth should be a valid date string." })
    ,
    __metadata("design:type", String)
], UserInput.prototype, "dob", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "Email should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "email", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "PhotoId should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "photoId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: "CoverPhoto should be a string." }),
    __metadata("design:type", String)
], UserInput.prototype, "coverPhotoId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)({ message: "Location should be an array." }),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => Location),
    __metadata("design:type", Array)
], UserInput.prototype, "location", void 0);
//# sourceMappingURL=createUser.input.js.map