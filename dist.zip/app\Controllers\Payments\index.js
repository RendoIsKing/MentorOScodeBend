"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const createSessionAction_1 = require("./Actions/createSessionAction");
class PaymentsController {
    static createSession(req, res) {
        return (0, createSessionAction_1.createSessionAction)(req, res);
    }
    static async status(req, res) {
        try {
            // @ts-ignore
            const user = req.user;
            if (!user)
                return res.status(401).json({ error: { message: 'Unauthorized' } });
            const active = String(user.status || '').toUpperCase() === 'SUBSCRIBED';
            return res.json({ active });
        }
        catch (e) {
            return res.status(500).json({ error: { message: 'status failed' } });
        }
    }
}
exports.default = PaymentsController;
//# sourceMappingURL=index.js.map