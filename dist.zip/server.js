"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Server = void 0;
const express_1 = __importDefault(require("express"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const passport_1 = __importDefault(require("passport"));
const cors_1 = __importDefault(require("cors"));
const dbConnection_1 = require("./utils/dbConnection");
require("reflect-metadata");
//************* */
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
//***********8 */
const routes_1 = require("./routes");
const strategies_1 = require("./utils/strategies");
const Middlewares_1 = require("./app/Middlewares");
const requireEntitlement_1 = require("./app/Middlewares/requireEntitlement");
const FileEnum_1 = require("./types/FileEnum");
const post_routes_1 = __importDefault(require("./routes/post.routes"));
const interaction_routes_1 = __importDefault(require("./routes/interaction.routes"));
const preonboarding_1 = __importDefault(require("./routes/preonboarding"));
const legal_routes_1 = __importDefault(require("./routes/legal.routes"));
const account_routes_1 = __importDefault(require("./routes/account.routes"));
const loginAs_1 = __importDefault(require("./routes/dev/loginAs"));
const dev_bootstrap_1 = __importDefault(require("./routes/dev.bootstrap"));
const snapshot_1 = __importDefault(require("./routes/student/snapshot"));
const handlePaymentStatusStripeWebhook_1 = require("./app/Controllers/CardDetails/Actions/handlePaymentStatusStripeWebhook");
const download_router_1 = __importDefault(require("./routes/download.router"));
const chat_1 = __importDefault(require("./routes/chat"));
const conversations_1 = __importDefault(require("./routes/conversations"));
const chat_stream_1 = __importDefault(require("./routes/chat.stream"));
const dev_seed_1 = __importDefault(require("./routes/dev.seed"));
const expireDataSets_1 = require("./utils/scheduledJobs/expireDataSets");
const express_session_1 = __importDefault(require("express-session"));
const snapshot_reconciler_1 = require("./jobs/snapshot.reconciler");
const sentry_1 = require("./observability/sentry");
const logging_1 = require("./observability/logging");
const health_1 = __importDefault(require("./routes/health"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const ensureIndexes_1 = require("./utils/ensureIndexes");
const version = "0.0.1";
//*********** */
// Define the path to the 'public' directory
const publicDir = path_1.default.join(__dirname, "../public");
//**********8 */
//*************** */
// Function to create the 'public' directory if it doesn't exist
const createPublicDirectory = () => {
    if (!fs_1.default.existsSync(publicDir)) {
        fs_1.default.mkdirSync(publicDir, { recursive: true }); // Create the directory, including parent directories if necessary
        console.log(`'public' directory created at: ${publicDir}`);
    }
    else {
        console.log(`'public' directory already exists.`);
    }
};
//*************** */
class Server {
    // Note: http server handle removed (unused)
    constructor(port) {
        this.app = (0, express_1.default)();
        this.port = port;
        // Ensure database connection established early
        try {
            void (0, dbConnection_1.connectDatabase)();
        }
        catch { }
        // Log dev login flag at boot for clarity
        try {
            console.log('[BOOT] DEV_LOGIN_ENABLED =', process.env.DEV_LOGIN_ENABLED);
        }
        catch { }
        this.registerPreRoutes();
        this.registerMiddlewares();
        this.initializePassportAndStrategies();
        this.regsiterRoutes();
        // Ensure indexes in background (non-blocking)
        (0, ensureIndexes_1.ensureIndexes)().catch(() => { });
        if (process.env.NODE_ENV !== 'test')
            (0, snapshot_reconciler_1.startSnapshotReconciler)();
        (0, expireDataSets_1.expireDataSetCronJob)();
        // this.start()
        console.log(port);
        console.log(`HTTP Application server ready to be started at ${this.port}`);
    }
    registerPreRoutes() {
        this.app.post("/api/v1/handlePaymentStripe", express_1.default.raw({ type: "*/*", limit: "50mb" }), handlePaymentStatusStripeWebhook_1.handlePaymentStatusWebhookStripe);
    }
    registerMiddlewares() {
        // Serve static uploads; prefer UPLOAD_ROOT when provided (e.g., Railway volume for persistence)
        const uploadRoot = process.env.UPLOAD_ROOT
            ? path_1.default.isAbsolute(process.env.UPLOAD_ROOT)
                ? process.env.UPLOAD_ROOT
                : path_1.default.join(process.cwd(), process.env.UPLOAD_ROOT)
            : `${process.cwd()}${FileEnum_1.FileEnum.PUBLICDIR}`;
        // Handle legacy path-based media URLs by redirecting/serving dynamically
        // e.g. /api/backend/profile-image/<fileName>
        try {
            // Lazy require AWS SDK to avoid hard dependency in local dev
            const Aws = (() => {
                try {
                    return {
                        S3Client: require("@aws-sdk/client-s3").S3Client,
                        GetObjectCommand: require("@aws-sdk/client-s3").GetObjectCommand,
                        getSignedUrl: require("@aws-sdk/s3-request-presigner").getSignedUrl,
                    };
                }
                catch {
                    return null;
                }
            })();
            this.app.get("/api/backend/profile-image/:name", async (req, res) => {
                var _a;
                const fileName = String(((_a = req.params) === null || _a === void 0 ? void 0 : _a.name) || "");
                const key = `profile-image/${fileName}`;
                const useS3 = String(process.env.MEDIA_STORAGE || "").toLowerCase() === "s3";
                if (useS3 && Aws) {
                    try {
                        const region = process.env.S3_REGION || process.env.AWS_REGION || "eu-north-1";
                        const accessKeyId = process.env.S3_ACCESS_KEY || process.env.AWS_ACCESS_KEY_ID;
                        const secretAccessKey = process.env.S3_SECRET_KEY || process.env.AWS_SECRET_ACCESS_KEY;
                        const bucket = process.env.S3_BUCKET;
                        if (bucket && accessKeyId && secretAccessKey) {
                            const s3 = new Aws.S3Client({ region, credentials: { accessKeyId, secretAccessKey } });
                            const cmd = new Aws.GetObjectCommand({ Bucket: bucket, Key: key });
                            const signed = await Aws.getSignedUrl(s3, cmd, { expiresIn: 60 * 10 });
                            return res.redirect(302, signed);
                        }
                    }
                    catch { }
                }
                // Local/persistent disk fallback
                const tryFiles = [];
                if (uploadRoot)
                    tryFiles.push(path_1.default.join(uploadRoot, key));
                tryFiles.push(path_1.default.join(process.cwd(), 'public', key));
                tryFiles.push(path_1.default.join(__dirname, '../public', key));
                for (const fp of tryFiles) {
                    try {
                        if (fs_1.default.existsSync(fp)) {
                            return res.sendFile(fp);
                        }
                    }
                    catch { }
                }
                // Final fallback: send placeholder to avoid broken UI
                try {
                    return res.redirect(302, '/assets/images/Home/small-profile-img.svg');
                }
                catch {
                    return res.status(404).end();
                }
            });
        }
        catch { }
        if (uploadRoot) {
            try {
                console.log('[STATIC] uploadRoot =', uploadRoot);
            }
            catch { }
            this.app.use("/api/backend", express_1.default.static(uploadRoot));
        }
        // Also serve from both CWD/public and dist-relative public to survive different runtimes
        this.app.use("/api/backend", express_1.default.static(`${process.cwd()}${FileEnum_1.FileEnum.PUBLICDIR}`));
        this.app.use("/api/backend", express_1.default.static(path_1.default.join(__dirname, "../public")));
        this.app.use(express_1.default.json({ limit: "50mb" }));
        this.app.use(express_1.default.urlencoded({ limit: "50mb", extended: true }));
        // Allow assets to be embedded across subdomains (www.mentorio.no → api.mentorio.no)
        this.app.use((0, helmet_1.default)({
            // Allow assets from api.mentorio.no to be embedded on www.mentorio.no
            crossOriginResourcePolicy: { policy: 'cross-origin' },
            crossOriginEmbedderPolicy: false,
        }));
        this.app.use((0, compression_1.default)());
        (0, sentry_1.initSentry)(this.app);
        this.app.use(logging_1.withRequestId, logging_1.httpLogger);
        // Prefer CORS_ALLOW_ORIGINS; fall back to FRONTEND_ORIGIN for backward compatibility
        const allowedOrigins = (process.env.CORS_ALLOW_ORIGINS || process.env.FRONTEND_ORIGIN || 'http://localhost:3002,http://192.168.1.244:3002')
            .split(',')
            .map(s => s.trim())
            .filter(Boolean);
        console.log('[CORS] Allowed origins:', allowedOrigins);
        const devOpenCors = process.env.DEV_LOGIN_ENABLED === 'true' && process.env.NODE_ENV !== 'production';
        if (devOpenCors) {
            // In dev, accept any origin and send credentials for convenience
            this.app.use((0, cors_1.default)({ origin: true, credentials: true }));
        }
        else {
            this.app.use((0, cors_1.default)({ origin: (origin, cb) => {
                    if (!origin)
                        return cb(null, true);
                    if (allowedOrigins.includes(origin))
                        return cb(null, true);
                    return cb(new Error('CORS'));
                }, credentials: true }));
        }
        const isProd = process.env.NODE_ENV === 'production';
        const trustProxy = (process.env.TRUST_PROXY || (isProd ? '1' : '0')).trim();
        if (trustProxy === '1' || trustProxy.toLowerCase() === 'true') {
            // Trust proxy for secure cookies on Railway/managed platforms
            this.app.set('trust proxy', 1);
        }
        const sameSiteEnv = String(process.env.SESSION_SAMESITE || '').toLowerCase();
        const cookieSameSite = sameSiteEnv === 'none' ? 'none' : 'lax';
        const secureEnv = String(process.env.SESSION_SECURE || (isProd ? 'true' : 'false')).toLowerCase();
        const cookieSecure = secureEnv === 'true' || secureEnv === '1';
        this.app.use((0, express_session_1.default)({
            secret: process.env.SESSION_SECRET || 'dev_session_secret_change_me',
            resave: false,
            saveUninitialized: false,
            cookie: { httpOnly: true, sameSite: cookieSameSite, secure: cookieSecure, maxAge: 1000 * 60 * 60 * 24 * 30 }
        }));
        if (isProd && process.env.DEV_LOGIN_ENABLED === 'true') {
            console.warn('[WARN] DEV_LOGIN_ENABLED=true in production – dev routes should be disabled');
        }
        // Rate limiting
        // General limiter for backend routes, but skip auth endpoints and streaming
        const generalLimiter = (0, express_rate_limit_1.default)({
            windowMs: 60000,
            max: Number(process.env.RL_GENERAL_MAX || 600),
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => {
                const p = req.path || '';
                // Skip auth endpoints; they have their own dedicated limiter
                if (p.startsWith('/v1/auth'))
                    return true;
                // Skip event streams (long-lived)
                if (p.includes('/events/stream'))
                    return true;
                return false;
            },
        });
        this.app.use('/api/backend', generalLimiter);
    }
    regsiterRoutes() {
        // Lightweight healthcheck for platforms
        this.app.get('/healthz', (_req, res) => res.status(200).json({ ok: true }));
        this.app.get("/api", (req, res) => {
            res.status(200).json({ message: `App running on version ${version}` });
        });
        this.app.get("/api/backend", (req, res) => {
            res
                .status(200)
                .json({ message: `App running on version ${version}. api/backend` });
        });
        this.app.use(express_1.default.static("public"));
        this.app.use('/api/backend', health_1.default);
        this.app.use('/', legal_routes_1.default);
        this.app.use('/api/backend/v1', account_routes_1.default);
        // Dedicated limiter for auth POST endpoints only (do NOT count /auth/me or other GETs)
        const authPostLimiter = (0, express_rate_limit_1.default)({
            windowMs: 60000,
            max: Number(process.env.RL_AUTH_LOGIN_MAX || 30),
            standardHeaders: true,
            legacyHeaders: false,
            skip: (req) => req.method !== 'POST',
        });
        // Apply only to login endpoints; mount limiter before the auth router
        this.app.use("/api/backend/v1/auth/user-login", authPostLimiter);
        this.app.use("/api/backend/v1/auth/google", authPostLimiter);
        // Mount remaining auth routes without limiter so /auth/me isn't rate-limited
        this.app.use("/api/backend/v1/auth", routes_1.AuthRoutes);
        this.app.use("/api/backend/v1/profile", Middlewares_1.Auth, routes_1.ProfileRoutes);
        this.app.use("/api/backend/v1/user", routes_1.UserRoutes);
        this.app.use("/api/backend/v1/module", Middlewares_1.OnlyAdmins, routes_1.ModuleRoutes);
        this.app.use("/api/backend/v1/category", Middlewares_1.Auth, routes_1.CategoryRoutes);
        this.app.use("/api/backend/v1/post", post_routes_1.default);
        this.app.use("/api/backend/v1/documents", Middlewares_1.Auth, routes_1.DocumentRoutes);
        this.app.use("/api/backend/v1/interests", Middlewares_1.Auth, routes_1.InterestRoutes);
        // Public for now: Coach Engh chatbot and knowledge endpoints
        this.app.use("/api/backend/v1/interaction", interaction_routes_1.default);
        const devOn = (String(process.env.DEV_LOGIN_ENABLED || '').trim().toLowerCase() === 'true') || (process.env.NODE_ENV !== 'production');
        if (devOn) {
            try {
                console.log('[DEV] Enabling /api/backend/v1/dev/* routes');
            }
            catch { }
            this.app.use("/api/backend/v1", loginAs_1.default);
            this.app.use("/api/backend/v1", dev_bootstrap_1.default);
        }
        else {
            try {
                console.log('[DEV] Dev routes disabled');
            }
            catch { }
        }
        this.app.use("/api/backend/v1/plans", Middlewares_1.Auth, routes_1.SubscriptionPlanRoutes);
        this.app.use("/api/backend/v1/user-connections", Middlewares_1.Auth, routes_1.ConnectionRoutes);
        this.app.use("/api/backend/v1/payment", Middlewares_1.Auth, routes_1.PaymentRoutes);
        this.app.use("/api/backend/v1/stats", routes_1.StatsRoutes);
        // Student routes must be accessible with cookie-based auth inside the route (no bearer required)
        this.app.use("/api/backend/v1/student", routes_1.StudentRoutes);
        this.app.use("/api/backend/v1/student", snapshot_1.default);
        // Public features list to allow subscription UI to load without auth
        this.app.use("/api/backend/v1/feature", routes_1.FeatureRoutes);
        this.app.use("/api/backend/v1/card-details", routes_1.CardDetailsRoutes);
        this.app.use("/api/backend/v1/subscriptions", Middlewares_1.Auth, routes_1.SubscriptionRoutes);
        this.app.use("/api/backend/v1/support", Middlewares_1.Auth, routes_1.SupportRoutes);
        this.app.use("/api/backend/v1/transactions", Middlewares_1.Auth, routes_1.TransactionRoutes);
        this.app.use("/api/backend/v1/notifications", Middlewares_1.Auth, routes_1.NotificationRoutes);
        this.app.use("/api/backend/v1/more-actions", Middlewares_1.Auth, requireEntitlement_1.requireEntitlement, routes_1.moreActionRoutes);
        this.app.use("/api/backend/v1/process-data", Middlewares_1.Auth, routes_1.userDataRoutes);
        this.app.use("/api/backend/v1/preonboarding", preonboarding_1.default);
        this.app.use('/api/backend/v1/chat', chat_1.default);
        this.app.use('/api/backend/v1/chat', conversations_1.default);
        this.app.use('/api/backend/v1', chat_stream_1.default);
        this.app.use('/api/backend/v1', dev_seed_1.default);
        this.app.use("/", download_router_1.default);
    }
    initializePassportAndStrategies() {
        this.app.use(passport_1.default.initialize());
        passport_1.default.use(strategies_1.local);
        passport_1.default.use(strategies_1.jwt);
    }
    start() {
        const http = require("http").createServer(this.app);
        // *********
        createPublicDirectory();
        // *********
        http.listen(this.port, () => {
            console.log(`:rocket: HTTP Server started at port ${this.port}`);
        });
        // http.listen(3001, () => {
        //   console.log(`:rocket: HTTP Server started at port 3001`);
        // });
    }
}
exports.Server = Server;
//# sourceMappingURL=server.js.map