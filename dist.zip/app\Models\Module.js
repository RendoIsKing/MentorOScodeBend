"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Module = void 0;
const mongoose_1 = require("mongoose");
const ModuleSchema_1 = require("../../database/schemas/ModuleSchema");
const Module = (0, mongoose_1.model)('Module', ModuleSchema_1.ModuleSchema);
exports.Module = Module;
//# sourceMappingURL=Module.js.map