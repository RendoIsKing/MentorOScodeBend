"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatMessage = exports.ChatThread = void 0;
const mongoose_1 = require("mongoose");
const ChatThreadSchema_1 = require("../../database/schemas/ChatThreadSchema");
const ChatMessageSchema_1 = require("../../database/schemas/ChatMessageSchema");
const ChatThread = (0, mongoose_1.model)('ChatThread', ChatThreadSchema_1.ChatThreadSchema);
exports.ChatThread = ChatThread;
const ChatMessage = (0, mongoose_1.model)('ChatMessage', ChatMessageSchema_1.ChatMessageSchema);
exports.ChatMessage = ChatMessage;
//# sourceMappingURL=ChatModels.js.map