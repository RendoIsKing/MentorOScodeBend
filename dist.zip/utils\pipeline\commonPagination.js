"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.commonPaginationPipeline = void 0;
const commonPaginationPipeline = (page, perPage, 
//   defaultPerPage: number,
skip) => {
    //   const pipeline: PipelineStage[] =;
    return [
        {
            $facet: {
                metaData: [
                    { $count: "total" },
                    { $addFields: { page, perPage: perPage } },
                    {
                        $addFields: {
                            pageCount: {
                                $ceil: {
                                    $divide: ["$total", perPage],
                                },
                            },
                        },
                    },
                ],
                data: [{ $skip: skip }, { $limit: perPage }],
            },
        },
    ];
};
exports.commonPaginationPipeline = commonPaginationPipeline;
//# sourceMappingURL=commonPagination.js.map