"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const acceptTos_1 = require("../app/Controllers/Legal/acceptTos");
const r = (0, express_1.Router)();
// Dev mailer abstraction
async function sendMail(to, subject, text) {
    if (process.env.NODE_ENV !== 'production') {
        // eslint-disable-next-line no-console
        console.log(`[MAIL] to=${to} subject=${subject} text=${text}`);
        return true;
    }
    // TODO: integrate Postmark/Mailgun
    return true;
}
r.post('/account/request-deletion', Middlewares_1.Auth, async (req, res) => {
    try {
        const me = req.user;
        await sendMail(process.env.SUPPORT_EMAIL || 'support@example.com', 'Account Deletion Request', `User ${(me === null || me === void 0 ? void 0 : me.email) || (me === null || me === void 0 ? void 0 : me._id)} requested deletion.`);
        return res.json({ ok: true });
    }
    catch {
        return res.status(500).json({ error: { message: 'request failed' } });
    }
});
r.post('/account/request-export', Middlewares_1.Auth, async (req, res) => {
    try {
        const me = req.user;
        await sendMail(process.env.SUPPORT_EMAIL || 'support@example.com', 'Data Export Request', `User ${(me === null || me === void 0 ? void 0 : me.email) || (me === null || me === void 0 ? void 0 : me._id)} requested export.`);
        return res.json({ ok: true });
    }
    catch {
        return res.status(500).json({ error: { message: 'request failed' } });
    }
});
exports.default = r;
// Legal acceptance
r.post('/legal/accept', Middlewares_1.Auth, acceptTos_1.acceptTos);
//# sourceMappingURL=account.routes.js.map