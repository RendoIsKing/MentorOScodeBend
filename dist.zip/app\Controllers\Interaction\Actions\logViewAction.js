"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logView = void 0;
const Post_1 = require("../../../Models/Post");
const Interaction_1 = require("../../../Models/Interaction");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const logView = async (req, res) => {
    const user = req.user;
    const { postId } = req.body;
    if (!postId) {
        return res.status(400).json({ error: { message: "Post Id is required" } });
    }
    try {
        const post = await Post_1.Post.findById(postId);
        if (!post) {
            return res.status(404).json({ error: { message: "Post not found" } });
        }
        const view = await Interaction_1.Interaction.create({
            user: post.user,
            post: postId,
            type: InteractionTypeEnum_1.InteractionType.VIEW,
            interactedBy: user.id,
        });
        return res.json({
            data: view,
            message: "View logged",
        });
    }
    catch (error) {
        console.log("error in logging view", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.logView = logView;
//# sourceMappingURL=logViewAction.js.map