"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const passport_jwt_1 = require("passport-jwt");
const options = {
    secretOrKey: process.env.APP_SECRET || process.env.JWT_SECRET || 'dev_session_secret_change_me',
    jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
};
exports.default = new passport_jwt_1.Strategy(options, (payload, done) => {
    try {
        if (!payload) {
            return done(null, false);
        }
        return done(null, payload);
    }
    catch (error) {
        return done(error, false);
    }
});
//# sourceMappingURL=jwt.js.map