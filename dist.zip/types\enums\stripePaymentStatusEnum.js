"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STRIPE_PAYMENT_STATUS = void 0;
exports.STRIPE_PAYMENT_STATUS = {
    SUCCESS: "payment_intent.succeeded",
    FAILED: "payment_intent.payment_failed",
    INITIATED: "payment_intent.created",
};
//# sourceMappingURL=stripePaymentStatusEnum.js.map