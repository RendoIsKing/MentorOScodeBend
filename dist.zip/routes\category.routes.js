"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Controllers_1 = require("../app/Controllers/");
const Middlewares_1 = require("../app/Middlewares");
const category = (0, express_1.Router)();
category.get("/", Controllers_1.CategoryController.index);
category.get("/:id", Controllers_1.CategoryController.show);
category.post("/", Middlewares_1.OnlyAdmins, Controllers_1.CategoryController.create);
category.put("/:id", Middlewares_1.OnlyAdmins, Controllers_1.CategoryController.update);
category.delete("/:id", Middlewares_1.OnlyAdmins, Controllers_1.CategoryController.destroy);
category.post("/sub-category", Middlewares_1.OnlyAdmins, Controllers_1.CategoryController.createSubCategory);
exports.default = category;
//# sourceMappingURL=category.routes.js.map