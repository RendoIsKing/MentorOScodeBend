"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const compression_server_1 = require("./compression.server");
describe('HTTP compression', () => {
    it('serves gzip when client accepts it and reduces size', async () => {
        const app = (0, compression_server_1.createTestApp)();
        const res = await (0, supertest_1.default)(app)
            .get('/big')
            .set('Accept-Encoding', 'gzip');
        expect(res.status).toBe(200);
        // compression should set content-encoding
        expect(res.header['content-encoding']).toBeDefined();
        expect(res.header['content-encoding']).toMatch(/gzip|br|deflate/);
        // ensure body length is smaller than raw 5000 bytes
        const contentLength = parseInt(res.header['content-length'] || '0', 10);
        if (!Number.isNaN(contentLength) && contentLength > 0) {
            expect(contentLength).toBeLessThan(5000);
        }
        else {
            // some servers use chunked encoding; still OK as long as encoding header exists
            expect(true).toBe(true);
        }
    });
});
//# sourceMappingURL=compression.spec.js.map