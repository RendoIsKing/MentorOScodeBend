"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Controllers_1 = require("../app/Controllers/");
// import { FileEnum } from "../types/FileEnum";
// import { createMulterInstance } from '../app/Middlewares/fileUpload';
const profile = (0, express_1.Router)();
// const upload = createMulterInstance(
//     `${process.cwd()}${FileEnum.PUBLICDIR}${FileEnum.PROFILEIMAGE}`
//   );
profile.post('/change-password', Controllers_1.ProfileController.changePassword);
// profile.post('/update-profile', upload.single('image'), ProfileController.updateProfile);
exports.default = profile;
//# sourceMappingURL=profile.routes.js.map