"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toggleFollow = void 0;
const class_transformer_1 = require("class-transformer");
const createFollowInput_1 = require("../Inputs/createFollowInput");
const Connection_1 = require("../../../Models/Connection");
const class_validator_1 = require("class-validator");
const User_1 = require("../../../Models/User");
const notificationService_1 = require("../../../../utils/Notifications/notificationService");
const FirebaseNotificationEnum_1 = require("../../../../types/enums/FirebaseNotificationEnum");
const saveNotification_1 = require("../../Notifications/Actions/saveNotification");
const toggleFollow = async (req, res) => {
    try {
        const user = req.user;
        const createFollowInput = (0, class_transformer_1.plainToClass)(createFollowInput_1.FollowInput, req.body);
        const validationErrors = await (0, class_validator_1.validate)(createFollowInput);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        const followExists = await Connection_1.userConnection.findOne({
            owner: user.id,
            followingTo: createFollowInput.followingTo,
        });
        if (followExists) {
            await Connection_1.userConnection.deleteOne({ _id: followExists.id });
            return res.json({
                message: "Account Unfollowed",
            });
        }
        const newFollow = await Connection_1.userConnection.create({
            owner: user.id,
            followingTo: createFollowInput.followingTo,
        });
        try {
            const followedUser = await User_1.User.findById(createFollowInput.followingTo);
            if (followedUser && followedUser.fcm_token) {
                const notificationToken = followedUser.fcm_token;
                if (notificationToken) {
                    const notificationTitle = "New Follower";
                    const notificationDescription = `${user.userName} is now following you`;
                    await (0, notificationService_1.sendNotification)(notificationToken, notificationTitle, notificationDescription, FirebaseNotificationEnum_1.FirebaseNotificationEnum.FOLLOW, user.userName);
                    await (0, saveNotification_1.saveNotification)({
                        title: notificationTitle,
                        description: notificationDescription,
                        sentTo: [followedUser._id],
                        type: FirebaseNotificationEnum_1.FirebaseNotificationEnum.FOLLOW,
                        notificationOnPost: null,
                        notificationFromUser: user.id
                    });
                }
                else {
                    console.error("FCM token for the user not found");
                }
            }
        }
        catch (error) {
            console.log("Error sending follow notification", error);
        }
        return res.json({
            data: newFollow,
            message: "You are now following this account",
        });
    }
    catch (error) {
        console.error("Error following account:", error);
        if (error.code === 11000) {
            return res.status(500).json({
                error: { message: "You are already following this account", error },
            });
        }
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.toggleFollow = toggleFollow;
//# sourceMappingURL=ToggleFollowAction.js.map