"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.kcalFrom = kcalFrom;
exports.macrosFrom = macrosFrom;
exports.generateDeterministicPreview = generateDeterministicPreview;
const crypto_1 = __importDefault(require("crypto"));
const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
function subForInjury(name, injuries = []) {
    if (injuries.includes("knee")) {
        if (/squat/i.test(name))
            return { name: "Leg Press", rationale: "Knee-friendly swap for Squat" };
        if (/lunge/i.test(name))
            return { name: "Step-ups", rationale: "Reduced knee shear vs Lunges" };
    }
    return { name };
}
function baseExercises(exp) {
    const ex = [
        { name: "Back Squat", sets: 3, reps: "8-10", rpe: "7-8" },
        { name: "Bench Press", sets: 3, reps: "6-8", rpe: "7-8" },
        { name: "Lat Pulldown", sets: 3, reps: "10-12", rpe: "7-8" },
    ];
    if (exp === "beginner")
        return ex;
    if (exp === "intermediate")
        return [...ex, { name: "Romanian Deadlift", sets: 3, reps: "6-8", rpe: "7-8" }];
    return [...ex, { name: "Romanian Deadlift", sets: 4, reps: "5-7", rpe: "8" }];
}
function kcalFrom(profile) {
    var _a;
    const bw = (_a = profile === null || profile === void 0 ? void 0 : profile.bodyWeightKg) !== null && _a !== void 0 ? _a : 70;
    const mult = (profile === null || profile === void 0 ? void 0 : profile.goals) === "cut" ? 28 : (profile === null || profile === void 0 ? void 0 : profile.goals) === "gain" ? 33 : 30;
    return Math.round(bw * mult);
}
function macrosFrom(profile, kcal) {
    var _a;
    const bw = (_a = profile === null || profile === void 0 ? void 0 : profile.bodyWeightKg) !== null && _a !== void 0 ? _a : 70;
    const proteinPerKg = (profile === null || profile === void 0 ? void 0 : profile.diet) === "vegan" ? 2.2 : 2.0;
    const protein = Math.round(bw * proteinPerKg);
    const kcalAfterProtein = Math.max(kcal - protein * 4, 0);
    const carbs = Math.round((kcalAfterProtein * 0.55) / 4);
    const fat = Math.round((kcalAfterProtein * 0.45) / 9);
    return { proteinGrams: protein, carbsGrams: carbs, fatGrams: fat };
}
function generateDeterministicPreview({ userId, profile }) {
    var _a, _b;
    const p = profile || {};
    const exp = (_a = p === null || p === void 0 ? void 0 : p.experienceLevel) !== null && _a !== void 0 ? _a : "beginner";
    const injuries = (_b = p === null || p === void 0 ? void 0 : p.injuries) !== null && _b !== void 0 ? _b : [];
    const days = dayNames.map((d, i) => {
        if (exp === "beginner") {
            if ([0, 2, 4].includes(i)) {
                const ex = baseExercises(exp).map(e => {
                    const swap = subForInjury(e.name, injuries);
                    return { ...e, name: swap.name, rationale: swap.rationale };
                });
                return { day: d, focus: "Full Body", exercises: ex };
            }
            if ([1, 5].includes(i))
                return { day: d, focus: "Cardio (Zone 2) 25–35min" };
            return { day: d, focus: "Rest / Mobility 10–15min" };
        }
        const full = baseExercises(exp).map(e => {
            const swap = subForInjury(e.name, injuries);
            return { ...e, name: swap.name, rationale: swap.rationale };
        });
        const focus = i % 2 === 0 ? "Upper" : "Lower";
        return { day: d, focus, exercises: full };
    });
    const kcal = kcalFrom(p);
    const macros = macrosFrom(p, kcal);
    const nutrition = {
        kcal,
        ...macros,
        rationale: (p === null || p === void 0 ? void 0 : p.diet) === "vegan"
            ? "Protein set to ~2.2g/kg for plant-based completeness."
            : "Protein set to ~2.0g/kg; carbs/fat split 55/45 for adherence.",
    };
    const raw = JSON.stringify({
        userId,
        exp,
        injuries: [...injuries].sort(),
        goals: p === null || p === void 0 ? void 0 : p.goals,
        diet: p === null || p === void 0 ? void 0 : p.diet,
        weight: p === null || p === void 0 ? void 0 : p.bodyWeightKg,
        days,
        nutrition,
    });
    const hash = crypto_1.default.createHash("sha256").update(raw).digest("hex");
    return { user: p.user, trainingWeek: days, nutrition, hash };
}
//# sourceMappingURL=generatePlanPreview.js.map