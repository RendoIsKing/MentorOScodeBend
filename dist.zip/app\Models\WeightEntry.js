"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WeightEntry = void 0;
const mongoose_1 = require("mongoose");
const WeightEntrySchema_1 = require("../../database/schemas/WeightEntrySchema");
const WeightEntry = (0, mongoose_1.model)('WeightEntry', WeightEntrySchema_1.WeightEntrySchema);
exports.WeightEntry = WeightEntry;
//# sourceMappingURL=WeightEntry.js.map