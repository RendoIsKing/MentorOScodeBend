"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userActionType = void 0;
var userActionType;
(function (userActionType) {
    userActionType["REPORT"] = "report_user";
    userActionType["NOT_INTERESTED"] = "not_interested";
    userActionType["USER_QUERY"] = "user_query";
})(userActionType || (exports.userActionType = userActionType = {}));
//# sourceMappingURL=userActionTypeEnum.js.map