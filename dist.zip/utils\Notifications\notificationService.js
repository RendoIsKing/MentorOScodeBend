"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendNotification = void 0;
const firebaseConfig_1 = __importDefault(require("../firebaseConfig"));
const sendNotification = async (token, title, body, type, actionTo, data) => {
    const message = {
        // notification: {
        //   title,
        //   body,
        // },
        data: {
            ...data,
            title,
            body,
            type,
            actionTo,
        },
        token,
    };
    try {
        const response = await firebaseConfig_1.default.messaging().send(message);
        console.log("Successfully sent message:", response);
    }
    catch (error) {
        console.error("Error sending message:", error);
    }
};
exports.sendNotification = sendNotification;
//# sourceMappingURL=notificationService.js.map