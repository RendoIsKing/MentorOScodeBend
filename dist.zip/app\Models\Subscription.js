"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Subscription = void 0;
const mongoose_1 = require("mongoose");
const SubscriptionSchema_1 = require("../../database/schemas/SubscriptionSchema");
const Subscription = (0, mongoose_1.model)('Subscription', SubscriptionSchema_1.SubscriptionSchema);
exports.Subscription = Subscription;
//# sourceMappingURL=Subscription.js.map