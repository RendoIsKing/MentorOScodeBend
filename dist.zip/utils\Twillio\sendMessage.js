"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendMessage = void 0;
const twilio_1 = __importDefault(require("twilio"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const client = (0, twilio_1.default)(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const sendMessage = async (to, message) => {
    try {
        await client.messages.create({
            body: message,
            to: `+${to}`,
            from: process.env.TWILIO_FROM_NUMBER,
        });
        return true;
    }
    catch (error) {
        console.error("Error sending message:", error);
        return false;
    }
};
exports.sendMessage = sendMessage;
//# sourceMappingURL=sendMessage.js.map