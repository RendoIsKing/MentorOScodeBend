"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_KCAL = exports.MIN_KCAL = exports.MAX_LOAD_JUMP_PCT = exports.MAX_SET_JUMP_PCT = void 0;
exports.clampKcal = clampKcal;
exports.MAX_SET_JUMP_PCT = 0.2; // ≤20% volume increase per patch
exports.MAX_LOAD_JUMP_PCT = 0.075; // ≤7.5% via RPE/rep (heuristic)
exports.MIN_KCAL = 1200, exports.MAX_KCAL = 5000;
function clampKcal(k) {
    return Math.max(exports.MIN_KCAL, Math.min(exports.MAX_KCAL, Math.round(k)));
}
//# sourceMappingURL=safety.js.map