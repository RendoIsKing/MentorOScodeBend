"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionType = void 0;
var TransactionType;
(function (TransactionType) {
    TransactionType["DEPOSIT"] = "deposit";
    TransactionType["DEBIT"] = "debit";
    TransactionType["CREDIT"] = "credit";
    TransactionType["CARD_ADD"] = "card_add";
    TransactionType["PAYMENT_FAILED"] = "Payment Declined";
    TransactionType["PAYMENT_SUCCESS"] = "Payment Success";
})(TransactionType || (exports.TransactionType = TransactionType = {}));
//# sourceMappingURL=transactionTypeEnum.js.map