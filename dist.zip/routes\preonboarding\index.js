"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Profile_1 = __importDefault(require("../../models/Profile"));
const User_1 = require("../../app/Models/User");
const PlanPreview_1 = __importDefault(require("../../models/PlanPreview"));
const generatePlanPreview_1 = require("../../services/preview/generatePlanPreview");
const TrainingPlanVersion_1 = __importDefault(require("../../models/TrainingPlanVersion"));
const NutritionPlanVersion_1 = __importDefault(require("../../models/NutritionPlanVersion"));
const StudentState_1 = __importDefault(require("../../models/StudentState"));
const StudentSnapshot_1 = __importDefault(require("../../models/StudentSnapshot"));
const publish_1 = require("../../services/events/publish");
const ChangeEvent_1 = __importDefault(require("../../models/ChangeEvent"));
const r = (0, express_1.Router)();
function collectedPercentOf(p) {
    var _a;
    const total = 6;
    let have = 0;
    if (p === null || p === void 0 ? void 0 : p.goals)
        have++;
    if (p === null || p === void 0 ? void 0 : p.experienceLevel)
        have++;
    if (p === null || p === void 0 ? void 0 : p.bodyWeightKg)
        have++;
    if (p === null || p === void 0 ? void 0 : p.diet)
        have++;
    if ((_a = p === null || p === void 0 ? void 0 : p.schedule) === null || _a === void 0 ? void 0 : _a.daysPerWeek)
        have++;
    if (Array.isArray(p === null || p === void 0 ? void 0 : p.injuries))
        have++;
    return Math.round((have / total) * 100);
}
r.post("/start", async (req, res) => {
    var _a;
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
    if (!userId)
        return res.status(401).json({ error: "Unauthorized" });
    const user = await User_1.User.findByIdAndUpdate(userId, { $set: { status: "VISITOR" } }, { new: true });
    let profile = await Profile_1.default.findOne({ user: userId });
    if (!profile)
        profile = await Profile_1.default.create({ user: userId });
    return res.json({
        ok: true,
        firstMessage: "Hei! Jeg er Coach Engh. Fortell meg kort hva du vil oppnå – så lager jeg et første forslag skreddersydd for deg.",
        status: user === null || user === void 0 ? void 0 : user.status,
    });
});
r.post("/message", async (req, res) => {
    var _a, _b;
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
    const { message, patch } = req.body;
    if (!userId)
        return res.status(401).json({ error: "Unauthorized" });
    let profile = await Profile_1.default.findOne({ user: userId });
    if (!profile)
        profile = await Profile_1.default.create({ user: userId });
    if ((patch === null || patch === void 0 ? void 0 : patch.injuries) && !(((_b = profile.consentFlags) === null || _b === void 0 ? void 0 : _b.healthData) === true)) {
        return res.status(400).json({ error: "Consent required to store injuries" });
    }
    await Profile_1.default.updateOne({ user: userId }, { $set: { ...patch } }, { upsert: true });
    profile = await Profile_1.default.findOne({ user: userId });
    const collected = collectedPercentOf(profile);
    await Profile_1.default.updateOne({ user: userId }, { $set: { collectedPercent: collected } });
    await User_1.User.updateOne({ _id: userId }, { $set: { status: "LEAD" } });
    let previewGenerated = false;
    if (collected >= 80) {
        const preview = (0, generatePlanPreview_1.generateDeterministicPreview)({ userId, profile });
        await PlanPreview_1.default.findOneAndUpdate({ user: userId }, { $set: preview }, { upsert: true });
        previewGenerated = true;
    }
    return res.json({
        ok: true,
        messageEcho: message,
        collectedPercent: collected,
        next: previewGenerated
            ? { type: "PREVIEW_READY", cta: ["BEGIN_TRIAL", "CHECKOUT"] }
            : { type: "QUESTION", prompt: "Hva veier du ca. nå, og hvor mange dager i uken ønsker du å trene?" },
    });
});
r.post("/consent", async (req, res) => {
    var _a;
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
    const { healthData } = req.body;
    if (!userId)
        return res.status(401).json({ error: "Unauthorized" });
    const now = new Date();
    await Profile_1.default.updateOne({ user: userId }, { $set: { "consentFlags.healthData": !!healthData, "consentFlags.timestamp": now } }, { upsert: true });
    return res.json({ ok: true, consented: !!healthData, timestamp: now.toISOString() });
});
r.get("/preview", async (req, res) => {
    var _a;
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.query.userId;
    if (!userId)
        return res.status(401).json({ error: "Unauthorized" });
    const preview = await PlanPreview_1.default.findOne({ user: userId });
    if (!preview)
        return res.status(404).json({ error: "No preview yet" });
    return res.json({ ok: true, preview });
});
r.post("/convert", async (req, res) => {
    var _a;
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
    const { planType } = req.body;
    if (!userId)
        return res.status(401).json({ error: "Unauthorized" });
    await User_1.User.updateOne({ _id: userId }, { $set: { status: planType === "TRIAL" ? "TRIAL" : "SUBSCRIBED" } });
    try {
        const preview = await PlanPreview_1.default.findOne({ user: userId }).lean();
        if (preview) {
            const tp = await TrainingPlanVersion_1.default.create({ user: userId, version: 1, source: "preview", reason: "Initialized from preview", days: preview.trainingWeek });
            const np = await NutritionPlanVersion_1.default.create({ user: userId, version: 1, source: "preview", reason: "Initialized from preview", kcal: preview.nutrition.kcal, proteinGrams: preview.nutrition.proteinGrams, carbsGrams: preview.nutrition.carbsGrams, fatGrams: preview.nutrition.fatGrams });
            await StudentState_1.default.findOneAndUpdate({ user: userId }, { $set: { currentTrainingPlanVersion: tp._id, currentNutritionPlanVersion: np._id } }, { upsert: true });
            // Build initial snapshot (idempotent: keep one per user)
            const daysPerWeek = Array.isArray(tp === null || tp === void 0 ? void 0 : tp.days) ? (tp.days.filter((d) => (d.exercises || []).length > 0).length || tp.days.length || 0) : 0;
            const snapshot = await StudentSnapshot_1.default.findOneAndUpdate({ user: userId }, {
                $setOnInsert: {
                    weightSeries: [],
                    trainingPlanSummary: { daysPerWeek },
                    nutritionSummary: { kcal: np === null || np === void 0 ? void 0 : np.kcal, protein: np === null || np === void 0 ? void 0 : np.proteinGrams, carbs: np === null || np === void 0 ? void 0 : np.carbsGrams, fat: np === null || np === void 0 ? void 0 : np.fatGrams },
                    kpis: { adherence7d: 0 },
                },
            }, { new: true, upsert: true });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: "PLAN_EDIT", summary: "Initialized from preview", refId: tp._id });
            }
            catch { }
            try {
                await ChangeEvent_1.default.create({ user: userId, type: "NUTRITION_EDIT", summary: "Initialized from preview", refId: np._id });
            }
            catch { }
            await (0, publish_1.publish)({ type: "PLAN_UPDATED", user: userId });
            await (0, publish_1.publish)({ type: "NUTRITION_UPDATED", user: userId });
            return res.status(200).json({ ok: true, activated: true, snapshotId: String((snapshot === null || snapshot === void 0 ? void 0 : snapshot._id) || "") });
        }
    }
    catch { }
    return res.json({ ok: true, activated: true });
});
// Dev/test helper: force entitlement and refresh session user
r.post("/force-sub", async (req, res) => {
    var _a;
    try {
        const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        await User_1.User.updateOne({ _id: userId }, { $set: { status: "SUBSCRIBED" } });
        try {
            // Reflect immediately in request context
            if (req.user)
                req.user.status = "SUBSCRIBED";
            // If using express-session, ensure session user id is set
            if (req.session) {
                req.session.user = { id: String(userId) };
            }
        }
        catch { }
        return res.json({ ok: true });
    }
    catch {
        return res.status(500).json({ error: "failed" });
    }
});
r.get("/state", async (req, res) => {
    var _a, _b, _c;
    const userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.query.userId;
    if (!userId)
        return res.status(401).json({ error: "Unauthorized" });
    const user = await User_1.User.findById(userId);
    const profile = await Profile_1.default.findOne({ user: userId });
    const preview = await PlanPreview_1.default.findOne({ user: userId });
    return res.json({
        ok: true,
        status: (_b = user === null || user === void 0 ? void 0 : user.status) !== null && _b !== void 0 ? _b : "VISITOR",
        collectedFieldsPercent: (_c = profile === null || profile === void 0 ? void 0 : profile.collectedPercent) !== null && _c !== void 0 ? _c : 0,
        previewReady: !!preview,
    });
});
exports.default = r;
//# sourceMappingURL=index.js.map