"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addNestedComment = void 0;
const Interaction_1 = require("../../../Models/Interaction"); // Update the import path as necessary
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const User_1 = require("../../../Models/User");
const notificationService_1 = require("../../../../utils/Notifications/notificationService");
const Post_1 = require("../../../Models/Post");
const FirebaseNotificationEnum_1 = require("../../../../types/enums/FirebaseNotificationEnum");
const addNestedComment = async (req, res) => {
    try {
        const { comment: childComment } = req.body;
        const parentCommentId = req.params.id;
        const user = req.user;
        const parentComment = await Interaction_1.Interaction.findById(parentCommentId);
        if (!parentComment) {
            return res
                .status(404)
                .json({ error: { message: "Parent comment not found" } });
        }
        if (parentComment.type !== InteractionTypeEnum_1.InteractionType.COMMENT) {
            return res.status(404).json({
                error: {
                    message: "You can only reply to a comment type interaction",
                },
            });
        }
        const newChildComment = new Interaction_1.Interaction({
            type: InteractionTypeEnum_1.InteractionType.COMMENT,
            post: parentComment.post,
            // user: parentComment.user,
            interactedBy: user._id,
            comment: childComment,
            isChildComment: true,
            isDeleted: false,
            parentComment: parentCommentId,
        });
        await newChildComment.save();
        if (!parentComment.replies) {
            parentComment.replies = [];
        }
        parentComment.replies.push(newChildComment._id);
        await parentComment.save();
        const updatedParentComment = await Interaction_1.Interaction.findById(parentCommentId)
            .populate({
            path: "replies",
            populate: {
                path: "interactedBy",
                select: "username",
            },
        })
            .exec();
        try {
            //notification to the user to whom the post belongs
            const post = await Post_1.Post.findOne({ id: parentComment.post });
            const postUser = await User_1.User.findById(post === null || post === void 0 ? void 0 : post.user);
            if (postUser && postUser.fcm_token) {
                const notificationToken = postUser.fcm_token;
                if (notificationToken) {
                    await (0, notificationService_1.sendNotification)(notificationToken, "New Comment on your post", `${user.userName} commented on your post`, FirebaseNotificationEnum_1.FirebaseNotificationEnum.COMMENT, postUser.userName);
                }
                else {
                    console.error("FCM token for the user not found");
                }
            }
            // Notification to the user who made the parent comment
            const parentCommentUser = await User_1.User.findById(parentComment.interactedBy);
            if (parentCommentUser && parentCommentUser.fcm_token) {
                const notificationToken = parentCommentUser.fcm_token;
                if (notificationToken) {
                    await (0, notificationService_1.sendNotification)(notificationToken, "New Reply to your comment", `${user.userName} replied to your comment`, FirebaseNotificationEnum_1.FirebaseNotificationEnum.COMMENT, parentCommentUser.userName);
                }
                else {
                    console.error("FCM token for the parent comment user not found");
                }
            }
        }
        catch (error) {
            console.log("Error sending like notification", error);
        }
        return res.json({
            data: updatedParentComment,
            message: "Child Comment added successfully",
        });
    }
    catch (error) {
        console.error("Error adding nested comment:", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.addNestedComment = addNestedComment;
//# sourceMappingURL=nestedCommentAction.js.map