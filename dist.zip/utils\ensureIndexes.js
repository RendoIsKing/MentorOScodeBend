"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensureIndexes = ensureIndexes;
/* Idempotent index creation for collections used by the app */
async function ensureIndexes() {
    try {
        const [{ User }] = await Promise.all([
            Promise.resolve().then(() => __importStar(require('../app/Models/User'))),
        ]);
        try {
            const coll = User.collection;
            // Inspect existing indexes
            let indexes = [];
            try {
                indexes = await coll.indexes();
            }
            catch { }
            const emailIdx = indexes.find((i) => (i === null || i === void 0 ? void 0 : i.name) === 'email_1');
            // If an email unique index exists without partial filter, drop it to avoid null duplicates
            if (emailIdx && !(emailIdx === null || emailIdx === void 0 ? void 0 : emailIdx.partialFilterExpression)) {
                try {
                    await coll.dropIndex('email_1');
                }
                catch { }
            }
            // Create partial unique index so only real strings are enforced
            try {
                await coll.createIndex({ email: 1 }, { unique: true, partialFilterExpression: { email: { $exists: true, $type: 'string' } } });
            }
            catch { }
        }
        catch { }
        // Ensure unique phone identity only when values exist to avoid partial duplicates
        try {
            await User.collection.createIndex({ completePhoneNumber: 1 }, { unique: true, partialFilterExpression: { completePhoneNumber: { $exists: true, $type: 'string' } } });
        }
        catch { }
        try {
            await User.collection.createIndex({ dialCode: 1, phoneNumber: 1 }, {
                unique: true,
                partialFilterExpression: { dialCode: { $exists: true, $type: 'string' }, phoneNumber: { $exists: true, $type: 'string' } },
            });
        }
        catch { }
    }
    catch { }
    try {
        const Post = (await Promise.resolve().then(() => __importStar(require('../app/Models/Post')))).Post;
        try {
            await Post.collection.createIndex({ createdAt: -1 });
        }
        catch { }
        try {
            await Post.collection.createIndex({ user: 1, createdAt: -1 });
        }
        catch { }
    }
    catch { }
    try {
        const WorkoutLog = (await Promise.resolve().then(() => __importStar(require('../models/WorkoutLog')))).default;
        try {
            await WorkoutLog.collection.createIndex({ user: 1, date: -1 });
        }
        catch { }
    }
    catch { }
    try {
        const StudentSnapshot = (await Promise.resolve().then(() => __importStar(require('../models/StudentSnapshot')))).default;
        try {
            await StudentSnapshot.collection.createIndex({ user: 1 }, { unique: true });
        }
        catch { }
    }
    catch { }
    try {
        const ChangeEvent = (await Promise.resolve().then(() => __importStar(require('../models/ChangeEvent')))).default;
        try {
            await ChangeEvent.collection.createIndex({ user: 1, createdAt: -1 });
        }
        catch { }
    }
    catch { }
}
//# sourceMappingURL=ensureIndexes.js.map