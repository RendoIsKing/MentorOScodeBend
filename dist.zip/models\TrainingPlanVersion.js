"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const TrainingPlanVersionSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    version: { type: Number, index: true, required: true },
    source: { type: String, enum: ["preview", "rule", "manual", "action"], default: "action" },
    reason: String,
    days: [{
            day: String,
            focus: String,
            exercises: [{ name: String, sets: Number, reps: String, rpe: String }]
        }]
}, { timestamps: true });
TrainingPlanVersionSchema.index({ user: 1, version: -1 }, { unique: true });
exports.default = (0, mongoose_1.model)("TrainingPlanVersion", TrainingPlanVersionSchema);
//# sourceMappingURL=TrainingPlanVersion.js.map