"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InterestSchema = void 0;
const mongoose_1 = require("mongoose");
const InterestSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: false,
    },
    slug: {
        type: String,
        required: false,
    },
    addedBy: {
        type: mongoose_1.Types.ObjectId,
        ref: "User",
    },
    isAvailable: {
        type: Boolean,
        default: true,
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
    deletedAt: {
        type: Date,
        default: null,
    },
}, { timestamps: true });
exports.InterestSchema = InterestSchema;
// import { Schema } from "mongoose";
// const InterestSchema = new Schema(
//   {
//     title: {
//       type: String,
//       required: true,
//     },
//     isDeleted: {
//       type: Boolean,
//       default: false,
//     },
//     deletedAt: {
//       type: Date,
//       default: null,
//     },
//   },
//   { timestamps: true }
// );
// export { InterestSchema };
//# sourceMappingURL=InterestSchema.js.map