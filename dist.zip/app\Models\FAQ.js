"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FAQ = void 0;
const mongoose_1 = require("mongoose");
const FAQSchema_1 = require("../../database/schemas/FAQSchema");
const FAQ = (0, mongoose_1.model)("FAQ", FAQSchema_1.FAQSchema);
exports.FAQ = FAQ;
//# sourceMappingURL=FAQ.js.map