"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initFirebaseTest = initFirebaseTest;
const firebase_admin_1 = __importDefault(require("firebase-admin"));
// Test-only initializer that reads credentials from env or uses ADC.
function initFirebaseTest() {
    if (!firebase_admin_1.default.apps.length) {
        const json = process.env.FIREBASE_SERVICE_ACCOUNT_JSON
            ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
            : undefined;
        firebase_admin_1.default.initializeApp({
            credential: json ? firebase_admin_1.default.credential.cert(json) : firebase_admin_1.default.credential.applicationDefault(),
        });
    }
    return firebase_admin_1.default;
}
exports.default = initFirebaseTest;
//# sourceMappingURL=firebaseConfig.test.js.map