"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolesEnum = void 0;
var RolesEnum;
(function (RolesEnum) {
    RolesEnum["USER"] = "user";
    RolesEnum["ADMIN"] = "admin";
})(RolesEnum || (exports.RolesEnum = RolesEnum = {}));
//# sourceMappingURL=RolesEnum.js.map