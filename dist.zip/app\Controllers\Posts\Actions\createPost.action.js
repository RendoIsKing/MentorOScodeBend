"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPostAction = void 0;
const class_transformer_1 = require("class-transformer");
const createPost_input_1 = require("../Inputs/createPost.input");
const class_validator_1 = require("class-validator");
const Post_1 = require("../../../Models/Post");
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const User_1 = require("../../../Models/User");
const privacyEnums_1 = require("../../../../types/enums/privacyEnums");
const createPayPerViewProductOnStripe_1 = require("../../../../utils/stripe/createPayPerViewProductOnStripe");
const stripeCurrency_1 = require("../../../../utils/consts/stripeCurrency");
const createPostAction = async (req, res) => {
    try {
        const user = req.user;
        const postInput = (0, class_transformer_1.plainToClass)(createPost_input_1.CreatePostDto, req.body);
        const errors = await (0, class_validator_1.validate)(postInput);
        if (errors.length) {
            const errorsInfo = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            return res
                .status(400)
                .json({ error: { message: "VALIDATIONS_ERROR", info: errorsInfo } });
        }
        if (postInput.userTags && postInput.userTags.length > 0) {
            const userIds = postInput.userTags.map((tag) => tag.userId);
            const uniqueUserIds = [...new Set(userIds)];
            const validUserIds = await User_1.User.find({ _id: { $in: uniqueUserIds }, deletedAt: null, isDeleted: false }, "_id").lean();
            if (validUserIds.length !== uniqueUserIds.length) {
                return res
                    .status(400)
                    .json({ error: { message: "One or more user IDs are invalid." } });
            }
        }
        let accessibleFeatures = [];
        if (postInput.planToAccess) {
            const subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.findOne({
                userId: user.id,
                title: postInput.planToAccess,
            });
            if (!subscriptionPlan) {
                return res
                    .status(400)
                    .json({ error: { message: "Invalid planToAccess value." } });
            }
            accessibleFeatures = subscriptionPlan.permissions.map((permission) => ({
                name: permission.feature,
                description: permission.description,
            }));
        }
        let stripePayperViewProduct;
        if (postInput.privacy == privacyEnums_1.Privacy.PAY_PER_VIEW) {
            stripePayperViewProduct = await (0, createPayPerViewProductOnStripe_1.createPayPerViewProductOnStripe)({
                title: "POST per view",
                description: postInput.content,
                stripe_currency: stripeCurrency_1.stripe_currency,
                price: +postInput.price,
            });
        }
        const post = await Post_1.Post.create({
            ...postInput,
            ...(stripePayperViewProduct
                ? {
                    stripeProductId: stripePayperViewProduct === null || stripePayperViewProduct === void 0 ? void 0 : stripePayperViewProduct.id,
                    stripePayperViewProduct,
                }
                : {}),
            ...(stripePayperViewProduct
                ? {
                    stripeProduct: stripePayperViewProduct,
                    stripePayperViewProduct,
                }
                : {}),
            //   content: postInput.content.map((content) => {
            //   }),
            user: user.id,
            accessibleTo: accessibleFeatures,
        });
        return res.status(201).json({ postId: String(post._id), data: post });
    }
    catch (error) {
        console.log("Error while posting content", error);
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.createPostAction = createPostAction;
//# sourceMappingURL=createPost.action.js.map