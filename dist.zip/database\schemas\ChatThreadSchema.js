"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatThreadSchema = void 0;
const mongoose_1 = require("mongoose");
exports.ChatThreadSchema = new mongoose_1.Schema({
    userId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    partner: { type: String, required: true },
}, { timestamps: true });
exports.ChatThreadSchema.index({ userId: 1, partner: 1 }, { unique: true });
//# sourceMappingURL=ChatThreadSchema.js.map