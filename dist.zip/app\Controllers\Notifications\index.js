"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationController = void 0;
// import { sendNotification } from "./Actions/saveNotification";
const getNotification_1 = require("./Actions/getNotification");
const deleteNotification_1 = require("./Actions/deleteNotification");
class NotificationController {
}
exports.NotificationController = NotificationController;
_a = NotificationController;
// static sendNotification = async (req: Request, res: Response) => {
//   return sendNotification(req, res);
// };
NotificationController.getNotifications = async (req, res) => {
    return (0, getNotification_1.getNotifications)(req, res);
};
NotificationController.deleteNotification = async (req, res) => {
    return (0, deleteNotification_1.deleteNotification)(req, res);
};
//# sourceMappingURL=index.js.map