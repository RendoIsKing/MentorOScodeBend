"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Controllers_1 = require("../app/Controllers");
const auth_1 = __importDefault(require("../app/Middlewares/auth"));
const auth = (0, express_1.Router)();
auth.post("/register", Controllers_1.AuthController.regsiter);
auth.post("/login", Controllers_1.AuthController.login);
auth.post("/user-login", Controllers_1.AuthController.userLogin);
auth.post("/google", Controllers_1.AuthController.googleLogin);
auth.post("/verify-otp", Controllers_1.AuthController.verifyOtp);
auth.post("/me", auth_1.default, Controllers_1.AuthController.updateMe);
auth.post("/checkUser", Controllers_1.AuthController.checkUser);
auth.post("/forget-password", Controllers_1.AuthController.sendForgotPasswordOtp);
auth.post("/validate-otp", Controllers_1.AuthController.validateForgotPasswordOtp);
auth.put("/reset-password", Controllers_1.AuthController.resetPassword);
auth.get("/me", auth_1.default, Controllers_1.AuthController.me);
auth.post('/logout', (req, res) => {
    var _a, _b;
    try {
        res.cookie('auth_token', '', { maxAge: 0, path: '/', sameSite: 'lax' });
        try {
            (_b = (_a = req.session) === null || _a === void 0 ? void 0 : _a.destroy) === null || _b === void 0 ? void 0 : _b.call(_a, () => { });
        }
        catch { }
        return res.json({ ok: true });
    }
    catch {
        return res.status(200).json({ ok: true });
    }
});
exports.default = auth;
//# sourceMappingURL=auth.routes.js.map