"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.initSentry = initSentry;
exports.sentryErrorHandler = sentryErrorHandler;
const Sentry = __importStar(require("@sentry/node"));
// Optional import; type-only usage guarded at runtime to avoid hard dep failures
let SentryExpress;
try {
    SentryExpress = require('@sentry/express');
}
catch {
    SentryExpress = null;
}
function initSentry(app) {
    var _a, _b;
    try {
        if (!process.env.SENTRY_DSN)
            return;
        Sentry.init({ dsn: process.env.SENTRY_DSN, tracesSampleRate: 0.1 });
        // request/tracing handlers
        if (SentryExpress) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            app.use(SentryExpress.requestHandler());
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            app.use((_b = (_a = SentryExpress).tracingHandler) === null || _b === void 0 ? void 0 : _b.call(_a));
        }
        else {
            // Fallback minimal breadcrumb for visibility without @sentry/express
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            app.use((req, _res, next) => { try {
                Sentry.addBreadcrumb({ category: 'http', message: `${req.method} ${req.url}` });
            }
            catch { } ; next(); });
        }
        // error handler at the end of middleware chain will be added in server.ts or here if needed
    }
    catch { }
}
function sentryErrorHandler() {
    var _a;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return (_a = SentryExpress === null || SentryExpress === void 0 ? void 0 : SentryExpress.errorHandler) === null || _a === void 0 ? void 0 : _a.call(SentryExpress);
}
//# sourceMappingURL=sentry.js.map