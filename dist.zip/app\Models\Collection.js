"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Collection = void 0;
const mongoose_1 = require("mongoose");
const CollectionSchema_1 = require("../../database/schemas/CollectionSchema");
const Collection = (0, mongoose_1.model)("Collection", CollectionSchema_1.CollectionSchema);
exports.Collection = Collection;
//# sourceMappingURL=Collection.js.map