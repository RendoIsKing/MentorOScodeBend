"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPostById = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const Post_1 = require("../../../Models/Post");
const InteractionTypeEnum_1 = require("../../../../types/enums/InteractionTypeEnum");
const getPostById = async (req, res) => {
    try {
        const { id } = req.params;
        const user = req.user;
        if (!mongoose_1.default.Types.ObjectId.isValid(id)) {
            return res.status(400).json({ error: "Invalid ID format" });
        }
        const posts = await Post_1.Post.aggregate([
            {
                $match: {
                    _id: new mongoose_1.default.Types.ObjectId(id),
                    deletedAt: null,
                    isDeleted: false,
                },
            },
            // {
            //   $unwind: "$media",
            // },
            {
                $lookup: {
                    from: "files",
                    localField: "media.mediaId",
                    foreignField: "_id",
                    as: "mediaFiles",
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "user",
                    foreignField: "_id",
                    as: "userInfo",
                },
            },
            {
                $lookup: {
                    from: "files",
                    localField: "userInfo.photoId",
                    foreignField: "_id",
                    as: "userPhoto",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.LIKE_POST] },
                                    ],
                                },
                            },
                        },
                        {
                            $count: "likesCount",
                        },
                    ],
                    as: "likesCount",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id", userId: user === null || user === void 0 ? void 0 : user._id },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$interactedBy", "$$userId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.LIKE_POST] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "likeInteractions",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id", userId: user === null || user === void 0 ? void 0 : user._id },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$interactedBy", "$$userId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "savedInteractions",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.COLLECTION_SAVED] },
                                    ],
                                },
                            },
                        },
                        {
                            $count: "savedCount",
                        },
                    ],
                    as: "savedCount",
                },
            },
            {
                $lookup: {
                    from: "interactions",
                    let: { postId: "$_id" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$post", "$$postId"] },
                                        { $eq: ["$type", InteractionTypeEnum_1.InteractionType.COMMENT] },
                                        { $eq: ["$isDeleted", false] },
                                    ],
                                },
                            },
                        },
                        {
                            $count: "commentsCount",
                        },
                    ],
                    as: "commentsCount",
                },
            },
            {
                $lookup: {
                    from: "userconnections",
                    let: { userId: { $arrayElemAt: ["$userInfo._id", 0] } },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$followingTo", "$$userId"] },
                                        { $eq: ["$owner", new mongoose_1.default.Types.ObjectId(user._id)] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: "followInfo",
                },
            },
            {
                $addFields: {
                    isFollowing: { $gt: [{ $size: "$followInfo" }, 0] },
                    isLiked: { $gt: [{ $size: "$likeInteractions" }, 0] },
                    isSaved: { $gt: [{ $size: "$savedInteractions" }, 0] },
                    // Viewer ownership for modal actions
                    isOwner: { $eq: ["$user", new mongoose_1.default.Types.ObjectId(user._id)] },
                    commentsCount: {
                        $ifNull: [{ $arrayElemAt: ["$commentsCount.commentsCount", 0] }, 0],
                    },
                    savedCount: {
                        $ifNull: [{ $arrayElemAt: ["$savedCount.savedCount", 0] }, 0],
                    },
                    likesCount: {
                        $ifNull: [{ $arrayElemAt: ["$likesCount.likesCount", 0] }, 0],
                    },
                },
            },
            {
                $unset: "followInfo",
            },
            {
                $lookup: {
                    from: "users",
                    let: { userTags: "$userTags" },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $in: ["$_id", "$$userTags.userId"],
                                },
                            },
                        },
                        {
                            $project: {
                                _id: 1,
                                userName: 1,
                            },
                        },
                    ],
                    as: "userTagsUsers",
                },
            },
            {
                $addFields: {
                    userTags: {
                        $map: {
                            input: "$userTags",
                            as: "tag",
                            in: {
                                $mergeObjects: [
                                    "$$tag",
                                    {
                                        userName: {
                                            $arrayElemAt: [
                                                "$userTagsUsers.userName",
                                                {
                                                    $indexOfArray: ["$userTagsUsers._id", "$$tag.userId"],
                                                },
                                            ],
                                        },
                                    },
                                ],
                            },
                        },
                    },
                },
            },
            {
                $project: {
                    userTagsUsers: 0,
                },
            },
        ]);
        if (posts.length === 0) {
            return res.status(404).json({ error: "Post not found", posts });
        }
        return res.json(posts[0]);
    }
    catch (error) {
        console.error("Error retrieving Post:", error);
        return res.status(500).json({ error: "Internal Server Error" });
    }
};
exports.getPostById = getPostById;
//# sourceMappingURL=getPostByIdAction.js.map