"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentEnum = void 0;
var DocumentEnum;
(function (DocumentEnum) {
    DocumentEnum["AadharCard"] = "aadharCard";
    DocumentEnum["VoterCard"] = "voterCard";
    DocumentEnum["Passport"] = "passport";
    DocumentEnum["DrivingLicense"] = "drivingLicense";
    DocumentEnum["Other"] = "other";
})(DocumentEnum || (exports.DocumentEnum = DocumentEnum = {}));
//# sourceMappingURL=DocumentEnum.js.map