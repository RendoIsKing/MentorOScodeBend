"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InteractionType = void 0;
var InteractionType;
(function (InteractionType) {
    InteractionType["LIKE_POST"] = "like_post";
    InteractionType["LIKE_STORY"] = "like_story";
    InteractionType["COMMENT"] = "comment";
    InteractionType["LIKE_COMMENT"] = "like_comment";
    InteractionType["COLLECTION_SAVED"] = "collection_saved";
    InteractionType["IMPRESSION"] = "impression";
    InteractionType["VIEW"] = "view";
})(InteractionType || (exports.InteractionType = InteractionType = {}));
//# sourceMappingURL=InteractionTypeEnum.js.map