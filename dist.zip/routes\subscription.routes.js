"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Middlewares_1 = require("../app/Middlewares");
const Subscriptions_1 = require("../app/Controllers/Subscriptions");
const SubscriptionRoutes = (0, express_1.Router)();
SubscriptionRoutes.post("/", Middlewares_1.Auth, Subscriptions_1.SubscriptionController.createSubscription);
SubscriptionRoutes.post("/one-time", Middlewares_1.Auth, Subscriptions_1.SubscriptionController.createOneTimePayment);
SubscriptionRoutes.post("/tip", Middlewares_1.Auth, Subscriptions_1.SubscriptionController.provideTipToCreator);
exports.default = SubscriptionRoutes;
//# sourceMappingURL=subscription.routes.js.map