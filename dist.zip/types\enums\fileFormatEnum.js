"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileFormatEnum = void 0;
var FileFormatEnum;
(function (FileFormatEnum) {
    FileFormatEnum["TEXT"] = "text";
    FileFormatEnum["JSON"] = "json";
})(FileFormatEnum || (exports.FileFormatEnum = FileFormatEnum = {}));
//# sourceMappingURL=fileFormatEnum.js.map