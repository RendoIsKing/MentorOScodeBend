"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.decideAndApplyAction = void 0;
const zod_1 = require("zod");
const mongoose_1 = require("mongoose");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const PlanModels_1 = require("../../Models/PlanModels");
const ChangeEvent_1 = __importDefault(require("../../../models/ChangeEvent"));
const publish_1 = require("../../../services/events/publish");
const UserProfile_1 = require("../../Models/UserProfile");
const Sentry = __importStar(require("@sentry/node"));
function toTitle(str) {
    return str
        .toLowerCase()
        .replace(/(^|\s)\S/g, (t) => t.toUpperCase());
}
const decideAndApplyAction = async (req, res) => {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    try {
        // Resolve user id from req.user, body, or auth_token cookie
        let userId = ((_a = req.user) === null || _a === void 0 ? void 0 : _a._id) || req.body.userId;
        if (!userId) {
            const cookie = (_b = req.headers) === null || _b === void 0 ? void 0 : _b.cookie;
            const match = cookie === null || cookie === void 0 ? void 0 : cookie.match(/auth_token=([^;]+)/);
            if (match) {
                try {
                    const token = decodeURIComponent(match[1]);
                    const secret = process.env.JWT_SECRET || 'secret_secret';
                    const decoded = jsonwebtoken_1.default.verify(token, secret);
                    userId = (decoded === null || decoded === void 0 ? void 0 : decoded.id) || (decoded === null || decoded === void 0 ? void 0 : decoded._id);
                }
                catch { }
            }
        }
        const MessageSchema = zod_1.z.object({ message: zod_1.z.string().trim().min(1).max(2000) });
        const parsed = MessageSchema.safeParse(req.body || {});
        if (!parsed.success)
            return res.status(422).json({ message: 'validation_failed', details: parsed.error.flatten() });
        const message = String(parsed.data.message || '');
        if (!userId || !mongoose_1.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'userId required' });
        }
        const lower = message.toLowerCase();
        // Heuristic: user states training availability (e.g., "kan trene 4 ganger i uken")
        const avail = lower.match(/trene\s+(\d)\s+(?:ganger|dager)/);
        try {
            Sentry.addBreadcrumb({ category: 'plan', message: 'decideAndApplyAction', data: { userId: String(userId), message: message.slice(0, 200) } });
        }
        catch { }
        if (avail) {
            const days = Number(avail[1]);
            const focuses = ['Overkropp', 'Underkropp', 'Fullkropp', 'Push', 'Pull', 'Legs'];
            const sessions = Array.from({ length: days }).map((_, i) => ({
                day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i % 7],
                focus: focuses[i % focuses.length],
                exercises: [
                    { name: 'Benkpress', sets: 4, reps: 8 },
                    { name: 'Knebøy', sets: 4, reps: 8 },
                    { name: 'Roing', sets: 4, reps: 10 },
                ],
            }));
            const current = await PlanModels_1.TrainingPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 });
            const nextVersion = ((current === null || current === void 0 ? void 0 : current.version) || 0) + 1;
            await PlanModels_1.TrainingPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
            const created = await PlanModels_1.TrainingPlan.create({ userId, version: nextVersion, isCurrent: true, sessions });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'PLAN_EDIT', summary: `Generated plan for ${days} days/week`, actor: (_c = req === null || req === void 0 ? void 0 : req.user) === null || _c === void 0 ? void 0 : _c._id, before: { fromVersion: current === null || current === void 0 ? void 0 : current.version }, after: { toVersion: nextVersion } });
            }
            catch { }
            try {
                await (0, publish_1.publish)({ type: 'PLAN_UPDATED', user: userId });
            }
            catch { }
            return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'training', planId: String(created._id) }], summary: `Ny treningsplan (${days} dager/uke) er lagt til Assets` });
        }
        // 0) Generate plans on demand: "lag treningsplan" / "ny treningsplan" / "lag kostholdsplan"
        // Add to assets (implicit plan) or explicit new training plan
        if (
        // explicit intent (lag/ny)
        ((/\blag\b|\bny\b/).test(lower) && /treningsplan/.test(lower)) ||
            // colloquial: "legg til i treningsplan(er)"
            (/(legg|legge)\s+til.*treningsplan(er)?/.test(lower)) ||
            // english
            ((/add/).test(lower) && /training\s*plan/.test(lower)) ||
            // mention assets with create verbs
            ((/\blag\b|\bny\b|\blegg\b|\blegge\b|\badd\b/).test(lower) && /assets/.test(lower))) {
            const profile = await UserProfile_1.UserProfile.findOne({ userId }).lean();
            // try to infer number of days from message, including patterns like "4-dagers"
            const inferred = lower.match(/(\d)[- ]?dagers|trene\s+(\d)\s+(?:ganger|dager)/);
            const inferDays = inferred ? Number(inferred[1] || inferred[2]) : undefined;
            const days = inferDays || (profile === null || profile === void 0 ? void 0 : profile.trainingDaysPerWeek) || 4;
            const focuses = ['Overkropp', 'Underkropp', 'Fullkropp', 'Push', 'Pull', 'Legs'];
            const sessions = Array.from({ length: days }).map((_, i) => ({
                day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i % 7],
                focus: focuses[i % focuses.length],
                exercises: [
                    { name: 'Benkpress', sets: 3, reps: 8 },
                    { name: 'Knebøy', sets: 3, reps: 8 },
                    { name: 'Roing', sets: 3, reps: 10 },
                ],
            }));
            const current = await PlanModels_1.TrainingPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 });
            const nextVersion = ((current === null || current === void 0 ? void 0 : current.version) || 0) + 1;
            await PlanModels_1.TrainingPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
            const created = await PlanModels_1.TrainingPlan.create({ userId, version: nextVersion, isCurrent: true, sessions });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'PLAN_EDIT', summary: 'Generated new training plan', actor: (_d = req === null || req === void 0 ? void 0 : req.user) === null || _d === void 0 ? void 0 : _d._id, before: { fromVersion: current === null || current === void 0 ? void 0 : current.version }, after: { toVersion: nextVersion } });
            }
            catch { }
            try {
                await (0, publish_1.publish)({ type: 'PLAN_UPDATED', user: userId });
            }
            catch { }
            return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'training', planId: String(created._id) }], summary: 'Ny treningsplan er lagt til Assets' });
        }
        if ((/\blag\b|\bny\b/).test(lower) && /(kostholdsplan|måltidsplan|meal)/.test(lower)) {
            const profile = await UserProfile_1.UserProfile.findOne({ userId }).lean();
            const weight = (profile === null || profile === void 0 ? void 0 : profile.currentWeightKg) || 80;
            const kcal = Math.round(weight * 30);
            const protein = Math.round(weight * 2.0);
            const carbs = Math.round((kcal * 0.5) / 4);
            const fat = Math.round((kcal * 0.25) / 9);
            const current = await PlanModels_1.NutritionPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 });
            const nextVersion = ((current === null || current === void 0 ? void 0 : current.version) || 0) + 1;
            await PlanModels_1.NutritionPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
            const created = await PlanModels_1.NutritionPlan.create({ userId, version: nextVersion, isCurrent: true, dailyTargets: { kcal, protein, carbs, fat }, notes: (profile === null || profile === void 0 ? void 0 : profile.nutritionPreferences) || '' });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'NUTRITION_EDIT', summary: 'Generated new nutrition plan', actor: (_e = req === null || req === void 0 ? void 0 : req.user) === null || _e === void 0 ? void 0 : _e._id, before: { fromVersion: current === null || current === void 0 ? void 0 : current.version }, after: { toVersion: nextVersion } });
            }
            catch { }
            try {
                await (0, publish_1.publish)({ type: 'NUTRITION_UPDATED', user: userId });
            }
            catch { }
            return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'nutrition', planId: String(created._id) }], summary: 'Ny kostholdsplan er lagt til Assets' });
        }
        // 1) Swap exercise: "bytt [old] til [new]"
        const swapMatch = lower.match(/bytt\s+([^\n]+?)\s+til\s+([^\n]+)$/);
        if (swapMatch) {
            const oldName = toTitle(swapMatch[1].trim());
            const newName = toTitle(swapMatch[2].trim());
            const current = await PlanModels_1.TrainingPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 });
            if (!current)
                return res.json({ noAction: true, info: 'No current training plan' });
            const nextVersion = (current.version || 0) + 1;
            const sessions = (current.sessions || []).map((s) => ({
                ...s,
                exercises: (s.exercises || []).map((e) => {
                    var _a;
                    return ({
                        ...e,
                        name: ((_a = e.name) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === oldName.toLowerCase() ? newName : e.name,
                    });
                }),
            }));
            await PlanModels_1.TrainingPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
            const created = await PlanModels_1.TrainingPlan.create({ userId, version: nextVersion, isCurrent: true, sessions });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'PLAN_EDIT', summary: `Swapped ${oldName} to ${newName}`, actor: (_f = req === null || req === void 0 ? void 0 : req.user) === null || _f === void 0 ? void 0 : _f._id, before: { fromVersion: current.version }, after: { toVersion: nextVersion } });
            }
            catch { }
            try {
                await (0, publish_1.publish)({ type: 'PLAN_UPDATED', user: userId });
            }
            catch { }
            return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'training', planId: String(created._id) }], summary: `Byttet ${oldName} til ${newName}` });
        }
        // 2) Set calories: "sett kalorier til 2400" / "sett kcal til 2200"
        const kcalSet = lower.match(/sett\s+(?:kalorier|kcal)\s+til\s+(\d{3,4})/);
        if (kcalSet) {
            const kcal = Number(kcalSet[1]);
            const current = await PlanModels_1.NutritionPlan.findOne({ userId, isCurrent: true }).sort({ version: -1 });
            const nextVersion = ((current === null || current === void 0 ? void 0 : current.version) || 0) + 1;
            const base = (current === null || current === void 0 ? void 0 : current.dailyTargets) || { kcal, protein: Math.round(kcal * 0.3 / 4), carbs: Math.round(kcal * 0.5 / 4), fat: Math.round(kcal * 0.2 / 9) };
            const ratio = { p: (base.protein * 4) / base.kcal, c: (base.carbs * 4) / base.kcal, f: (base.fat * 9) / base.kcal };
            const protein = Math.round((kcal * ratio.p) / 4);
            const carbs = Math.round((kcal * ratio.c) / 4);
            const fat = Math.round((kcal * ratio.f) / 9);
            await PlanModels_1.NutritionPlan.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
            const created = await PlanModels_1.NutritionPlan.create({ userId, version: nextVersion, isCurrent: true, dailyTargets: { kcal, protein, carbs, fat }, notes: (current === null || current === void 0 ? void 0 : current.notes) || '' });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'NUTRITION_EDIT', summary: `Set calories to ${kcal}`, actor: (_g = req === null || req === void 0 ? void 0 : req.user) === null || _g === void 0 ? void 0 : _g._id, before: { fromVersion: current === null || current === void 0 ? void 0 : current.version }, after: { toVersion: nextVersion, kcal } });
            }
            catch { }
            try {
                await (0, publish_1.publish)({ type: 'NUTRITION_UPDATED', user: userId });
            }
            catch { }
            return res.json({ actions: [{ type: 'PLAN_CREATE', area: 'nutrition', planId: String(created._id) }], summary: `Kalorier satt til ${kcal}` });
        }
        // 3) Update goal: "sett vektmål til 75kg"
        const goalSet = lower.match(/sett\s+(?:vektmål|mål)\s+til\s+(\d{2,3})\s*kg?/);
        if (goalSet) {
            const target = Number(goalSet[1]);
            const current = await PlanModels_1.Goal.findOne({ userId, isCurrent: true }).sort({ version: -1 });
            const nextVersion = ((current === null || current === void 0 ? void 0 : current.version) || 0) + 1;
            await PlanModels_1.Goal.updateMany({ userId, isCurrent: true }, { $set: { isCurrent: false } });
            const created = await PlanModels_1.Goal.create({ userId, version: nextVersion, isCurrent: true, targetWeightKg: target, strengthTargets: (current === null || current === void 0 ? void 0 : current.strengthTargets) || '', horizonWeeks: (current === null || current === void 0 ? void 0 : current.horizonWeeks) || 8 });
            try {
                await ChangeEvent_1.default.create({ user: userId, type: 'PLAN_EDIT', summary: `Updated target weight to ${target}kg`, actor: (_h = req === null || req === void 0 ? void 0 : req.user) === null || _h === void 0 ? void 0 : _h._id, before: { fromVersion: current === null || current === void 0 ? void 0 : current.version }, after: { toVersion: nextVersion, target } });
            }
            catch { }
            return res.json({ actions: [{ type: 'GOAL_SET', goalId: String(created._id) }], summary: `Vektmål oppdatert til ${target}kg` });
        }
        return res.json({ noAction: true });
    }
    catch (e) {
        console.error('decideAndApplyAction error', e);
        return res.status(500).json({ message: 'action failed' });
    }
};
exports.decideAndApplyAction = decideAndApplyAction;
//# sourceMappingURL=decisionEngine.js.map