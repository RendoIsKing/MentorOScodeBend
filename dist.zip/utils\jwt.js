"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateToken = generateToken;
exports.generateAuthToken = generateAuthToken;
const jsonwebtoken_1 = require("jsonwebtoken");
function generateToken(data) {
    return (0, jsonwebtoken_1.sign)(data, process.env.APP_SECRET);
}
function generateAuthToken(user) {
    const data = {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
        phoneNumber: user.phoneNumber,
        isActive: user.isActive,
        isVerified: user.isVerified,
        isDeleted: user.isDeleted,
        date: new Date()
    };
    return generateToken(data);
}
//# sourceMappingURL=jwt.js.map