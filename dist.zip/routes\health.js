"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
const package_json_1 = __importDefault(require("../../package.json"));
const r = (0, express_1.Router)();
r.get('/health', (_req, res) => res.json({ ok: true, version: package_json_1.default.version, uptimeSeconds: Math.floor(process.uptime()) }));
exports.default = r;
//# sourceMappingURL=health.js.map