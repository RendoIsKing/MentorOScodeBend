"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cardDetails = void 0;
const mongoose_1 = require("mongoose");
const cardDetailsSchema_1 = require("../../database/schemas/cardDetailsSchema");
const cardDetails = (0, mongoose_1.model)('cardDetails', cardDetailsSchema_1.CardDetailsSchema);
exports.cardDetails = cardDetails;
//# sourceMappingURL=CardDetails.js.map