"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postSubscriptionPlan = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const SubscriptionPlan_1 = require("../../../Models/SubscriptionPlan");
const subscriptionPlanInput_1 = require("../Inputs/subscriptionPlanInput");
const subscriptionPlanEnum_1 = require("../../../../types/enums/subscriptionPlanEnum");
const postSubscriptionPlan = async (req, res) => {
    try {
        const user = req.user;
        const subscriptionPlanInput = (0, class_transformer_1.plainToClass)(subscriptionPlanInput_1.SubscriptionPlanInput, req.body);
        const validationErrors = await (0, class_validator_1.validate)(subscriptionPlanInput);
        if (validationErrors.length > 0) {
            return res.status(400).json({ errors: validationErrors });
        }
        let subscriptionPlan;
        if (subscriptionPlanInput.planType === subscriptionPlanEnum_1.SubscriptionPlanType.FIXED) {
            subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.findOne({
                userId: user.id,
                planType: subscriptionPlanEnum_1.SubscriptionPlanType.FIXED,
                isDeleted: false,
            });
            if (subscriptionPlan) {
                subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.findByIdAndUpdate(subscriptionPlan._id, { ...subscriptionPlanInput }, { new: true });
            }
            else {
                subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.create({
                    ...subscriptionPlanInput,
                    userId: user.id,
                });
            }
        }
        else {
            subscriptionPlan = await SubscriptionPlan_1.SubscriptionPlan.create({
                ...subscriptionPlanInput,
                userId: user.id,
            });
        }
        return res.json({
            data: subscriptionPlan,
            message: "Plan created successfully.",
        });
    }
    catch (err) {
        console.error(err, "Error creating plan");
        return res
            .status(500)
            .json({ error: { message: "Something went wrong." } });
    }
};
exports.postSubscriptionPlan = postSubscriptionPlan;
//# sourceMappingURL=createSubscriptionPlanAction.js.map