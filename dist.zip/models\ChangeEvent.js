"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const ChangeEventSchema = new mongoose_1.Schema({
    user: { type: mongoose_1.Schema.Types.ObjectId, ref: "User", index: true, required: true },
    type: { type: String, enum: ["PLAN_EDIT", "NUTRITION_EDIT", "WEIGHT_LOG", "WORKOUT_LOG", "GOAL_EDIT"], required: true },
    summary: { type: String, required: true },
    rationale: String,
    refId: { type: mongoose_1.Schema.Types.ObjectId },
    actor: { type: mongoose_1.Schema.Types.Mixed },
    before: { type: mongoose_1.Schema.Types.Mixed },
    after: { type: mongoose_1.Schema.Types.Mixed }
}, { timestamps: true });
ChangeEventSchema.index({ user: 1, createdAt: -1 });
exports.default = mongoose_1.model.ChangeEvent || (0, mongoose_1.model)("ChangeEvent", ChangeEventSchema);
//# sourceMappingURL=ChangeEvent.js.map