"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentSchema = void 0;
const mongoose_1 = require("mongoose");
const DocumentEnum_1 = require("../../types/DocumentEnum");
const DocumentStatusEnum_1 = require("../../types/DocumentStatusEnum");
const DocumentSchema = new mongoose_1.Schema({
    title: {
        type: String,
        required: false,
    },
    description: {
        type: String,
        required: false,
    },
    userId: {
        type: mongoose_1.Types.ObjectId,
        required: true,
        ref: "User",
    },
    documentMediaId: {
        type: mongoose_1.Types.ObjectId,
        required: true,
        ref: "File"
    },
    verifiedAt: {
        type: Date,
        default: null
    },
    verifiedBy: {
        type: String,
        default: null
    },
    type: {
        type: String,
        enum: Object.values(DocumentEnum_1.DocumentEnum),
        required: false
    },
    status: {
        type: String,
        required: false,
        default: DocumentStatusEnum_1.DocumentStatusEnum.Pending
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    deletedAt: {
        type: Date,
        default: null
    },
}, { timestamps: true });
exports.DocumentSchema = DocumentSchema;
//# sourceMappingURL=DocumentSchema.js.map