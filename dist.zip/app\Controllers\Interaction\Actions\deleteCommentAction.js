"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.softDeleteComment = void 0;
const Interaction_1 = require("../../../Models/Interaction");
const RolesEnum_1 = require("../../../../types/RolesEnum");
const softDeleteChildComments = async (commentId) => {
    const comment = await Interaction_1.Interaction.findById(commentId);
    if (comment && comment.replies && comment.replies.length > 0) {
        for (const replyId of comment.replies) {
            const reply = await Interaction_1.Interaction.findById(replyId);
            if (reply && !reply.isDeleted) {
                reply.isDeleted = true;
                reply.deletedAt = new Date();
                await reply.save();
                await softDeleteChildComments(reply._id.toString());
            }
        }
    }
};
const softDeleteComment = async (req, res) => {
    try {
        const user = req.user;
        const id = req.params.id;
        const comment = await Interaction_1.Interaction.findById(id);
        if (!comment) {
            return res.status(404).json({ error: { message: "Comment not found" } });
        }
        if (comment.interactedBy.toString() !== user.id.toString() &&
            (user === null || user === void 0 ? void 0 : user.role) !== RolesEnum_1.RolesEnum.ADMIN) {
            return res
                .status(400)
                .json({ error: { message: "You cannot delete this comment" } });
        }
        if (comment.isDeleted) {
            return res
                .status(400)
                .json({ error: { message: "Comment is already deleted" } });
        }
        comment.isDeleted = true;
        comment.deletedAt = new Date();
        await comment.save();
        await softDeleteChildComments(comment._id.toString());
        return res.json({ message: "Comment/child comments deleted successfully" });
    }
    catch (error) {
        console.log(error, "error in deleting comment");
        return res.status(500).json({ error: { message: "Something went wrong" } });
    }
};
exports.softDeleteComment = softDeleteComment;
//# sourceMappingURL=deleteCommentAction.js.map